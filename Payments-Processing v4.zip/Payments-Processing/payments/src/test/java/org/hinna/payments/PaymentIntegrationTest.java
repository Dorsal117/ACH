package org.hinna.payments;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.junit.jupiter.api.Test;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import org.springframework.http.MediaType;

@SpringBootTest
@AutoConfigureMockMvc
public class PaymentIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testCreatePayment() throws Exception {
        String json = """
            {
              "customerId": "123e4567-e89b-12d3-a456-426614174000",
              "paymentMethodId": "321e4567-e89b-12d3-a456-426614174111",
              "amount": 120.00,
              "description": "Test Payment",
              "referenceNumber": "TEST-REF-001"
            }
        """;

        mockMvc.perform(post("/api/payments")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.amount").value(120.00))
                .andExpect(jsonPath("$.description").value("Test Payment"));
    }
}
