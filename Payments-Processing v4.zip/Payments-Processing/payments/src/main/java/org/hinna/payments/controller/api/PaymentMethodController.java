package org.hinna.payments.controller.api;

import lombok.extern.slf4j.Slf4j;
import com.stripe.model.SetupIntent;

import org.hinna.payments.dto.AchSetupIntentResponse;
import org.hinna.payments.dto.AchVerificationRequest;
import org.hinna.payments.dto.ConfirmSetupIntentRequest;
import org.hinna.payments.dto.PaymentMethodRequestDTO;
import org.hinna.payments.dto.PaymentMethodResponseDTO;
import org.hinna.payments.dto.StripeSetupIntentDTO;
import org.hinna.payments.model.Account;
import org.hinna.payments.model.PaymentMethod;
import org.hinna.payments.model.enums.PaymentType;
import org.hinna.payments.service.AccountService;
import org.hinna.payments.service.PaymentMethodService;
import org.hinna.payments.service.StripeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * REST Controller for payment method operations, managing saved payment methods
 */
@RestController
@RequestMapping("/api/payment-methods")
@Slf4j
public class PaymentMethodController {

    private final PaymentMethodService paymentMethodService;
    private final AccountService accountService;
    private final StripeService stripeService;

    @Autowired
    public PaymentMethodController(PaymentMethodService paymentMethodService,
            AccountService accountService,
            StripeService stripeService) {
        this.paymentMethodService = paymentMethodService;
        this.accountService = accountService;
        this.stripeService = stripeService;
    }

    /**
     * Create a payment method
     * 
     * @param paymentMethodRequestDTO RequestDTO
     * @return PaymentMethodReturnDTO
     */
    @PostMapping
    public ResponseEntity<PaymentMethodResponseDTO> createPaymentMethod(
            @RequestBody PaymentMethodRequestDTO paymentMethodRequestDTO) {
        try {
            // Validate owner exists
            Account owner = accountService.getAccountById(paymentMethodRequestDTO.getOwnerId())
                    .orElseThrow(() -> new IllegalArgumentException("Account not found"));

            PaymentMethod paymentMethod = new PaymentMethod(owner, paymentMethodRequestDTO.getType());
            paymentMethod.setProviderToken(paymentMethodRequestDTO.getProviderToken());

            // Set basic info from request (brand info will be extracted in service layer)
            paymentMethod.setLastFourDigits(paymentMethodRequestDTO.getLastFourDigits());
            paymentMethod.setBrand(paymentMethodRequestDTO.getBrand());
            paymentMethod.setWalletType(paymentMethod.getWalletType());

            if (paymentMethodRequestDTO.getExpiryDate() != null) {
                // Parse expiry date (MM/YY)
                String expiryDate = paymentMethodRequestDTO.getExpiryDate();
                int month = Integer.parseInt(expiryDate.substring(0, 2));
                int year = Integer.parseInt("20" + expiryDate.substring(3, 5));

                // Set to last day of month
                LocalDateTime expiry = LocalDateTime.of(year, month, 1, 0, 0)
                        .plusMonths(1).minusDays(1);

                paymentMethod.setExpiryDate(expiry);
            }

            paymentMethod.setIsDefault(paymentMethodRequestDTO.getIsDefault());
            paymentMethod.setIsActive(true);

            // Service will extract brand info during validation
            PaymentMethod createdPaymentMethod = paymentMethodService.createPaymentMethod(paymentMethod);

            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(this.convertToResponseDTO(createdPaymentMethod));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to create payment method");
        }
    }

    /**
     * Get payment method by ID
     * 
     * @param id payment method's ID
     * @return PaymentMethod as ResponseEntity
     */
    @GetMapping({ "/{id}" })
    public ResponseEntity<PaymentMethodResponseDTO> getPaymentMethodById(@PathVariable UUID id) {
        return paymentMethodService.getPaymentMethodById(id)
                .map(paymentMethod -> ResponseEntity.ok(this.convertToResponseDTO(paymentMethod)))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Payment method not found"));
    }

    /**
     * Get payment methods by owner
     * 
     * @param ownerId owner's ID
     * @return list of payment methods
     */
    @GetMapping("/owner/{ownerId}")
    public ResponseEntity<List<PaymentMethodResponseDTO>> getPaymentMethodsByOwner(@PathVariable UUID ownerId) {
        try {
            Account owner = accountService.getAccountById(ownerId)
                    .orElseThrow(() -> new IllegalArgumentException("Account not found"));

            List<PaymentMethod> paymentMethods = paymentMethodService.getPaymentMethodsByOwner(owner);
            List<PaymentMethodResponseDTO> paymentMethodResponseDTOs = paymentMethods.stream()
                    .map(this::convertToResponseDTO)
                    .collect(Collectors.toList());

            return ResponseEntity.ok(paymentMethodResponseDTOs);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }

    /**
     * Update a payment method
     * 
     * @param id payment method's ID
     * @return updated payment method as response DTO
     */
    @PutMapping("/{id}")
    public ResponseEntity<PaymentMethodResponseDTO> updatePaymentMethod(
            @PathVariable UUID id,
            @RequestBody PaymentMethodRequestDTO paymentMethodRequestDTO) {
        try {
            PaymentMethod paymentMethodDetails = new PaymentMethod();
            paymentMethodDetails.setIsActive(paymentMethodRequestDTO.getIsActive());
            paymentMethodDetails.setIsDefault(paymentMethodRequestDTO.getIsDefault());

            PaymentMethod updatedPaymentMethod = paymentMethodService.updatePaymentMethod(id, paymentMethodDetails);

            return ResponseEntity.ok(this.convertToResponseDTO(updatedPaymentMethod));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to update payment method");
        }
    }

    /**
     * Delete a payment method
     * 
     * @param id Payment method's ID
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePaymentMethod(@PathVariable UUID id) {
        try {
            paymentMethodService.deletePaymentMethod(id);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to delete the payment method");
        }
    }

    /**
     * Set payment method as default
     * 
     * @param id Payment method's ID
     * @return Updated payment method
     */
    @PostMapping("/{id}/set-default")
    public ResponseEntity<PaymentMethodResponseDTO> setDefaultPaymentMethod(@PathVariable UUID id) {
        try {
            PaymentMethod paymentMethod = paymentMethodService.getPaymentMethodById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Payment method not found"));

            paymentMethodService.setDefaultPaymentMethod(id, paymentMethod.getOwner());

            PaymentMethod updatedPaymentMethod = paymentMethodService.getPaymentMethodById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Payment method not found"));

            return ResponseEntity.ok(this.convertToResponseDTO(updatedPaymentMethod));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to set payment method as default");
        }
    }

    /**
     * Create Stripe setup intent for adding a new payment method
     * 
     * @param accountId Account ID
     * @return StripeSetupIntentDTO
     */
    @PostMapping("/stripe/setup-intent")
    public ResponseEntity<StripeSetupIntentDTO> createStripeSetupIntent(@RequestParam UUID accountId) {
        try {
            Account account = accountService.getAccountById(accountId)
                    .orElseThrow(() -> new IllegalArgumentException("Account not found"));

            String clientSecret = stripeService.createSetupIntent(account);

            StripeSetupIntentDTO response = new StripeSetupIntentDTO();
            response.setClientSecret(clientSecret);
            response.setAccountId(accountId);

            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to create Stripe setup intent",
                    e);
        }
    }

    /**
     * Confirm setup intent and create payment method with extracted Stripe data
     */
    @PostMapping("/stripe/confirm-setup")
    public ResponseEntity<PaymentMethodResponseDTO> confirmSetupIntent(
            @RequestBody ConfirmSetupIntentRequest request) {
        try {
            log.info("Confirming setup intent: {} for account: {}",
                    request.getSetupIntentId(),
                    request.getAccountId());

            // Validate account exists
            Account owner = accountService.getAccountById(request.getAccountId())
                    .orElseThrow(() -> new IllegalArgumentException("Account not found"));

            // Get the setup intent to find the payment method
            SetupIntent setupIntent = SetupIntent.retrieve(request.getSetupIntentId());
            String paymentMethodId = setupIntent.getPaymentMethod();

            if (paymentMethodId == null) {
                throw new IllegalArgumentException("No payment method found in setup intent");
            }

            // Create PaymentMethod entity with Stripe token
            PaymentMethod paymentMethod = new PaymentMethod(owner, PaymentType.CREDIT_CARD);
            paymentMethod.setProviderToken(paymentMethodId);
            paymentMethod.setIsActive(true);
            paymentMethod.setIsDefault(request.getIsDefault() != null ? request.getIsDefault() : false);

            // Service will enrich with Stripe data during creation
            PaymentMethod createdPaymentMethod = paymentMethodService.createPaymentMethod(paymentMethod);

            log.info("Successful created payment method {} with brand: {}",
                    createdPaymentMethod.getId(),
                    createdPaymentMethod.getBrand());

            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(this.convertToResponseDTO(createdPaymentMethod));

        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            log.error("Error confirming setup intent", e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to confirm setup intent");
        }
    }

    /**
     * Convert PaymentMethod to PaymentMethodResponseDTO
     * 
     * @param paymentMethod PaymentMethod
     * @return ResponseDTO
     */
    private PaymentMethodResponseDTO convertToResponseDTO(PaymentMethod paymentMethod) {
        PaymentMethodResponseDTO dto = new PaymentMethodResponseDTO();
        dto.setId(paymentMethod.getId());
        dto.setOwnerId(paymentMethod.getOwner().getId());
        dto.setOwnerName(paymentMethod.getOwner().getFullName());
        dto.setType(paymentMethod.getType());
        dto.setLastFourDigits(paymentMethod.getLastFourDigits());
        dto.setBrand(paymentMethod.getBrand());
        dto.setWalletType(paymentMethod.getWalletType());

        if (paymentMethod.getExpiryDate() != null) {
            dto.setExpiryDate(paymentMethod.getExpiryDate().format(DateTimeFormatter.ofPattern("MM/yy")));
            dto.setExpired(paymentMethod.isExpired());
        }

        dto.setIsDefault(paymentMethod.getIsDefault());
        dto.setIsActive(paymentMethod.getIsActive());
        dto.setDisplayName(paymentMethod.getDisplayName());
        dto.setBankVerificationStatus(paymentMethod.getBankVerificationStatus());
        dto.setBankVerificationMethod(paymentMethod.getBankVerificationMethod());
        dto.setBankAccountVerified(paymentMethod.isBankAccountVerified());
        dto.setBankMandateReference(paymentMethod.getBankMandateReference());
        dto.setBankMandateUrl(paymentMethod.getBankMandateUrl());

        return dto;
    }

    @PostMapping("/owner/{ownerId}/ach/setup-intent")
    public ResponseEntity<AchSetupIntentResponse> createAchSetupIntent(@PathVariable UUID ownerId) {
        Account owner = accountService.getAccountById(ownerId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Account not found"));

        String clientSecret = stripeService.createAchSetupIntent(owner);

        AchSetupIntentResponse response = new AchSetupIntentResponse();
        response.setClientSecret(clientSecret);
        return ResponseEntity.ok(response);
    }

        @PostMapping("/{id}/ach/verify")
    public ResponseEntity<PaymentMethodResponseDTO> verifyAchPaymentMethod(
            @PathVariable UUID id,
            @RequestBody AchVerificationRequest request) {

        PaymentMethod updated = paymentMethodService.verifyAchMicroDeposits(
                id,
                request.getFirstAmount(),
                request.getSecondAmount());

        return ResponseEntity.ok(convertToResponseDTO(updated));
    }

    @PostMapping("/{id}/ach/refresh")
    public ResponseEntity<PaymentMethodResponseDTO> refreshAchDetails(@PathVariable UUID id) {
        PaymentMethod updated = paymentMethodService.refreshAchDetails(id);
        return ResponseEntity.ok(convertToResponseDTO(updated));
    }



}
