package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "reseller_account")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = {"saasAccount", "customers"}, callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class ResellerAccount extends Account{

    @Column(name = "company_name", nullable = false)
    private String companyName;

    @Column(name = "reseller_code", nullable = false, unique = true)
    private String resellerCode;

    @ManyToOne
    @JoinColumn(name = "saas_account_id")
    private SaaSAccount saasAccount;

    @Column(name = "commission_rate", nullable = false)
    private BigDecimal commissionRate;

    @OneToMany(mappedBy = "reseller", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DirectCustomer> customers = new ArrayList<>();

    public ResellerAccount(String firstName, String lastName, String email,
                           String companyName, String resellerCode, BigDecimal commissionRate) {
        super(firstName, lastName, email);
        this.companyName = companyName;
        this.resellerCode = resellerCode;
        this.commissionRate = commissionRate;
    }

    public void addCustomer(DirectCustomer customer) {
        customers.add(customer);
        customer.setReseller(this);
    }

    public void removeCustomer(DirectCustomer customer) {
        customers.remove(customer);
        customer.setReseller(null);
    }

    public BigDecimal calculateCommission(BigDecimal amount) {
        return amount.multiply(commissionRate.divide(new BigDecimal("100")));
    }
}
