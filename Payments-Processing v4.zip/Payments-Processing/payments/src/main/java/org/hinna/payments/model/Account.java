package org.hinna.payments.model;


import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "account")
@Inheritance(strategy = InheritanceType.JOINED)
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = {"billingHistory", "paymentMethods"})
@EqualsAndHashCode(of = "id")
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "first_name", nullable = false)
    private String firstName;

    @Column(name = "last_name", nullable = false)
    private String lastName;

    @Column(nullable = false, unique = true)
    private String email;

    private String address;

    @Column(name = "mobile_phone")
    private String mobilePhone;

    @Column(name = "home_phone")
    private String homePhone;

    @Column(name = "dob")
    private LocalDate dob;

    @Column(name = "gender")
    private String gender;

    @Column(name = "profile_picture_path")
    private String profilePicturePath;

    @Column(name = "qr_code_path")
    private String qrCodePath;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "is_active")
    private boolean isActive;

    @ManyToOne
    @JoinColumn(name = "location_id")
    private Location location;

    @OneToMany(mappedBy = "owner", cascade = CascadeType.ALL)
    private List<PaymentMethod> paymentMethods = new ArrayList<>();

    @OneToMany(mappedBy = "account", cascade = CascadeType.ALL)
    private List<BillingHistory> billingHistory = new ArrayList<>();

    /**
     * Creates a link between payment system's accounts and the users in the User Service
     */
    @Column(name = "external_user_id")
    private Long externalUserId;

    public Account(String firstName, String lastName, String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    @PrePersist
    public void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.isActive = true;
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }

    public void addPaymentMethod(PaymentMethod paymentMethod) {
        if (paymentMethod == null) {
            return;
        }

        if (!paymentMethods.contains(paymentMethod)) {
            paymentMethods.add(paymentMethod);
            paymentMethod.setOwner(this);
        }
    }

    public void removePaymentMethod(PaymentMethod paymentMethod) {
        if (paymentMethod == null) {
            return;
        }

        if (paymentMethods.remove(paymentMethod)) {
            paymentMethod.setOwner(null);
        }
    }
}
