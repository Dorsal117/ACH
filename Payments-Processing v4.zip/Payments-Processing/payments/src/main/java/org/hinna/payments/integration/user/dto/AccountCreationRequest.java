package org.hinna.payments.integration.user.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Request to create a new account for a user from the Login-Register system")
public class AccountCreationRequest {

    @Schema(description = "ID of the user in the Login-Register system", example = "12345")
    private Long userId;

    @Schema(description = "Email of the user in the Login-Register system", example = "example@gmail.com")
    private String email;

    @Schema(description = "User's first name", example = "John")
    private String firstName;

    @Schema(description = "User's last name", example = "Doe")
    private String lastName;

    @Schema(description = "User's role in the system", example = "BUSINESS")
    private String role;

    @Schema(description = "User's address")
    private String address;

    @Schema(description = "User's profile picture path")
    private String profilePicturePath;

    // Business-specific fields
    @Schema(description = "Business name (for BUSINESS role)", example = "Acme Inc.")
    private String businessName;

    @Schema(description = "Tax ID (for BUSINESS role)", example = "123-45-6789")
    private String taxId;

    // Reseller/SaaS-specific fields
    @Schema(description = "Company name (for RESELLER or SAAS roles)", example = "Global Distribution Corp")
    private String companyName;
}
