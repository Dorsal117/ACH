package org.hinna.payments.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class RefundRequestDTO {
    private BigDecimal amount;
    private String reason;
}
