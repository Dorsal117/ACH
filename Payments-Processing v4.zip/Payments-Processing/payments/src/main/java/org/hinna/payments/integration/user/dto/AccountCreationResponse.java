package org.hinna.payments.integration.user.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Response after account creation attempt")
public class AccountCreationResponse {

    @Schema(description = "Whether the creation was successful", example = "true")
    private boolean success;

    @Schema(description = "ID of the created account in the Payment System", example = "123e4567-e89b-12d3-a456-426614174000")
    private UUID accountId;

    @Schema(description = "ID of the user in the Login-Register system", example = "12345")
    private Long userId;

    @Schema(description = "Message describing the result", example = "Account successful created")
    private String message;
}
