package org.hinna.payments.service;

import org.springframework.stereotype.Service;
import org.hinna.payments.model.Refund;

import java.math.BigDecimal;
import java.util.UUID;

@Service
public interface RefundService {
    /**
     * Requests a refund for a given payment.
     *
     * @param paymentId the ID of the payment to refund
     * @param amount the amount to refund
     * @param reason the reason for requesting the refund
     * @return the created Refund entity
     */
    Refund requestRefund(UUID paymentId, BigDecimal amount, String reason);

     /**
     * Approves and processes a refund.
     *
     * @param refundId the ID of the refund to approve
     * @return the updated Refund entity after processing
     */
    Refund approveRefund(UUID refundId);

     /**
     * Rejects a refund request.
     *
     * @param refundId the ID of the refund to reject
     * @param rejectionReason the reason why the refund was rejected
     * @return the updated Refund entity after rejection
     */
    Refund rejectRefund(UUID refundId, String rejectionReason);
}
