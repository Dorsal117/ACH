package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "admin")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = { "account", "adminGroup" })
@EqualsAndHashCode(of = "id")
public class Admin {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @OneToOne
    @JoinColumn(name = "account_id")
    private Account account;

    @Column(name = "admin_type")
    private String adminType; // Business or Reseller

    @Column(name = "roles_overview")
    private String rolesOverview;

    @Column(name = "tables_accessible")
    private String tablesAccessible;

    @Column(name = "tables_created")
    private String tablesCreated;

    @Column(name = "base_permissions")
    private String basePermissions;

    @ManyToOne
    @JoinColumn(name = "admin_group_id")
    private AdminGroup adminGroup;

    @ManyToMany
    @JoinTable(name = "admin_accessible_table", joinColumns = @JoinColumn(name = "admin_id"), inverseJoinColumns = @JoinColumn(name = "table_id"))
    private Set<DatabaseTable> accessibleTables = new HashSet<>();

    @ManyToMany
    @JoinTable(name = "admin_created_table", joinColumns = @JoinColumn(name = "admin_id"), inverseJoinColumns = @JoinColumn(name = "table_id"))
    private Set<DatabaseTable> createdTables = new HashSet<>();

    public Admin(Account account, String adminType) {
        this.account = account;
        this.adminType = adminType;
    }

    public boolean hasPermission(String permissionName) {
        if (adminGroup == null) {
            return false;
        }
        return adminGroup.hasPermission(permissionName);
    }

    public boolean canAccessTable(String tableName) {
        return accessibleTables.stream()
                .anyMatch(table -> table.getTableName().equals(tableName));
    }

    public void addAccessibleTable(DatabaseTable table) {
        this.accessibleTables.add(table);
    }

    public void addCreatedTable(DatabaseTable table) {
        this.createdTables.add(table);
        accessibleTables.add(table); // Creator automatically has access
    }
}
