package org.hinna.payments.controller.api;

import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.dto.PaymentGatewaySettingsRequestDTO;
import org.hinna.payments.dto.PaymentGatewaySettingsResponseDTO;
import org.hinna.payments.dto.ValidationResult;
import org.hinna.payments.model.Account;
import org.hinna.payments.service.AccountService;
import org.hinna.payments.service.impl.MultiTenantStripeApiKeyServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.security.Principal;
import java.time.LocalDateTime;
import java.util.UUID;

@RestController
@RequestMapping("/api/payment-settings")
@Slf4j
public class PaymentSettingsController {

    private final MultiTenantStripeApiKeyServiceImpl stripeApiKeyService;
    private final AccountService accountService;

    @Value("${application.url:https://app.hinna.com}")
    private String applicationUrl;

    @Autowired
    public PaymentSettingsController(MultiTenantStripeApiKeyServiceImpl stripeApiKeyService,
                                     AccountService accountService) {
        this.stripeApiKeyService = stripeApiKeyService;
        this.accountService = accountService;
    }

    /**
     * Get the payment gateway connection status for the current account
     */
    @GetMapping("/connection-status")
    public ResponseEntity<PaymentGatewaySettingsResponseDTO> getConnectionStatus(Principal principal) {
        Account account = accountService.getAccountByEmail(principal.getName())
                .orElseThrow(() -> new IllegalArgumentException("Account not found"));

        return ResponseEntity.ok(this.buildConnectionStatus(account));
    }

    private PaymentGatewaySettingsResponseDTO buildConnectionStatus(Account account) {
        boolean hasApiKey = stripeApiKeyService.hasCustomApiKey(account, "api_key");
        boolean hasWebhookSecret = stripeApiKeyService.hasCustomApiKey(account, "webhook_secret");

        String accountType = this.getAccountType(account);
        String accountId = account.getId().toString();

        return PaymentGatewaySettingsResponseDTO.builder()
                .connected(hasApiKey && hasWebhookSecret)
                .apiKeyConfigured(hasApiKey)
                .webhookSecretConfigured(hasWebhookSecret)
                .provider("stripe")
                .testMode(true) // Could be stored with API key or as separate setting
                .currency("cad") // Could be stored with API key or as separate setting
                .lastConfiguredAt(hasApiKey ? LocalDateTime.now() : null) // Should use actual timestamp from DB
                .status(this.getConnectionStatus(hasApiKey, hasWebhookSecret))
                .accountType(accountType)
                .webhookUrl(String.format("%s/api/stripe/webhooks?accountId=%s", applicationUrl, accountId))
                .build();
    }

    /**
     * Get connection status text
     */
    private String getConnectionStatus(boolean hasApiKey, boolean hasWebhookSecret) {
        if (hasApiKey && hasWebhookSecret) {
            return "active";
        } else if (hasApiKey || hasWebhookSecret) {
            return "partially_configured";
        } else {
            return "not_configured";
        }
    }

    /**
     * Configure payment gateway settings for the current account
     */
    @PostMapping("/configure")
    public ResponseEntity<?> configurePaymentGateway(@RequestBody PaymentGatewaySettingsRequestDTO settings,
                                                     Principal principal) {

        Account account = accountService.getAccountByEmail(principal.getName())
                .orElseThrow(() -> new IllegalArgumentException("Account not found"));

        // Validate and store API key
        ValidationResult apiKeyResult = stripeApiKeyService.validateAndStoreAccountApiKey(
                account,
                "api_key",
                settings.getApiKey()
        );

        if (!apiKeyResult.isValid()) {
            return ResponseEntity.badRequest().body(
                    PaymentGatewaySettingsResponseDTO.builder()
                            .status("error")
                            .connected(false)
                            .accountType(this.getAccountType(account))
                            .build()
            );
        }

        // Validate and store webhook secret if provided
        if (settings.getWebhookSecret() != null && !settings.getWebhookSecret().isEmpty()) {
            ValidationResult webhookResult = stripeApiKeyService.validateAndStoreAccountApiKey(
                    account, "webhook_secret", settings.getWebhookSecret());

            if (webhookResult != null && !webhookResult.isValid()) {
                return ResponseEntity.badRequest().body(
                        PaymentGatewaySettingsResponseDTO.builder()
                                .status("error")
                                .connected(false)
                                .apiKeyConfigured(true)
                                .webhookSecretConfigured(false)
                                .accountType(this.getAccountType(account))
                                .build()
                );
            }
        }

        // Return updated connection status
        PaymentGatewaySettingsResponseDTO response = this.buildConnectionStatus(account);

        // Add success message to response
        response.setStatus("success");

        // Return both validation result and connection status
        return ResponseEntity.ok(response);
    }

    @GetMapping("/account/{accountId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<PaymentGatewaySettingsResponseDTO> getAccountSettings(@PathVariable UUID accountId) {
        Account account = accountService.getAccountById(accountId)
                .orElseThrow(() -> new IllegalArgumentException("Account not found"));

        return ResponseEntity.ok(this.buildConnectionStatus(account));
    }

    /**
     * Configure payment gateway settings for a specific account (admin only)
     */
    @PostMapping("/account/{accountId}/configure")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> configureAccountPaymentGateway(@PathVariable UUID accountId,
                                                            @RequestBody PaymentGatewaySettingsRequestDTO settings) {
        Account account = accountService.getAccountById(accountId)
                .orElseThrow(() -> new IllegalArgumentException("Account not found"));

        // Validate and store API key
        ValidationResult apiKeyResult = stripeApiKeyService.validateAndStoreAccountApiKey(
                account,
                "api_key",
                settings.getApiKey()
        );

        if (!apiKeyResult.isValid()) {
            return ResponseEntity.badRequest().body(
                    PaymentGatewaySettingsResponseDTO.builder()
                            .status("error")
                            .connected(false)
                            .accountType(getAccountType(account))
                            .build()
            );
        }

        // Validate and store webhook secret if provided
        if (settings.getWebhookSecret() != null && !settings.getWebhookSecret().isEmpty()) {
            ValidationResult webhookResult = stripeApiKeyService.validateAndStoreAccountApiKey(
                    account, "webhook_secret", settings.getWebhookSecret());

            if (webhookResult != null && !webhookResult.isValid()) {
                return ResponseEntity.badRequest().body(
                        PaymentGatewaySettingsResponseDTO.builder()
                                .status("error")
                                .connected(false)
                                .apiKeyConfigured(true)
                                .webhookSecretConfigured(false)
                                .accountType(getAccountType(account))
                                .build()
                );
            }
        }

        // Return updated connection status
        PaymentGatewaySettingsResponseDTO response = buildConnectionStatus(account);

        // Add success message to response
        response.setStatus("success");

        return ResponseEntity.ok(response);
    }

    /**
     * Delete payment gateway settings for the current account
     */
    @DeleteMapping("/configure")
    public ResponseEntity<?> deletePaymentGatewaySettings(Principal principal) {
        Account account = accountService.getAccountByEmail(principal.getName())
                .orElseThrow(() -> new IllegalArgumentException("Account not found"));

        // Delete API keys for this account
        boolean apiKeyDeleted = stripeApiKeyService.deleteApiKey(account, "api_key");
        boolean webhookSecretDeleted = stripeApiKeyService.deleteApiKey(account, "webhook_secret");

        if (!apiKeyDeleted && !webhookSecretDeleted) {
            return ResponseEntity.notFound().build();
        }

        ValidationResult result = new ValidationResult(
                true,
                "Payment gateway configuration removed successfully."
        );

        return ResponseEntity.ok(result);
    }

    /**
     * Delete payment gateway settings for a specific account (admin only)
     */
    @DeleteMapping("/account/{accountId}/configure")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteAccountPaymentGatewaySettings(@PathVariable UUID accountId) {
        Account account = accountService.getAccountById(accountId)
                .orElseThrow(() -> new IllegalArgumentException("Account not found"));

        // Delete API keys for this account
        boolean apiKeyDeleted = stripeApiKeyService.deleteApiKey(account, "api_key");
        boolean webhookSecretDeleted = stripeApiKeyService.deleteApiKey(account, "webhook_secret");

        if (!apiKeyDeleted && !webhookSecretDeleted) {
            return ResponseEntity.notFound().build();
        }

        ValidationResult result = new ValidationResult(
                true,
                "Payment gateway configuration removed successfully for " + getAccountTypeDisplay(account) + " account."
        );

        return ResponseEntity.ok(result);
    }

    /**
     * Determines the account type string with meaningful use of pattern variables
     */
    private String getAccountType(Account account) {
        return switch (account) {
            case org.hinna.payments.model.SaaSAccount saasAccount -> {
                // Log or use company name for audit purposes
                String companyName = saasAccount.getCompanyName();
                log.debug("SaaS account for company: {}", companyName);
                yield "saas";
            }
            case org.hinna.payments.model.ResellerAccount resellerAccount -> {
                // Could extract reseller code for additional context
                String resellerCode = resellerAccount.getResellerCode();
                log.debug("Reseller account with code: {}", resellerCode);
                yield "reseller";
            }
            case org.hinna.payments.model.DirectCustomer customer -> {
                // Could extract business info
                String businessName = customer.getBusinessName();
                String businessType = customer.getBusinessType();
                log.debug("Business account: {} ({})", businessName, businessType);
                yield "business";
            }
            case null, default -> "general";
        };
    }

    /**
     * Gets a user-friendly display name for account type with specific details
     */
    private String getAccountTypeDisplay(Account account) {
        return switch (account) {
            case org.hinna.payments.model.SaaSAccount saasAccount -> {
                // Include plan type information for SaaS accounts
                String planType = saasAccount.getPlanType();
                yield "SaaS (" + planType + ")";
            }
            case org.hinna.payments.model.ResellerAccount resellerAccount -> {
                // Include commission rate for additional context
                BigDecimal commissionRate = resellerAccount.getCommissionRate();
                yield "Reseller (" + commissionRate + "% commission)";
            }
            case org.hinna.payments.model.DirectCustomer customer -> {
                // Include business type for better context
                String businessType = customer.getBusinessType() != null ?
                        customer.getBusinessType() : "Unspecified";
                yield "Business (" + businessType + ")";
            }
            case null, default -> "General";
        };
    }
}
