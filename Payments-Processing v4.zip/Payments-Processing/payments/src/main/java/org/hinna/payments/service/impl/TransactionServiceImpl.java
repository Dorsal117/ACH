package org.hinna.payments.service.impl;

import org.hinna.payments.dto.TransactionDTO;
import org.hinna.payments.dto.TransactionGroupDTO;
import org.hinna.payments.model.Invoice;
import org.hinna.payments.model.InvoiceItem;
import org.hinna.payments.model.Payment;
import org.hinna.payments.model.PaymentMethod;
import org.hinna.payments.repository.InvoiceRepository;
import org.hinna.payments.repository.PaymentRepository;
import org.hinna.payments.repository.ServiceRepository;
import org.hinna.payments.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.TextStyle;
import java.util.*;
import java.util.stream.Collectors;
import java.time.LocalDate;
import java.util.Locale;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final PaymentRepository paymentRepository;
    private final ServiceRepository serviceRepository;
    private final InvoiceRepository invoiceRepository;

    @Autowired
    public TransactionServiceImpl(PaymentRepository paymentRepository,
                                  ServiceRepository serviceRepository,
                                  InvoiceRepository invoiceRepository) {
        this.paymentRepository = paymentRepository;
        this.serviceRepository = serviceRepository;
        this.invoiceRepository = invoiceRepository;
    }

    @Override
    public List<TransactionGroupDTO> getTransactionsGroupedByMonth(int year, String searchTerm) {
        // Get all payments for the specified year
        LocalDateTime startOfYear = LocalDateTime.of(year, 1, 1, 0, 0);
        LocalDateTime endOfYear = LocalDateTime.of(year, 12, 31, 23, 59, 59);

        List<Payment> allPayments = paymentRepository.findByCreatedAtBetween(startOfYear, endOfYear);

        List<TransactionDTO> allTransactions = allPayments.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());

        if (searchTerm != null && !searchTerm.trim().isEmpty()) {
            String lowered = searchTerm.toLowerCase();

            allTransactions = allTransactions.stream()
                    .filter(txn ->
                            (txn.getClientName() != null && txn.getClientName().toLowerCase().contains(lowered)) ||
                                    (txn.getService() != null && txn.getService().toLowerCase().contains(lowered)) ||
                                    getMonthName(txn.getDate()).toLowerCase().contains(lowered)
                    )
                    .collect(Collectors.toList());
        }

        Map<Integer, TransactionGroupDTO> groupsByMonth = new HashMap<>();
        for (int month = 1; month <= 12; month++) {
            TransactionGroupDTO group = new TransactionGroupDTO(year, month);
            LocalDateTime now = LocalDateTime.now();
            group.setCurrentMonth(now.getYear() == year && now.getMonthValue() == month);
            groupsByMonth.put(month, group);
        }

        for (TransactionDTO txn : allTransactions) {
            int month = txn.getDate().getMonthValue();
            groupsByMonth.get(month).addTransaction(txn);
        }

        for (TransactionGroupDTO group : groupsByMonth.values()) {
            group.getTransactions().sort(Comparator.comparing(TransactionDTO::getDate).reversed());
        }

        return groupsByMonth.values().stream()
                .filter(group -> !group.getTransactions().isEmpty())
                .sorted(Comparator.comparing(TransactionGroupDTO::getMonth).reversed())
                .collect(Collectors.toList());
    }

    private String getMonthName(LocalDateTime date) {
        return date.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH); // e.g. "March"
    }

    @Override
    public TransactionDTO getTransactionById(UUID id) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment not found with id: " + id));
        return this.convertToDTO(payment);
    }

    private TransactionDTO convertToDTO(Payment payment) {
        TransactionDTO dto = new TransactionDTO();

        dto.setId(payment.getId());
        dto.setDate(payment.getCreatedAt());
        dto.setAmount(payment.getAmount());
        dto.setStatus(String.valueOf(payment.getStatus()));
        dto.setReferenceNumber(payment.getReferenceNumber());
        dto.setDescription(payment.getDescription());

        Optional<Invoice> invoiceOpt = invoiceRepository.findByPayment(payment);

        if (invoiceOpt.isPresent()) {
            Invoice invoice = invoiceOpt.get();
            if (!invoice.getItems().isEmpty()) {
                InvoiceItem firstItem = invoice.getItems().getFirst();

                if (firstItem.getServiceId() != null) {
                    Optional<org.hinna.payments.model.Service> serviceOpt = serviceRepository.findById(firstItem.getServiceId());
                    dto.setService(serviceOpt.map(org.hinna.payments.model.Service::getName).orElse(firstItem.getDescription()));
                } else {
                    dto.setService(firstItem.getDescription());
                }
            }
        } else if (payment.getDescription() != null && !payment.getDescription().isEmpty()) {
            dto.setService(payment.getDescription());
        } else {
            dto.setService("Payment Transaction");
        }

        if (payment.getCustomer() != null) {
            dto.setClientName(payment.getCustomer().getFullName());
        }

        if (payment.getMethod() != null) {
            PaymentMethod method = payment.getMethod();
            dto.setPaymentMethodType(method.getType().getDisplayName());
            dto.setLastFourDigits(method.getLastFourDigits());
        }

        return dto;
    }
}
