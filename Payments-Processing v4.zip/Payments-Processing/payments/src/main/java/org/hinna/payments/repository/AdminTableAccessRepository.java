package org.hinna.payments.repository;

import org.hinna.payments.model.Admin;
import org.hinna.payments.model.AdminTableAccess;
import org.hinna.payments.model.DatabaseTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface AdminTableAccessRepository extends JpaRepository<AdminTableAccess, UUID> {
    List<AdminTableAccess> findByAdmin(Admin admin);
    List<AdminTableAccess> findByDatabaseTable(DatabaseTable databaseTable);
    Optional<AdminTableAccess> findByAdminAndDatabaseTable(Admin admin, DatabaseTable databaseTable);
    List<AdminTableAccess> findByAccessLevel(AdminTableAccess.AccessLevel accessLevel);
    List<AdminTableAccess> findByIsCreatorTrue();
}
