package org.hinna.payments.model.enums;

public enum PaymentStatus {
    PENDING,
    PROCESSING,
    COMPLETED,
    FAILED,
    REFUNDED,
    PARTIAL_REFUNDED,
    CANCELLED,
    PENDING_APPROVAL,
    REJECTED
}
