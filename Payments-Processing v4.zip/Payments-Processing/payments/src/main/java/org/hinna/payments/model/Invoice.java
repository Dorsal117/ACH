package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;
import org.hinna.payments.model.enums.InvoiceStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "invoice")
@Getter
@Setter
@NoArgsConstructor
public class Invoice {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "invoice_number", unique = true)
    private String invoiceNumber;

    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false)
    private Account customer;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private InvoiceStatus status;

    @Column(nullable = false)
    private BigDecimal subtotal;

    @Column(nullable = false)
    private BigDecimal taxAmount;

    @Column(nullable = false)
    private BigDecimal totalAmount;

    @Column(nullable = false)
    private LocalDateTime issueDate;

    @Column(nullable = false)
    private LocalDateTime dueDate;

    private String notes;

    @OneToMany(mappedBy = "invoice", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<InvoiceItem> items = new ArrayList<>();

    @OneToOne
    @JoinColumn(name = "payment_id")
    private Payment payment;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column
    private LocalDateTime updatedAt;

    @Column
    private LocalDateTime paidAt;

    public Invoice(Account customer, LocalDateTime issueDate, LocalDateTime dueDate) {
        this.customer = customer;
        this.invoiceNumber = this.generateInvoiceNumber();
        this.issueDate = issueDate;
        this.dueDate = dueDate;
        this.status = InvoiceStatus.DRAFT;
        this.subtotal = BigDecimal.ZERO;
        this.totalAmount = BigDecimal.ZERO;
    }

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Add an item to the invoice
     * @param item The item to add
     * @return The updated invoice
     */
    public Invoice addItem(InvoiceItem item) {
        item.setInvoice(this);
        items.add(item);
        this.recalculateTotals();
        return this;
    }

    /**
     * Remove an item from the invoice
     * @param item The item to remove
     * @return The updated invoice
     */
    public Invoice removeItem(InvoiceItem item) {
        item.setInvoice(null);
        items.remove(item);
        this.recalculateTotals();
        return this;
    }

    /**
     * Recalculate invoice totals based on items
     */
    public void recalculateTotals() {
        this.subtotal = items.stream()
                .map(item -> item.getPrice().multiply(new BigDecimal(item.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        this.taxAmount = items.stream()
                .map(item -> {
                    BigDecimal itemTotal = item.getPrice().multiply(new BigDecimal(item.getQuantity()));
                    return itemTotal.multiply(item.getTaxRate()).divide(new BigDecimal(100));
                })
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        this.totalAmount = this.subtotal.add(this.taxAmount);
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Generate a unique invoice number
     * Format: INV-{timestamp}-{random}
     * @return The generated invoice number
     */
    private String generateInvoiceNumber() {
        long timestamp = System.currentTimeMillis();
        int random = (int) (Math.random() * 1000);
        return String.format("INV-%d-%03d", timestamp, random);
    }

    /**
     * Mark the invoice as issued
     */
    public void issue() {
        if (this.status != InvoiceStatus.DRAFT) {
            throw new IllegalArgumentException("Invoice must be in DRAFT state to be issued");
        }
        this.status = InvoiceStatus.ISSUED;
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Mark the invoice as paid and associate payment
     * @param payment The payment that paid this invoice
     */
    public void markAsPaid(Payment payment) {
        if (this.status != InvoiceStatus.ISSUED) {
            throw new IllegalArgumentException("Invoice must be in ISSUED state to be marked as paid");
        }
        this.status = InvoiceStatus.PAID;
        this.payment = payment;
        this.paidAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Mark the invoice as cancelled
     */
    public void cancel() {
        if (this.status == InvoiceStatus.PAID) {
            throw new IllegalArgumentException("Paid invoices cannot be cancelled");
        }
        this.status = InvoiceStatus.CANCELLED;
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Mark the invoice as overdue
     */
    public void markAsOverdue() {
        if (this.status != InvoiceStatus.ISSUED) {
            throw new IllegalArgumentException("Only issued invoices can be marked as overdue");
        }
        this.status = InvoiceStatus.OVERDUE;
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Check if the invoice is overdue
     * @return true if the invoice is due, false otherwise
     */
    public boolean isDue() {
        return LocalDateTime.now().isAfter(this.dueDate) &&
                this.status == InvoiceStatus.ISSUED;
    }
}
