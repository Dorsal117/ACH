package org.hinna.payments.repository;

import org.hinna.payments.model.DirectCustomer;
import org.hinna.payments.model.Staff;
import org.hinna.payments.model.StaffGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface StaffRepository extends JpaRepository<Staff, UUID> {
    List<Staff> findByEmployer(DirectCustomer employer);
    List<Staff> findByStaffGroup(StaffGroup staffGroup);
    List<Staff> findByDepartment(String department);
    List<Staff> findByPositionAndDepartment(String position, String department);
    List<Staff> findByIsAdminTrue();
}