package org.hinna.payments.dto;

import lombok.Data;

/**
 * Simple DTO for displaying payroll data in the frontend
 */
@Data
public class PayrollDisplayDTO {
    private String id;
    private String staffName;
    private String role;
    private String paymentDate;
    private String salary;
    private String paymentMethod;
}
