package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * "Reverse API call".
 * Instead of the application constantly asking Stripe 'Has this payment completed yet?',
 * Stripe sends an HTTP POST request to a URL specified (webhook endpoint) whenever something important happens
 */

@Entity
@Table(name = "stripe_webhook_event")
@Getter
@Setter
@NoArgsConstructor
public class StripeWebhookEvent {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "stripe_event_id", nullable = false, unique = true)
    private String stripeEventId;

    @Column(name = "event_type")
    private String eventType;

    @Column(name = "payload", columnDefinition = "TEXT", nullable = false)
    private String payload;

    @Column(name = "processed", nullable = false)
    private Boolean processed;

    @Column(name = "received_at", nullable = false)
    private LocalDateTime receivedAt;

    @Column(name = "processed_at")
    private LocalDateTime processedAt;

    public StripeWebhookEvent(String stripeEventId, String eventType, String payload) {
        this.stripeEventId = stripeEventId;
        this.eventType = eventType;
        this.payload = payload;
        this.processed = false;
        this.receivedAt = LocalDateTime.now();
    }

    public void markAsProcessed() {
        this.processed = true;
        this.processedAt = LocalDateTime.now();
    }
}
