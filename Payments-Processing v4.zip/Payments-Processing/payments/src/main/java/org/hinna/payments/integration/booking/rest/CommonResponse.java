package org.hinna.payments.integration.booking.rest;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommonResponse<T> {
    private boolean success;
    private String message;
    private T data;
    private int code;
}
