package org.hinna.payments.repository;

import org.hinna.payments.model.AdminGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

import java.util.List;

@Repository
public interface AdminGroupRepository extends JpaRepository<AdminGroup, UUID> {
    Optional<AdminGroup> findByGroupName(String name);
    List<AdminGroup> findByTypesContaining(String type);
    List<AdminGroup> findByIsActiveTrue();
}