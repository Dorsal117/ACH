package org.hinna.payments.integration.user.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class AutomaticPaymentSettingsDTO {
    private boolean retryFailedPayments = true;
    private Integer retryAttempts = 3;
    private boolean chargeForRetry = false;
    private BigDecimal retryChargeAmount = new BigDecimal("0.00");
    private boolean doNotRetry = false;
    private String nonRetryReasons = "Insufficient funds, Credit card is expired, No such issuer";
    private boolean autoChargeNegativeBalance = false;
    private String autoChargeDay = "Thursday";
    private String autoChargeFrequency = "every";
    private boolean combineClientPayments = false;
}
