package org.hinna.payments.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.function.Function;

/**
 * Service decoding and extracting information from JWT tokens.
 */
@Component
public class JwtDecoder {

    @Value("${jwt.secret}")
    private String secret;

    /**
     * Extract user ID from JWT Token
     */
    public Long getUserIdFromToken(String token) {
        return Long.parseLong(this.getClaimFromToken(token, Claims::getSubject));
    }

    /**
     * Extract expiration date from JWT token
     */
    public Date getExpirationDateFromToken(String token) {
        return this.getClaimFromToken(token, Claims::getExpiration);
    }

    /**
     * Extract role from JWT token
     */
    public String getRoleFromToken(String token) {
        return this.getClaimFromToken(token, claims -> claims.get("role", String.class));
    }

    /**
     * Check if the token has expired
     */
    public Boolean isTokenExpired(String token) {
        final Date expiration = getExpirationDateFromToken(token);
        return expiration.before(new Date());
    }

    /**
     * Extract claim from token
     */    public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = this.getAllClaimsFromToken(token);
        return claimsResolver.apply(claims);
    }

    /**
     * Get all claims from token
     */
    private Claims getAllClaimsFromToken(String token) {
        return Jwts.parser()
                .verifyWith(Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8)))
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }
}
