package org.hinna.payments.service.impl;

import jakarta.transaction.Transactional;
import org.hinna.payments.model.AdminGroup;
import org.hinna.payments.model.Permission;
import org.hinna.payments.repository.AdminGroupRepository;
import org.hinna.payments.repository.PermissionRepository;
import org.hinna.payments.service.AdminGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AdminGroupServiceImpl implements AdminGroupService {

    private final AdminGroupRepository adminGroupRepository;
    private final PermissionRepository permissionRepository;

    @Autowired
    public AdminGroupServiceImpl(AdminGroupRepository adminGroupRepository, PermissionRepository permissionRepository) {
        this.adminGroupRepository = adminGroupRepository;
        this.permissionRepository = permissionRepository;
    }

    @Override
    @Transactional
    public AdminGroup createAdminGroup(AdminGroup adminGroup) {
        if (adminGroupRepository.findByGroupName(adminGroup.getGroupName()).isPresent()) {
            throw new IllegalArgumentException("Admin group with this name already exists");
        }
        return adminGroupRepository.save(adminGroup);
    }

    @Override
    public Optional<AdminGroup> getAdminGroupById(UUID id) {
        return adminGroupRepository.findById(id);
    }

    @Override
    public Optional<AdminGroup> getAdminGroupByName(String name) {
        return adminGroupRepository.findByGroupName(name);
    }

    @Override
    public Page<AdminGroup> getAllAdminGroups(Pageable pageable) {
        return adminGroupRepository.findAll(pageable);
    }

    @Override
    public List<AdminGroup> getActiveAdminGroups() {
        return adminGroupRepository.findByIsActiveTrue();
    }

    @Override
    public List<AdminGroup> getAdminGroupsByType(String groupType) {
        return adminGroupRepository.findByTypesContaining(groupType);
    }

    @Override
    public AdminGroup updateAdminGroup(UUID id, AdminGroup adminGroupDetails) {
        return adminGroupRepository.findById(id)
                .map(adminGroup -> {
                    // Check if name is being changed and is not already taken
                    if (!adminGroup.getGroupName().equals(adminGroupDetails.getGroupName()) &&
                            adminGroupRepository.findByGroupName(adminGroupDetails.getGroupName()).isPresent()) {
                        throw new IllegalArgumentException("Admin group with name " +
                                adminGroupDetails.getGroupName() + " already exists");
                    }

                    adminGroup.setGroupName(adminGroupDetails.getGroupName());
                    adminGroup.setBasePermissions(adminGroupDetails.getBasePermissions());
                    adminGroup.setTypes(adminGroupDetails.getTypes());
                    adminGroup.setActive(adminGroupDetails.isActive());
                    return adminGroupRepository.save(adminGroup);
                })
                .orElseThrow(() -> new IllegalArgumentException("Admin group not found"));
    }

    @Override
    @Transactional
    public void deleteAdminGroup(UUID id) {
        adminGroupRepository.deleteById(id);
    }

    @Override
    @Transactional
    public AdminGroup addPermission(UUID groupId, UUID permissionId) {
        AdminGroup adminGroup = adminGroupRepository.findById(groupId)
                .orElseThrow(() -> new IllegalArgumentException("Admin group not found with id: " + groupId));

        Permission permission = permissionRepository.findById(permissionId)
                .orElseThrow(() -> new IllegalArgumentException("Permission not found with id: " + permissionId));

        adminGroup.getPermissions().add(permission);
        return adminGroupRepository.save(adminGroup);
    }

    @Override
    public AdminGroup removePermission(UUID groupId, UUID permissionId) {
        AdminGroup adminGroup = adminGroupRepository.findById(groupId)
                .orElseThrow(() -> new IllegalArgumentException("Admin group not found with id: " + groupId));

        Permission permission = permissionRepository.findById(permissionId)
                .orElseThrow(() -> new IllegalArgumentException("Permission not found with id: " + permissionId));

        adminGroup.getPermissions().remove(permission);
        return adminGroupRepository.save(adminGroup);
    }

    @Override
    public Set<Permission> getGroupPermissions(UUID groupId) {
        AdminGroup adminGroup = adminGroupRepository.findById(groupId)
                .orElseThrow(() -> new IllegalArgumentException("Admin group not found with id: " + groupId));

        return new HashSet<>(adminGroup.getPermissions());
    }

    @Override
    public boolean hasPermission(UUID groupId, String permissionName) {
        AdminGroup adminGroup = adminGroupRepository.findById(groupId)
                .orElseThrow(() -> new IllegalArgumentException("Admin group not found with id: " + groupId));

        return adminGroup.hasPermission(permissionName);
    }
}
