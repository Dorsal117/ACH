package org.hinna.payments.dto;

import lombok.Data;

import java.util.UUID;

@Data
public class ConfirmSetupIntentRequest {
    private String setupIntentId;
    private UUID accountId;
    private Boolean isDefault;
}
