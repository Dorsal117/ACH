package org.hinna.payments.integration.user.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Event sent when a user is created in the UserService
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserCreatedEvent {
    private Long userId;
    private String firstName;
    private String lastName;
    private String email;
    private String role;
    private String businessName;
    private String companyName;
    private String taxId;
}
