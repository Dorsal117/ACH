package org.hinna.payments.controller;

import org.hinna.payments.service.PayrollService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/settings")
public class SettingsController {

    private final PayrollService payrollService;

    @Autowired
    public SettingsController(PayrollService payrollService) {
        this.payrollService = payrollService;
    }

    @GetMapping("/page")
    public String getPaymentsPage(Model model) {
        model.addAttribute("pageTitle", "Payments & Processors");
        model.addAttribute("content", "PaymentProcessors");
        return "layout";
    }

    @GetMapping("/currencies")
    public String getCurrenciesPage(Model model) {
        model.addAttribute("pageTitle", "Currencies & Taxes");
        model.addAttribute("content", "CurrenciesTaxes");
        return "layout";
    }

    @GetMapping("/processors")
    public String getProcessorsPage(Model model) {
        model.addAttribute("pageTitle", "Payments & Processors");
        model.addAttribute("content", "PaymentProcessors");
        return "layout";
    }

    @GetMapping("/autopayment")
    public String getAutoPaymentPage(Model model) {
        model.addAttribute("pageTitle", "Autopayments");
        model.addAttribute("content", "Autopayment");
        return "layout";
    }

//    @GetMapping("/payroll")
//    public String getPayrollPage(Model model) {
//        model.addAttribute("pageTitle", "Payrolls");
//        model.addAttribute("content", "Payroll");
//        model.addAttribute("payrolls", payrollService.getAllPayrolls());
//        return "layout";
//    }
}
