package org.hinna.payments.service.impl;

import jakarta.transaction.Transactional;
import org.hinna.payments.model.Permission;
import org.hinna.payments.model.StaffGroup;
import org.hinna.payments.repository.PermissionRepository;
import org.hinna.payments.repository.StaffGroupRepository;
import org.hinna.payments.service.StaffGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class StaffGroupServiceImpl implements StaffGroupService {

    private final StaffGroupRepository staffGroupRepository;
    private final PermissionRepository permissionRepository;

    @Autowired
    public StaffGroupServiceImpl(StaffGroupRepository staffGroupRepository, PermissionRepository permissionRepository) {
        this.staffGroupRepository = staffGroupRepository;
        this.permissionRepository = permissionRepository;
    }

    @Override
    @Transactional
    public StaffGroup createStaffGroup(StaffGroup staffGroup) {
        if (staffGroupRepository.findByGroupName(staffGroup.getGroupName()).isPresent()) {
            throw new IllegalArgumentException("Staff group with this name already exists");
        }
        return staffGroupRepository.save(staffGroup);
    }

    @Override
    public Optional<StaffGroup> getStaffGroupById(UUID id) {
        return staffGroupRepository.findById(id);
    }

    @Override
    public Optional<StaffGroup> getStaffGroupByName(String name) {
        return staffGroupRepository.findByGroupName(name);
    }

    @Override
    public Page<StaffGroup> getAllStaffGroups(Pageable pageable) {
        return staffGroupRepository.findAll(pageable);
    }

    @Override
    public List<StaffGroup> getActiveStaffGroups() {
        return staffGroupRepository.findByIsActiveTrue();
    }

    @Override
    @Transactional
    public StaffGroup updateStaffGroup(UUID groupId, StaffGroup staffGroupDetails) {
        return staffGroupRepository.findById(groupId)
                .map(existingGroup -> {
                    // Check if name is being changed and is not already taken
                    if (!existingGroup.getGroupName().equals(staffGroupDetails.getGroupName()) &&
                            staffGroupRepository.findByGroupName(staffGroupDetails.getGroupName()).isPresent()) {
                        throw new IllegalArgumentException("Staff group with this name already exists");
                    }
                    existingGroup.setGroupName(staffGroupDetails.getGroupName());
                    existingGroup.setDescription(staffGroupDetails.getDescription());
                    existingGroup.setActive(staffGroupDetails.isActive());
                    existingGroup.setAdminId(staffGroupDetails.getAdminId());

                    return staffGroupRepository.save(existingGroup);
                })
                .orElseThrow(() -> new IllegalArgumentException("Staff group not found"));
    }

    @Override
    @Transactional
    public void deleteStaffGroup(UUID groupId) {
        staffGroupRepository.deleteById(groupId);
    }

    @Override
    @Transactional
    public StaffGroup addPermission(UUID groupId, UUID permissionId) {
        StaffGroup staffGroup = staffGroupRepository.findById(groupId)
                .orElseThrow(() -> new IllegalArgumentException("Staff group not found"));

        Permission permission = permissionRepository.findById(permissionId)
                .orElseThrow(() -> new IllegalArgumentException("Permission not found"));

        staffGroup.getPermissions().add(permission);
        return staffGroupRepository.save(staffGroup);
    }

    @Override
    public StaffGroup removePermission(UUID groupId, UUID permissionId) {
        StaffGroup staffGroup = staffGroupRepository.findById(groupId)
                .orElseThrow(() -> new IllegalArgumentException("Staff group not found"));

        Permission permission = permissionRepository.findById(permissionId)
                .orElseThrow(() -> new IllegalArgumentException("Permission not found"));

        staffGroup.getPermissions().remove(permission);
        return staffGroupRepository.save(staffGroup);
    }

    @Override
    public Set<Permission> getPermissionsByGroupId(UUID groupId) {
        StaffGroup staffGroup = staffGroupRepository.findById(groupId)
                .orElseThrow(() -> new IllegalArgumentException("Staff group not found"));

        return new HashSet<>(staffGroup.getPermissions());
    }

    @Override
    public boolean hasPermission(UUID groupId, String permissionName) {
        StaffGroup staffGroup = staffGroupRepository.findById(groupId)
                .orElseThrow(() -> new IllegalArgumentException("Staff group not found"));

        return staffGroup.hasPermission(permissionName);
    }
}
