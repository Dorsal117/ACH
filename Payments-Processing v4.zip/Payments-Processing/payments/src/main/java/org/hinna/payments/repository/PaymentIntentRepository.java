package org.hinna.payments.repository;

import org.hinna.payments.model.Payment;
import org.hinna.payments.model.PaymentIntent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface PaymentIntentRepository extends JpaRepository<PaymentIntent, UUID> {

    /**
     * Find a payment intent by its Stripe ID
     *
     * @param stripeIntentId the Stripe payment intent ID
     * @return on Optional containing the payment intent if found
     */
    Optional<PaymentIntent> findByStripeIntentId(String stripeIntentId);

    Optional<PaymentIntent> findByPayment(Payment payment);
}
