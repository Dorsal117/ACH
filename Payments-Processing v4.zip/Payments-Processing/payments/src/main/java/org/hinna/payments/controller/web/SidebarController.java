package org.hinna.payments.controller.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SidebarController {
    @GetMapping("/partials/sidebar-settings.html")
    public String getSidebarPartial() {
        return "partials/sidebar-settings"; // No `.html`
    }
}
