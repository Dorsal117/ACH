package org.hinna.payments.integration.pat;

import org.hinna.payments.integration.config.RabbitMQConfig;
import org.hinna.payments.model.Payroll;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Service to integrate payroll and refund processing with PAT
 */
@Service
public class PayrollPATIntegrationService {

    private final RabbitTemplate rabbitTemplate;
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Autowired
    public PayrollPATIntegrationService(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    /**
     * Creates a workflow in PAT for scheduled payroll processing
     * @param employerId Employer account ID
     * @param scheduleId They payroll schedule ID
     * @return UUI of the created workflow
     */
    public UUID createPayrollScheduleWorkflow(UUID employerId, UUID scheduleId) {
        // Create a workflow with scheduled trigger for payroll processing
        Map<String, Object> workflowData = new HashMap<>();
        workflowData.put("workflow_name", "Payroll Processing Workflow");
        workflowData.put("account_id", employerId.toString());
        workflowData.put("schedule_id", scheduleId.toString());
        workflowData.put("isEnabled", true);
        workflowData.put("steps", this.createPayrollProcessingSteps());

        // Send workflow creation request
        return (UUID) rabbitTemplate.convertSendAndReceive(
                RabbitMQConfig.PAT_EXCHANGE,
                "workflow.create",
                workflowData,
                message -> {
                    // Set message properties if needed
                    return message;
                }
        );
    }

    /**
     * Triggers a payroll processing workflow
     * @param payrollId The payroll ID to process
     */
    public void triggerPayrollProcessingWorkflow(UUID payrollId, Payroll payroll) {
        Map<String, Object> message = new HashMap<>();
        message.put("trigger_type", "PAYROLL_PROCESS");
        message.put("payroll_id", payrollId.toString());
        message.put("employee_id", payroll.getEmployee().getId().toString());
        message.put("employer_id", payroll.getProcessingAccount().getId().toString());
        message.put("amount", payroll.getGrossAmount());
        message.put("payment_method_id", payroll.getPaymentMethod() != null ?
                payroll.getPaymentMethod().getId().toString() : null);
        message.put("description", payroll.getDescription());
        message.put("scheduled_date", payroll.getScheduledDate() != null ?
                payroll.getScheduledDate().format(DATE_FORMATTER) : null);

        rabbitTemplate.convertAndSend(
                RabbitMQConfig.PAT_EXCHANGE,
                RabbitMQConfig.PAT_WORKFLOW_EXECUTE_KEY,
                message
        );
    }

    /**
     * Helper methods to create workflow components
     */
    private Map<String, Object> createPayrollProcessingSteps() {
        // Create a map of steps for payroll processing
        Map<String, Object> steps = new HashMap<>();

        // Payroll processing step
        Map<String, Object> processStep = new HashMap<>();
        processStep.put("step_type", "PAYROLL_PROCESS");

        // Notification step
        Map<String, Object> notifyStep = new HashMap<>();
        notifyStep.put("step_type", "EMAIL");
        notifyStep.put("subject", "Payroll Processing Notification");
        notifyStep.put("body", "Your payroll has been processed.");

        // Conditional for success/failure
        Map<String, Object> conditional = new HashMap<>();
        conditional.put("expression", "payroll.status === 'COMPLETED");

        // Add steps to workflow
        steps.put("process", processStep);
        steps.put("notify", notifyStep);
        steps.put("check_result", conditional);

        return steps;
    }

    /**
     * Create a payroll notification step
     * @param payroll The payroll to notify about
     */
    public void createPayrollNotificationStep(Payroll payroll) {
        Map<String, Object> stepData = new HashMap<>();
        stepData.put("step_type", "EMAIL");
        stepData.put("recipient_id", payroll.getEmployee().getId().toString());
        stepData.put("email", payroll.getEmployee().getEmail());
        stepData.put("body", createPayrollEmailBody(payroll));
        stepData.put("subject", "Payroll Notification: " + payroll.getReferenceNumber());

        rabbitTemplate.convertAndSend(
                RabbitMQConfig.PAT_EXCHANGE,
                RabbitMQConfig.PAT_STEP_EXECUTE_KEY,
                stepData
        );
    }

    private String createPayrollEmailBody(Payroll payroll) {
        return "Dear " + payroll.getEmployee().getFullName() + ",\n\n" +
                "This is a notification about payroll " + payroll.getReferenceNumber() + ".\n" +
                "Gross Amount: " + payroll.getGrossAmount() + "\n" +
                "Net Amount: " + payroll.getNetAmount() + "\n" +
                "Tax Withheld: " + payroll.getTaxWithheld() + "\n" +
                "Deductions: " + payroll.getDeductions() + "\n" +
                "Status: " + payroll.getStatus() + "\n\n" +
                "Payment Period: " +
                (payroll.getPayPeriodStart() != null ? payroll.getPayPeriodStart().format(DATE_FORMATTER) : "N/A") +
                " to " +
                (payroll.getPayPeriodEnd() != null ? payroll.getPayPeriodEnd().format(DATE_FORMATTER) : "N/A") + "\n\n" +
                "Thank you for your service.";
    }
}
