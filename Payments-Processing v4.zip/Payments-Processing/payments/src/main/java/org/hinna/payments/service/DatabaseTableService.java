package org.hinna.payments.service;

import org.hinna.payments.model.DatabaseTable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;
import java.util.UUID;

public interface DatabaseTableService {
    DatabaseTable createDatabaseTable(DatabaseTable databaseTable);
    Optional<DatabaseTable> getDatabaseTableById(UUID id);
    Optional<DatabaseTable> getDatabaseTableByName(String tableName);
    Page<DatabaseTable> getAllDatabaseTables(Pageable pageable);
    DatabaseTable updateDatabaseTable(UUID id, DatabaseTable databaseTableDetails);
    void deleteDatabaseTable(UUID id);
    boolean existsByTableName(String tableName);
}
