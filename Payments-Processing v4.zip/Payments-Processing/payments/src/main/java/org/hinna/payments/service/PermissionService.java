package org.hinna.payments.service;

import org.hinna.payments.model.Permission;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface PermissionService {
    Permission createPermission(Permission permission);
    Optional<Permission> getPermissionById(UUID id);
    Optional<Permission> getPermissionByName(String name);
    Page<Permission> getAllPermissions(Pageable pageable);
    List<Permission> getPermissionsByResourceType(String resourceType);
    Permission updatePermission(UUID id, Permission permissionDetails);
    void deletePermission(UUID id);
    boolean existsByName(String name);
}
