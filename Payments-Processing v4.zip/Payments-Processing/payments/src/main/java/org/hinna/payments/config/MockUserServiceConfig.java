package org.hinna.payments.config;

import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.client.UserServiceClient;
import org.hinna.payments.exception.ServiceUnavailableException;
import org.hinna.payments.integration.user.dto.UserDTO;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.util.List;

/**
 * Mock configuration for Login-Register microservice when running in development mode
 * Activated by settings: 'spring.profiles.active=dev-mock
 */
@Configuration
@ConditionalOnProperty(name = "hinna.integration.user.mock", havingValue = "true", matchIfMissing = false)
@Slf4j
public class MockUserServiceConfig {

    @Bean
    @Primary
    public UserServiceClient mockUserServiceClient() {
        return new MockUserServiceClient();
    }

    public static class MockUserServiceClient extends UserServiceClient {

        public MockUserServiceClient() {
            super(null, "http://mock-user-service");
        }

        @Override
        public String authenticate(String email, String password) {
            log.info("Mock authentication for email: {}", email);

            // Return a mock JWT token
            return "mock-jwt-token-" + System.currentTimeMillis();
        }

        @Override
        public UserDTO getUserByEmail(String email) throws ServiceUnavailableException {
            log.info("Mock getUserByEmail for email: {}", email);

            // Return mock user data
            UserDTO mockUser = new UserDTO();
            mockUser.setUserId(12345L);
            mockUser.setFirstName("Mock");
            mockUser.setLastName("User");
            mockUser.setEmail(email);
            mockUser.setRole("BUSINESS");
            mockUser.setActive(true);
            mockUser.setBusinessName("Mock Business");
            mockUser.setPhoneNumber("555-0100");
            mockUser.setAddress("123 Mock Street");
            mockUser.setCity("Mock City");
            mockUser.setProvince("Mock Province");
            mockUser.setPostalCode("M0C K1N");
            mockUser.setCountry("Canada");

            return mockUser;
        }


        @Override
        public UserDTO getUserById(Long userId) throws ServiceUnavailableException {
            log.info("Mock getUserById for userId: {}", userId);

            // Return mock user data
            UserDTO mockUser = new UserDTO();
            mockUser.setUserId(userId);
            mockUser.setFirstName("Mock");
            mockUser.setLastName("User" + userId);
            mockUser.setEmail("mock.user" + userId + "@example.com");
            mockUser.setRole("BUSINESS");
            mockUser.setActive(true);
            mockUser.setBusinessName("Mock Business " + userId);
            mockUser.setPhoneNumber("555-010" + userId);
            mockUser.setAddress("123 Mock Street");
            mockUser.setCity("Mock City");
            mockUser.setProvince("Mock Province");
            mockUser.setPostalCode("M0C K1N");
            mockUser.setCountry("Canada");

            return mockUser;
        }

        @Override
        public List<UserDTO> getUsersByRole(String role) throws ServiceUnavailableException {
            log.info("Mock getUsersByRole for role: {}", role);

            // Return mock list with multiple users
            UserDTO mockUser1 = new UserDTO();
            mockUser1.setUserId(12345L);
            mockUser1.setFirstName("Mock");
            mockUser1.setLastName("User 1");
            mockUser1.setEmail("mock.user1@example.com");
            mockUser1.setRole(role);
            mockUser1.setActive(true);
            mockUser1.setPhoneNumber("555-0101");

            UserDTO mockUser2 = new UserDTO();
            mockUser2.setUserId(12346L);
            mockUser2.setFirstName("Mock");
            mockUser2.setLastName("User 2");
            mockUser2.setEmail("mock.user2@example.com");
            mockUser2.setRole(role);
            mockUser2.setActive(true);
            mockUser2.setPhoneNumber("555-0102");

            // Set role-specific fields
            if ("BUSINESS".equals(role)) {
                mockUser1.setBusinessName("Mock Business 1");
                mockUser2.setBusinessName("Mock Business 2");
            } else if ("RESELLER".equals(role)) {
                mockUser1.setCompanyName("Mock Reseller Company 1");
                mockUser2.setCompanyName("Mock Reseller Company 2");
            } else if ("SAAS".equals(role)) {
                mockUser1.setCompanyName("Mock SaaS Company 1");
                mockUser2.setCompanyName("Mock SaaS Company 2");
            }

            return List.of(mockUser1, mockUser2);
        }

        @Override
        public boolean isHealthy() {
            log.debug("Mock health check - always healthy");
            return true; // Always healthy in mock mode
        }

        @Override
        public boolean validateToken(String token) {
            log.debug("Mock token validation for token: {}", token);

            // Always return true for mock tokens
            return token != null && token.startsWith("mock-jwt-token");
        }
    }
}
