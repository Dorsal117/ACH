package org.hinna.payments.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for payment gateway settings configuration requests
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentGatewaySettingsRequestDTO {

    // API key for the payment gateway
    private String apiKey;

    // The webhook secret for the payment gateway
    private String webhookSecret;

    // The payment gateway provider
    private String provider = "stripe";

    // Whether to use test mode
    private boolean testMode = true;

    // Default currency for transactions
    private String currency = "cad";
}
