package org.hinna.payments.service.impl;

import org.hinna.payments.dto.ValidationResult;
import org.hinna.payments.model.*;
import org.hinna.payments.repository.StripeApiKeyRepository;
import org.hinna.payments.security.EncryptionUtil;
import org.hinna.payments.service.StripeApiKeyService;
import org.hinna.payments.service.stripe.StripeKeyValidationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@Primary
public class MultiTenantStripeApiKeyServiceImpl implements StripeApiKeyService {
    private static final Logger logger = LoggerFactory.getLogger(MultiTenantStripeApiKeyServiceImpl.class);

    private final StripeApiKeyRepository stripeApiKeyRepository;
    private final EncryptionUtil encryptionUtil;
    private final StripeKeyValidationService validationService;

    @Autowired
    public MultiTenantStripeApiKeyServiceImpl(
            StripeApiKeyRepository repository,
            StripeKeyValidationService validationService,
            @Value("${encryption.key}") String encryptionKey) {
        this.stripeApiKeyRepository = repository;
        this.validationService = validationService;
        this.encryptionUtil = new EncryptionUtil(encryptionKey);
    }

    @Override
    @Transactional
    public void storeApiKey(String keyAlias, String apiKey) {
        try {
            String encrypted = encryptionUtil.encrypt(apiKey);

            // Check if key already exists
            Optional<StripeApiKey> existingKey = stripeApiKeyRepository.findByKeyAlias(keyAlias);

            StripeApiKey entity;
            if (existingKey.isPresent()) {
                // Update existing key
                entity = existingKey.get();
                entity.setEncryptedKey(encrypted);
            } else {
                // Create new key
                entity = new StripeApiKey(keyAlias, encrypted);
            }

            stripeApiKeyRepository.save(entity);
            logger.info("Stored API key with alias: {}", keyAlias);
        } catch (Exception e) {
            logger.error("Failed to encrypt and store API key: {}", e.getMessage());
            throw new RuntimeException("Failed to encrypt and store API key", e);
        }
    }

    @Override
public String getDecryptedKey(String keyAlias) {
try {
// 🔹 Hard override to use application.properties value instead of DB
return System.getProperty("stripe.api.key",
System.getenv("STRIPE_API_KEY")); // fallback to ENV if set
} catch (Exception e) {
logger.error("Failed to retrieve API key from properties: {}", e.getMessage());
throw new RuntimeException("Failed to retrieve API key", e);
}
}

    /**
     * Delete an API key by alias
     *
     * @param keyAlias The alias of the key to delete
     * @return True if the key was deleted, false if it didn't exist
     */
    @Transactional
    public boolean deleteApiKey(String keyAlias) {
        Optional<StripeApiKey> key = stripeApiKeyRepository.findByKeyAlias(keyAlias);
        if (key.isPresent()) {
            stripeApiKeyRepository.delete(key.get());
            logger.info("Deleted API key with alias: {}", keyAlias);
            return true;
        }
        return false;
    }

    /**
     * Delete an account-specific API key
     *
     * @param account The account
     * @param keyType The key type (api_key, webhook_secret)
     * @return True if the key was deleted, false if it didn't exist
     */
    @Transactional
    public boolean deleteApiKey(Account account, String keyType) {
        String keyAlias = generateKeyAlias(account, keyType);
        return deleteApiKey(keyAlias);
    }

    /**
     * Validates and stores API keys for a specific account
     *
     * @param account The account to store keys for
     * @param keyType The type of key (api_key, webhook_secret)
     * @param apiKey The actual API key to store
     * @return Validation result with success status and message
     */
    @Transactional
    public ValidationResult validateAndStoreAccountApiKey(Account account, String keyType, String apiKey) {
        // First validate the key if it's an API key (webhook secrets can't be validated the same way)
        ValidationResult result = null;

        if ("api_key".equals(keyType)) {
            result = validationService.validateStripeKey(apiKey);

            if (!result.isValid()) {
                return result;
            }
        } else if ("webhook_secret".equals(keyType)) {
            // We can't really validate webhook secrets here, so we just accept them
            // They'll be validated when webhooks are received
            result = new ValidationResult(true, "Webhook secret accepted");
        } else {
            logger.warn("Unknown key type: {}", keyType);
            return new ValidationResult(false, "Unknown key type: " + keyType);
        }

        try {
            // Create an alias based on account type and ID
            String keyAlias = generateKeyAlias(account, keyType);

            // Store the encrypted key
            storeApiKey(keyAlias, apiKey);

            return new ValidationResult(true,
                    "API key validated and stored for " + getAccountTypeDisplay(account) + " account.");
        } catch (Exception e) {
            logger.error("Failed to store API key: {}", e.getMessage());
            return new ValidationResult(false,
                    "API key is valid but could not be stored: " + e.getMessage());
        }
    }

    /**
     * Gets the appropriate API key for a specific account
     *
     * @param account The account to get the key for
     * @param keyType The type of key (api_key, webhook_secret)
     * @return The decrypted API key or null if not found
     */
    public String getApiKeyForAccount(Account account, String keyType) {
        try {
            String keyAlias = generateKeyAlias(account, keyType);
            return getDecryptedKey(keyAlias);
        } catch (Exception e) {
            // If the account doesn't have its own key, return null
            // The caller will typically fall back to a system default
            logger.debug("No API key found for account {} and type {}: {}",
                    account.getId(), keyType, e.getMessage());
            return null;
        }
    }

    /**
     * Generates a standardized key alias for an account
     */
    private String generateKeyAlias(Account account, String keyType) {
        String accountType = getAccountType(account);
        return accountType + "_" + account.getId() + "_" + keyType;
    }

    /**
     * Determines the account type
     */
    private String getAccountType(Account account) {
        if (account instanceof SaaSAccount) {
            return "saas";
        } else if (account instanceof ResellerAccount) {
            return "reseller";
        } else if (account instanceof DirectCustomer) {
            return "business";
        } else {
            return "account";
        }
    }

    /**
     * Gets a user-friendly display name for account type
     */
    private String getAccountTypeDisplay(Account account) {
        if (account instanceof SaaSAccount) {
            return "SaaS";
        } else if (account instanceof ResellerAccount) {
            return "Reseller";
        } else if (account instanceof DirectCustomer) {
            return "Business";
        } else {
            return "General";
        }
    }

    /**
     * Checks if an account has its own API keys configured
     */
    public boolean hasCustomApiKey(Account account, String keyType) {
        String keyAlias = generateKeyAlias(account, keyType);
        return stripeApiKeyRepository.findByKeyAlias(keyAlias).isPresent();
    }

    /**
     * Performs a full test of the Stripe API with a given key
     *
     * @param apiKey The API key to test
     * @return Validation result with success status and message
     */
    public ValidationResult performFullTest(String apiKey) {
        return validationService.performFullTest(apiKey);
    }

    /**
     * Checks if the API is already exist
     */
    @Override
    public boolean hasApiKeyAlias(String keyAlias) {
        return stripeApiKeyRepository.findByKeyAlias(keyAlias).isPresent();
    }

}