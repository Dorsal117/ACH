package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;
import org.hinna.payments.model.enums.PayrollStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Represents an employee payroll record in the system.
 * This entity stores information about scheduled and processed payroll payments.
 */
@Entity
@Table(name = "payroll")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString(exclude = {"employee", "processingAccount"})
public class Payroll {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * The staff member (employee) receiving this payroll payment
     */
    @ManyToOne
    @JoinColumn(name = "employee_id", nullable = false)
    private Staff employee;

    /**
     * The account processing the payroll payment (typically a business account)
     */
    @ManyToOne
    @JoinColumn(name = "processing_account_id", nullable = false)
    private Account processingAccount;

    /**
     * The payment method used to process this payroll
     */
    @ManyToOne
    @JoinColumn(name = "payment_method_id")
    private PaymentMethod paymentMethod;

    /**
     * The gross amount of the payroll payment
     */
    @Column(name = "gross_amount", precision = 19, scale = 4, nullable = false)
    private BigDecimal grossAmount;

    /**
     * The net amount after taxes and deductions
     */
    @Column(name = "net_amount", precision = 19, scale = 4, nullable = false)
    private BigDecimal netAmount;

    /**
     * Total tax withheld
     */
    @Column(name = "tax_withheld", precision = 19, scale = 4, nullable = false)
    private BigDecimal taxWithheld;

    /**
     * Other deductions
     */
    @Column(name = "deductions", precision = 19, scale = 4, nullable = false)
    private BigDecimal deductions;

    /**
     * Notes or description for this payroll payment
     */
    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    /**
     * The reference number for this payroll payment
     */
    @Column(name = "reference_number")
    private String referenceNumber;

    /**
     * The pay period start date
     */
    @Column(name = "pay_period_start")
    private LocalDateTime payPeriodStart;

    /**
     * The pay period end date
     */
    @Column(name = "pay_period_end")
    private LocalDateTime payPeriodEnd;

    /**
     * The date this payroll was scheduled
     */
    @Column(name = "scheduled_date")
    private LocalDateTime scheduledDate;

    /**
     * The date this payroll was processed
     */
    @Column(name = "processed_date")
    private LocalDateTime processedDate;

    /**
     * Current status of the payroll payment
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private PayrollStatus status;

    /**
     * When this record was created
     */
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    /**
     * When this record was last updated
     */
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    /**
     * Automatic payment flag
     */
    @Column(name = "is_automatic", nullable = false)
    private boolean isAutomatic = false;

    /**
     * Whether ACH payment is enabled for this payroll
     */
    @Column(name = "is_ach_enabled", nullable = false)
    private boolean isAchEnabled = false;

    /**
     * Error message if payment failed
     */
    @Column(name = "error_message")
    private String errorMessage;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        if (this.status == null) {
            this.status = PayrollStatus.SCHEDULED;
        }
        this.generateReferenceNumber();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Generates a unique reference number for this payroll payment
     */
    private void generateReferenceNumber() {
        if (this.referenceNumber == null || this.referenceNumber.isEmpty()) {
            long timestamp = System.currentTimeMillis();
            String randomPart = UUID.randomUUID().toString().substring(0, 8);
            this.referenceNumber = "PAY-" + timestamp + "-" + randomPart;
        }
    }

    /**
     * Process this payroll payment
     * @return The new status of the payroll payment
     */
    public PayrollStatus process() {
        if (this.status != PayrollStatus.SCHEDULED) {
            return this.status;
        }

        // Logic for processing the payroll would go here
        // For now, just update the status

        this.status = PayrollStatus.PROCESSING;
        return this.status;
    }

    /**
     * Complete this payroll payment
     * @return true if the payment was completed successfully
     */
    public boolean complete() {
        if (this.status != PayrollStatus.PROCESSING) {
            return false;
        }

        this.status = PayrollStatus.COMPLETED;
        this.processedDate = LocalDateTime.now();
        return true;
    }

    /**
     * Mark this payroll payment as failed
     * @param errorMessage The error message explaining why the payment failed
     * @return The updated payroll object
     */
    public Payroll fail(String errorMessage) {
        this.status = PayrollStatus.FAILED;
        this.errorMessage = errorMessage;
        return this;
    }
}
