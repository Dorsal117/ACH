package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;
import org.hinna.payments.model.enums.PaymentStatus;
import org.hinna.payments.model.enums.TransactionStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "payment")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = {"customer", "method", "transactions", "billingHistory"})
@EqualsAndHashCode(of = "id")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    private PaymentStatus status;

    private String stripeId;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Account customer;

    @ManyToOne
    @JoinColumn(name = "method_id")
    private PaymentMethod method;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "processed_at")
    private LocalDateTime processedAt;

    @Column(name = "reference_number")
    private String referenceNumber;

    private String description;

    private String currency;



    @OneToMany(mappedBy = "payment", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PaymentTransaction> transactions = new ArrayList<>();

    @OneToMany(mappedBy = "payment", cascade =  CascadeType.ALL)
    private List<BillingHistory> billingHistory = new ArrayList<>();

    public Payment(Account customer, BigDecimal amount, PaymentMethod method) {
        this.customer = customer;
        this.amount = amount;
        this.method = method;
    }

    @PrePersist
    public void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.status = PaymentStatus.PENDING;
    }

    // Business methods
    public PaymentStatus processPayment() {
        if (status != PaymentStatus.PENDING) {
            return status;
        }

        // Logics (will be developed further)

        // Success
        this.status = PaymentStatus.COMPLETED;
        this.processedAt = LocalDateTime.now();

        // Create transaction record
        PaymentTransaction transaction = new PaymentTransaction();
        transaction.setPayment(this);
        transaction.setStatus(TransactionStatus.SUCCESS);
        transaction.setAmount(this.amount);
        transaction.setMessage("Payment processed successfully");
        this.transactions.add(transaction);

        return this.status;
    }

    public boolean capturePayment() {
        if (status != PaymentStatus.PROCESSING) {
            return false;
        }

        // Logic to capture payment
        this.status = PaymentStatus.COMPLETED;
        this.processedAt = LocalDateTime.now();

        PaymentTransaction transaction = new PaymentTransaction();
        transaction.setPayment(this);
        transaction.setStatus(TransactionStatus.SUCCESS);
        transaction.setMessage("Payment captured successfully");
        this.transactions.add(transaction);

        return true;
    }
}
