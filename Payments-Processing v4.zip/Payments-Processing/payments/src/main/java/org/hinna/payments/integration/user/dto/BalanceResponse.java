package org.hinna.payments.integration.user.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Response DTO for balance endpoint.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Response containing account balance information")
public class BalanceResponse {

    @Schema(description = "Whether the request was successful", example = "true")
    private boolean success;

    @Schema(description = "Message describing the result", example = "Balance information retrieved successfully")
    private String message;

    @Schema(description = "Current balance", example = "500.00")
    private BigDecimal balance;

    @Schema(description = "Available credit (may be null if not applicable)", example = "1000.00")
    private BigDecimal availableCredit;

    @Schema(description = "Amount in pending transactions", example = "50.00")
    private BigDecimal pendingTransactions;
}
