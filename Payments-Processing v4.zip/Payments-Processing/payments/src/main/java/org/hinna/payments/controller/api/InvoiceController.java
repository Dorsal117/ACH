package org.hinna.payments.controller.api;

import org.hinna.payments.dto.InvoiceDTO;
import org.hinna.payments.dto.InvoiceItemDTO;
import org.hinna.payments.model.*;
import org.hinna.payments.model.enums.InvoiceStatus;
import org.hinna.payments.service.AccountService;
import org.hinna.payments.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {

    private final InvoiceService invoiceService;
    private final AccountService accountService;

    @Autowired
    public InvoiceController(InvoiceService invoiceService, AccountService accountService) {
        this.invoiceService = invoiceService;
        this.accountService = accountService;
    }

    @PostMapping
    public ResponseEntity<InvoiceDTO> createInvoice(@RequestParam UUID customerId,
            @RequestParam String issueDate,
            @RequestParam String dueDate) {
        Account customer = accountService.getAccountById(customerId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Customer not found"));

        Invoice invoice = new Invoice(customer, LocalDateTime.parse(issueDate), LocalDateTime.parse(dueDate));
        Invoice created = invoiceService.createInvoice(invoice);

        return ResponseEntity.status(HttpStatus.CREATED).body(convertToInvoiceDTO(created));
    }

    @GetMapping("/{id}")
    public ResponseEntity<InvoiceDTO> getInvoiceById(@PathVariable UUID id) {
        return invoiceService.getInvoiceById(id)
                .map(this::convertToInvoiceDTO)
                .map(ResponseEntity::ok)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Invoice not found"));
    }

    @GetMapping
    public ResponseEntity<Page<InvoiceDTO>> getAllInvoices(@RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Page<InvoiceDTO> dtos = invoiceService.getAllInvoices(PageRequest.of(page, size))
                .map(this::convertToInvoiceDTO);
        return ResponseEntity.ok(dtos);
    }

    @PutMapping("/{id}")
    public ResponseEntity<InvoiceDTO> updateInvoice(@PathVariable UUID id, @RequestBody Invoice updatedInvoice) {
        Invoice updated = invoiceService.updateInvoice(id, updatedInvoice);
        return ResponseEntity.ok(convertToInvoiceDTO(updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInvoice(@PathVariable UUID id) {
        invoiceService.deleteInvoice(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/items")
    public ResponseEntity<InvoiceDTO> addItem(@PathVariable UUID id, @RequestBody InvoiceItem item) {
        Invoice updated = invoiceService.addItemToInvoice(id, item);
        return ResponseEntity.ok(convertToInvoiceDTO(updated));
    }

    @DeleteMapping("/{invoiceId}/items/{itemId}")
    public ResponseEntity<InvoiceDTO> removeItem(@PathVariable UUID invoiceId, @PathVariable UUID itemId) {
        Invoice updated = invoiceService.removeItemFromInvoice(invoiceId, itemId);
        return ResponseEntity.ok(convertToInvoiceDTO(updated));
    }

    @PostMapping("/{id}/issue")
    public ResponseEntity<InvoiceDTO> issueInvoice(@PathVariable UUID id) {
        Invoice issued = invoiceService.issueInvoice(id);
        return ResponseEntity.ok(convertToInvoiceDTO(issued));
    }

    @PostMapping("/{id}/pay")
    public ResponseEntity<InvoiceDTO> markAsPaid(@PathVariable UUID id, @RequestParam UUID paymentId) {
        Invoice paid = invoiceService.markAsPaid(id, paymentId);
        return ResponseEntity.ok(convertToInvoiceDTO(paid));
    }

    @PostMapping("/{id}/cancel")
    public ResponseEntity<InvoiceDTO> cancelInvoice(@PathVariable UUID id) {
        Invoice cancelled = invoiceService.cancelInvoice(id);
        return ResponseEntity.ok(convertToInvoiceDTO(cancelled));
    }

    @GetMapping("/overdue")
    public ResponseEntity<List<InvoiceDTO>> getOverdueInvoices() {
        List<InvoiceDTO> overdue = invoiceService.getOverdueInvoices().stream()
                .map(this::convertToInvoiceDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(overdue);
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<InvoiceDTO>> getInvoicesByStatus(@PathVariable InvoiceStatus status) {
        List<InvoiceDTO> result = invoiceService.getInvoiceByStatus(status).stream()
                .map(this::convertToInvoiceDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(result);
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<InvoiceDTO>> getInvoicesByCustomer(@PathVariable UUID customerId) {
        Account customer = accountService.getAccountById(customerId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Customer not found"));

        List<InvoiceDTO> invoices = invoiceService.getInvoicesByCustomer(customer).stream()
                .map(this::convertToInvoiceDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(invoices);
    }

    @GetMapping("/customer/{customerId}/outstanding")
    public ResponseEntity<BigDecimal> getOutstanding(@PathVariable UUID customerId) {
        Account customer = accountService.getAccountById(customerId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Customer not found"));
        return ResponseEntity.ok(invoiceService.getTotalOutstandingAmount(customer));
    }

    @PostMapping("/overdue/mark")
    public ResponseEntity<List<InvoiceDTO>> markAllOverdue() {
        List<InvoiceDTO> marked = invoiceService.markOverdueInvoices().stream()
                .map(this::convertToInvoiceDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(marked);
    }

    // ================================
    // DTO conversion methods (inline)
    // ================================

    private InvoiceDTO convertToInvoiceDTO(Invoice invoice) {
        InvoiceDTO dto = new InvoiceDTO();
        dto.setId(invoice.getId());
        dto.setInvoiceNumber(invoice.getInvoiceNumber());
        dto.setCustomerId(invoice.getCustomer().getId());
        dto.setCustomerName(invoice.getCustomer().getFullName());
        dto.setStatus(invoice.getStatus());
        dto.setSubtotal(invoice.getSubtotal());
        dto.setTaxAmount(invoice.getTaxAmount());
        dto.setTotalAmount(invoice.getTotalAmount());
        dto.setIssueDate(invoice.getIssueDate());
        dto.setDueDate(invoice.getDueDate());
        dto.setNotes(invoice.getNotes());
        dto.setCreatedAt(invoice.getCreatedAt());
        dto.setUpdatedAt(invoice.getUpdatedAt());
        dto.setPaidAt(invoice.getPaidAt());

        if (invoice.getPayment() != null) {
            dto.setPaymentId(invoice.getPayment().getId());
        }

        dto.setItems(invoice.getItems().stream()
                .map(this::convertToInvoiceItemDTO)
                .collect(Collectors.toList()));

        return dto;
    }

    private InvoiceItemDTO convertToInvoiceItemDTO(InvoiceItem item) {
        InvoiceItemDTO dto = new InvoiceItemDTO();
        dto.setId(item.getId());
        dto.setDescription(item.getDescription());
        dto.setQuantity(item.getQuantity());
        dto.setPrice(item.getPrice());
        dto.setTaxRate(item.getTaxRate());
        dto.setItemType(item.getItemType());
        dto.setItemId(item.getItemId());
        dto.setServiceId(item.getServiceId());
        return dto;
    }
}
