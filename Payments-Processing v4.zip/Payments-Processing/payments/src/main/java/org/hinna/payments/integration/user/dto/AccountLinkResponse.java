package org.hinna.payments.integration.user.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * Response DTO for account linking endpoint.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Response containing account linking result")
public class AccountLinkResponse {

    @Schema(description = "Whether the linking was successful", example = "true")
    private boolean success;

    @Schema(description = "ID of the account in the Payment System", example = "123e4567-e89b-12d3-a456-426614174000")
    private UUID accountId;

    @Schema(description = "ID of the user in the User Service", example = "12345")
    private Long userId;

    @Schema(description = "Message describing the result", example = "Account successfully linked")
    private String message;
}