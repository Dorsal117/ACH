package org.hinna.payments.service.impl;

import jakarta.transaction.Transactional;
import org.hinna.payments.model.*;
import org.hinna.payments.repository.AdminGroupRepository;
import org.hinna.payments.repository.AdminRepository;
import org.hinna.payments.repository.AdminTableAccessRepository;
import org.hinna.payments.repository.DatabaseTableRepository;
import org.hinna.payments.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class AdminServiceImpl implements AdminService {

    private final AdminRepository adminRepository;
    private final AdminGroupRepository adminGroupRepository;
    private final DatabaseTableRepository databaseTableRepository;
    private final AdminTableAccessRepository adminTableAccessRepository;

    @Autowired
    public AdminServiceImpl(AdminRepository adminRepository, AdminGroupRepository adminGroupRepository,
                            DatabaseTableRepository databaseTableRepository,
                            AdminTableAccessRepository adminTableAccessRepository) {
        this.adminRepository = adminRepository;
        this.adminGroupRepository = adminGroupRepository;
        this.databaseTableRepository = databaseTableRepository;
        this.adminTableAccessRepository = adminTableAccessRepository;
    }

    @Override
    public Admin createAdmin(Admin admin) {
        // Check if account already has an admin role
        if (adminRepository.findByAccount(admin.getAccount()).isPresent()) {
            throw new IllegalArgumentException("Account already has an admin role");
        }

        return adminRepository.save(admin);
    }

    @Override
    public Optional<Admin> getAdminById(UUID id) {
        return adminRepository.findById(id);
    }

    @Override
    public Optional<Admin> getAdminByAccount(Account account) {
        return adminRepository.findByAccount(account);
    }

    @Override
    public Page<Admin> getAllAdmins(Pageable pageable) {
        return adminRepository.findAll(pageable);
    }

    @Override
    public List<Admin> getAdminsByType(String adminType) {
        return adminRepository.findByAdminType(adminType);
    }

    @Override
    public List<Admin> getAdminsByGroup(AdminGroup adminGroup) {
        return adminRepository.findByAdminGroup(adminGroup);
    }

    @Override
    @Transactional
    public Admin updateAdmin(UUID id, Admin adminDetails) {
        return adminRepository.findById(id)
                .map(existingAdmin -> {
                    // Update admin fields
                    existingAdmin.setAdminType(adminDetails.getAdminType());
                    existingAdmin.setRolesOverview(adminDetails.getRolesOverview());
                    existingAdmin.setTablesAccessible(adminDetails.getTablesAccessible());
                    existingAdmin.setTablesCreated(adminDetails.getTablesCreated());
                    existingAdmin.setBasePermissions(adminDetails.getBasePermissions());

                    // Don't update account or admin group - use specific methods for that

                    return adminRepository.save(existingAdmin);
                })
                .orElseThrow(() -> new IllegalArgumentException("Admin not found with id: " + id));
    }

    @Override
    @Transactional
    public void deleteAdmin(UUID id) {
        adminRepository.deleteById(id);
    }

    @Override
    public Admin assignToGroup(UUID adminId, UUID groupId) {
        Admin admin = adminRepository.findById(adminId)
                .orElseThrow(() -> new IllegalArgumentException("Admin not found with id: " + adminId));

        AdminGroup adminGroup = adminGroupRepository.findById(groupId)
                .orElseThrow(() -> new IllegalArgumentException("Admin group not found with id: " + groupId));

        admin.setAdminGroup(adminGroup);
        return adminRepository.save(admin);
    }

    @Override
    public boolean hasPermission(UUID adminId, String permissionName) {
        Admin admin = adminRepository.findById(adminId)
                .orElseThrow(() -> new IllegalArgumentException("Admin not found with id: " + adminId));

        return admin.hasPermission(permissionName);
    }

    @Override
    @Transactional
    public Admin addAccessToTable(UUID adminId, UUID tableId, String accessLevel) {
        Admin admin = adminRepository.findById(adminId)
                .orElseThrow(() -> new IllegalArgumentException("Admin not found with id: " + adminId));

        DatabaseTable table = databaseTableRepository.findById(tableId)
                .orElseThrow(() -> new IllegalArgumentException("Database table not found with id: " + tableId));

        // Check if access already exists
        Optional<AdminTableAccess> existingAccess =
                adminTableAccessRepository.findByAdminAndDatabaseTable(admin, table);

        if (existingAccess.isPresent()) {
            // Update existing access
            AdminTableAccess access = existingAccess.get();
            access.setAccessLevel(AdminTableAccess.AccessLevel.valueOf(accessLevel));
            adminTableAccessRepository.save(access);
        } else {
            // Create new access
            AdminTableAccess access = new AdminTableAccess(
                    admin,
                    table,
                    AdminTableAccess.AccessLevel.valueOf(accessLevel)
            );
            adminTableAccessRepository.save(access);
            admin.addAccessibleTable(table);
        }

        return adminRepository.save(admin);
    }

    @Override
    public Admin removeAccessToTable(UUID adminId, UUID tableId) {
        Admin admin = adminRepository.findById(adminId)
                .orElseThrow(() -> new IllegalArgumentException("Admin not found with id: " + adminId));

        DatabaseTable table = databaseTableRepository.findById(tableId)
                .orElseThrow(() -> new IllegalArgumentException("Database table not found with id: " + tableId));

        // Find and remove access
        Optional<AdminTableAccess> existingAccess = adminTableAccessRepository.findByAdminAndDatabaseTable(admin, table);
        existingAccess.ifPresent(adminTableAccessRepository::delete);

        // Remove table from admin's accessible tables
        admin.getAccessibleTables().removeIf(t -> t.getId().equals(tableId));
        return adminRepository.save(admin);
    }

    @Override
    public boolean canAccessTable(UUID adminId, String tableName) {
        Admin admin = adminRepository.findById(adminId)
                .orElseThrow(() -> new IllegalArgumentException("Admin not found with id: " + adminId));

        return admin.canAccessTable(tableName);
    }
}
