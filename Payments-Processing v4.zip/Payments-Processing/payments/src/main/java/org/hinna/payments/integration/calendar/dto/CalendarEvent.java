package org.hinna.payments.integration.calendar.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * DTO that matches the Calendar microservice model
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CalendarEvent {
    private String event_id; // Following calendar project's naming convention
    private String company_id;
    private String title;
    private String description;
    private Date start_time;
    private Date end_time;
    private String location;
    private String status;
    private List<String> tags;

    // Payment-specific properties
    private Boolean paymentRequired;    // Not in the original model, for our logic
    private String paymentStatus;       // Not in the original model, for tracking
}
