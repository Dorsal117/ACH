package org.hinna.payments.service.impl;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Service
public class PaymentCalculationServiceImpl {

    private static final BigDecimal GST_RATE = new BigDecimal("0.10"); // 10%
    private static final BigDecimal STRIPE_PERCENT = new BigDecimal("0.029"); // 2.9%
    private static final BigDecimal STRIPE_FIXED_FEE = new BigDecimal("0.30"); // $0.30

    public BigDecimal calculateTotal(BigDecimal baseAmount) {
        BigDecimal gst = baseAmount.multiply(GST_RATE);
        BigDecimal stripeFee = baseAmount.multiply(STRIPE_PERCENT).add(STRIPE_FIXED_FEE);
        return baseAmount.add(gst).add(stripeFee).setScale(2, RoundingMode.HALF_UP);
    }
}
