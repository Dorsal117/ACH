package org.hinna.payments.model.enums;

public enum BankAccountVerificationStatus {
    UNVERIFIED,
    PENDING,
    VERIFIED,
    FAILED
}