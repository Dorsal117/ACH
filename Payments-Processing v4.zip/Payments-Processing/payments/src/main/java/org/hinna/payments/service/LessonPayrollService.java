package org.hinna.payments.service;

import org.hinna.payments.model.enums.LessonCancellationReason;

import java.util.UUID;

public interface LessonPayrollService {

    /**
     * Main method to process payroll for a cancelled lesson
     * Implements the decision flow from the payroll management diagram
     */
    void processLessonCancellationPayroll(UUID lessonId, LessonCancellationReason reason);
}
