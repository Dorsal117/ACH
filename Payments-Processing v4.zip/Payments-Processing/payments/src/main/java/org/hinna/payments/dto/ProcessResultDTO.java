package org.hinna.payments.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for process result
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProcessResultDTO {
    private int count;
    private String message;
}
