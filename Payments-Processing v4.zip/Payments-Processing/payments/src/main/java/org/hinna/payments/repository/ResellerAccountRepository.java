package org.hinna.payments.repository;

import org.hinna.payments.model.ResellerAccount;
import org.hinna.payments.model.SaaSAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface ResellerAccountRepository extends JpaRepository<ResellerAccount, UUID> {
    List<ResellerAccount> findBySaasAccount(SaaSAccount saasAccount);
    Optional<ResellerAccount> findByResellerCode(String resellerCode);
    List<ResellerAccount> findByCommissionRateGreaterThan(BigDecimal rate);
    boolean existsByResellerCode(String resellerCode);

}