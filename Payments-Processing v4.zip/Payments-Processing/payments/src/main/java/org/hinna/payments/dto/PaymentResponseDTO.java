package org.hinna.payments.dto;

import lombok.Data;
import org.hinna.payments.model.enums.PaymentStatus;
import org.hinna.payments.model.enums.PaymentType;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
public class PaymentResponseDTO {
    private UUID id;
    private BigDecimal amount;
    private PaymentStatus status;
    private UUID customerId;
    private String customerName;
    private UUID paymentMethodId;
    private PaymentType paymentMethodType;
    private String paymentMethodBrand;
    private String paymentMethodWalletType;
    private String lastFourDigits;
    private LocalDateTime createdAt;
    private LocalDateTime processedAt;
    private String referenceNumber;
    private String description;
    private String currency;
}
