package org.hinna.payments.controller.api;

import lombok.extern.slf4j.Slf4j;

import org.hinna.payments.service.stripe.StripeWebhookHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/stripe/webhooks")
@Slf4j
public class StripeWebhookController {

    private final StripeWebhookHandler stripeWebhookHandler;

    @Autowired
    public StripeWebhookController(StripeWebhookHandler stripeWebhookHandler) {
        this.stripeWebhookHandler = stripeWebhookHandler;
    }

    public ResponseEntity<String> handleWebhook(@RequestBody String payload,
                                              @RequestHeader("Stripe-Signature") String sigHeader) {
        try {
            // Process the webhook
            boolean success = stripeWebhookHandler.handleWebhook(payload, sigHeader);

            if (success) {
                // Return 200 OK to acknowledge receipt
                return ResponseEntity.ok().body("Webhook processed successfully");
            } else {
                // Return 422 Unprocessable Entity if couldn't process
                return  ResponseEntity.unprocessableEntity().body("Could not process webhook");
            }
        } catch (Exception e) {
            log.error("Error handling webhook: {}", e.getMessage());

            // Return 400 Bad Request for invalid webhooks
            return ResponseEntity.badRequest().body("Invalid webhook: " + e.getMessage());
        }
    }
}
