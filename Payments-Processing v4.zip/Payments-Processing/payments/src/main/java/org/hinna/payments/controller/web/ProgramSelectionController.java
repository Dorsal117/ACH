package org.hinna.payments.controller.web;

import org.hinna.payments.model.ProgramOption;
import org.hinna.payments.model.ProgramSelectionForm;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class ProgramSelectionController {

    @GetMapping("/program-selection")
    public String showSelectionForm(Model model) {
        model.addAttribute("selectionForm", new ProgramSelectionForm());
        model.addAttribute("programs", List.of(
                new ProgramOption("Music Together", "Lorem ipsum..."),
                new ProgramOption("Rhythm Kids", "Lorem ipsum..."),
                new ProgramOption("Private Music lessons", "Lorem ipsum..."),
                new ProgramOption("Online Private Music lessons", "Lorem ipsum...")
        ));
        model.addAttribute("locations", List.of("Toronto", "Etobicoke", "Mississauga"));
        return "ProgramSelection";
    }


    @PostMapping("/program-selection/submit")
    public String handleSelection(@ModelAttribute ProgramSelectionForm selectionForm, RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("selectedProgram", selectionForm.getSelectedProgram());
        redirectAttributes.addFlashAttribute("selectedLocation", selectionForm.getSelectedLocation());
        return "redirect:/teacher-selection";
    }
}

