package org.hinna.payments.service;

import org.hinna.payments.integration.user.dto.AutomaticPaymentSettingsDTO;
import org.hinna.payments.model.Account;
import org.hinna.payments.model.PaymentSettings;
import org.hinna.payments.model.enums.PaymentType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;
import java.util.UUID;

public interface PaymentSettingsService {
    PaymentSettings createPaymentSettings(PaymentSettings paymentSettings);
    Optional<PaymentSettings> getPaymentSettingsById(UUID id);
    Optional<PaymentSettings> getPaymentSettingsByAccount(Account account);
    Page<PaymentSettings> getAllPaymentSettings(Pageable pageable);
    PaymentSettings updatePaymentSettings(UUID id, PaymentSettings paymentSettingsDetails);
    void deletePaymentSettings(UUID id);
    PaymentSettings getOrCreatePaymentSettings(Account account);
    PaymentSettings addAllowedPaymentType(UUID id, PaymentType type);
    PaymentSettings removeAllowedPaymentType(UUID id, PaymentType type);
    boolean isPaymentTypeAllowed(UUID id, PaymentType type);

    /**
     * Get automatic payment settings for an account
     * @param accountId The account ID
     * @return AutomaticPaymentSettingsDTO containing the settings
     */
    AutomaticPaymentSettingsDTO getAutomaticPaymentSettings(UUID accountId);

    /**
     * Update automatic payment settings
     * @param accountId The account ID
     * @param settings The new settings
     * @return Updated AutomaticPaymentSettingsDTO
     */
    AutomaticPaymentSettingsDTO updateAutomaticPaymentSettings(UUID accountId, AutomaticPaymentSettingsDTO settings);

    /**
     * Process automatic payment retries for failed payments
     * This would be called by a scheduled job
     * @return Number of payments retried
     */
    int processAutomaticPaymentRetries();

    /**
     * Process automatic charges for accounts with negative balances
     * This would be called by a scheduled job
     * @param day The day of the week to process
     * @return Number of accounts charged
     */
    int processNegativeBalanceCharges(String day);
}
