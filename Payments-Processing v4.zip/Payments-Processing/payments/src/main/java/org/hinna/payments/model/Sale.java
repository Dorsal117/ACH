package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "sale")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = "applicableListings")
@EqualsAndHashCode(of = "id")
public class Sale {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(nullable = false)
    private String name;

    private String description;

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "discount_type")
    private DiscountType discountType;

    @Column(name = "discounted_value", precision = 19, scale = 4)
    private BigDecimal discountValue;

    @Column(name = "is_active")
    private boolean isActive = true;

    @ManyToMany(mappedBy = "applicableSales")
    private Set<Listing> applicableListings = new HashSet<>();

    public Sale(String name, DiscountType discountType, BigDecimal discountValue) {
        this.name = name;
        this.discountType = discountType;
        this.discountValue = discountValue;
        this.startDate = LocalDate.now();
    }

    public BigDecimal calculateDiscount(BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0 ||
            discountValue == null || discountValue.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }

        if (discountType == DiscountType.PERCENTAGE) {
            return amount.multiply(discountValue).divide(new BigDecimal("100"));
        } else {
            return discountValue.min(amount);
        }
    }

    /**
     * Validate active status, start date, and end date of a sale
     * @return boolean
     */
    public boolean validateSale() {
        if (!isActive) {
            return false;
        }

        LocalDate now = LocalDate.now();

        if (startDate != null && startDate.isAfter(now)) {
            return false;
        }

        return endDate == null || !endDate.isBefore(now);
    }

    public enum DiscountType {
        PERCENTAGE,
        FIXED_AMOUNT,
    }
}
