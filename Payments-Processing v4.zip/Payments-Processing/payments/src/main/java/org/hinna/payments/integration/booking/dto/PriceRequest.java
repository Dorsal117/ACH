package org.hinna.payments.integration.booking.dto;

import lombok.*;

/**
 * Matches exactly with the PriceRequest from booking service
 */
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class PriceRequest extends BaseEntity {
    private Double amount;
    private Integer classDuration;
    private String billingFrequency;
}
