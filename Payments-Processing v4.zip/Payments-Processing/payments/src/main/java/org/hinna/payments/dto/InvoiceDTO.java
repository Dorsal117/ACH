package org.hinna.payments.dto;

import lombok.Data;
import org.hinna.payments.model.enums.InvoiceStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Data
public class InvoiceDTO {

    private UUID id;
    private String invoiceNumber;

    private UUID customerId;
    private String customerName;

    private InvoiceStatus status;

    private BigDecimal subtotal;
    private BigDecimal taxAmount;
    private BigDecimal totalAmount;

    private LocalDateTime issueDate;
    private LocalDateTime dueDate;

    private String notes;

    private List<InvoiceItemDTO> items;

    private UUID paymentId;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private LocalDateTime paidAt;
}