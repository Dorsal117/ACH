package org.hinna.payments.service.stripe;

import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.Balance;
import com.stripe.model.Customer;
import com.stripe.param.CustomerListParams;
import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.dto.ValidationResult;
import org.springframework.stereotype.Service;

/**
 * Service for validating Stripe API keys
 */
@Service
@Slf4j
public class StripeKeyValidationService {

    /**
     * Validate a Stripe API key
     * @param apiKey The API key to validate
     * @return ValidationResult with success status and message
     */
    public ValidationResult validateStripeKey(String apiKey) {
        // Store current API key to restore it after validation
        String currentApiKey = Stripe.apiKey;

        try {
            // Temporarily set the API key for validation
            Stripe.apiKey = apiKey;

            // Make a simple API call to test the key
            // Using Balance.retrieve as it's a simple call that requires authentication
            Balance balance = Balance.retrieve();

            // Determine if this is a test or live key
            boolean isTestKey = balance.getLivemode() != null && !balance.getLivemode();

            // Reset the API key
            Stripe.apiKey = currentApiKey;

            return new ValidationResult(
                    true,
                    "API key validated successfully. This is a " + (isTestKey ? "TEST" : "LIVE" + " mode key.")
            );
        } catch (StripeException e) {
            // Reset the API key
            Stripe.apiKey = currentApiKey;

            log.error("Error validating Stripe API key: {}", e.getMessage());
            return new ValidationResult(
                    false,
                    "Invalid API key: " + e.getMessage()
            );
        }
    }

    /**
     * Test a full round-trip to Stripe by creating and immediately deleting a customer.
     * This is a more thorough validation than just checking the balance
     *
     * @param apiKey The API key to test
     * @return ValidationResult with success status and message
     */
    public ValidationResult performFullTest(String apiKey) {
        // Store current API key to restore it after test
        String currentApiKey = Stripe.apiKey;

        try {
            // Temporarily set the API for testing
            Stripe.apiKey = apiKey;

            // Create a test customer
            CustomerListParams params = CustomerListParams.builder()
                    .setLimit(1L)
                    .build();

            // Just list a customer to make sure that the API can be actually used
            Customer.list(params);

            // Reset the API key
            Stripe.apiKey = currentApiKey;

            return new ValidationResult(
                    true,
                    "Full API test completed successfully. Your Stripe integration is working correctly."
            );
        } catch (StripeException e) {
            // Reset the API key
            Stripe.apiKey = currentApiKey;

            log.error("Error during full Stripe API test: {}", e.getMessage());
            return new ValidationResult(
                    false,
                    "Stripe API test failed: " + e.getMessage()
            );
        }
    }
}
