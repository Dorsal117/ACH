package org.hinna.payments.repository;

import org.hinna.payments.model.Account;
import org.hinna.payments.model.PaymentSettings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface PaymentSettingsRepository extends JpaRepository<PaymentSettings, UUID> {
    Optional<PaymentSettings> findByAccount(Account account);
    List<PaymentSettings> findByAutoInvoiceTrue();
    List<PaymentSettings> findByRetryAttemptsGreaterThan(Integer attempts);
    List<PaymentSettings> findByMinimumPaymentAmountLessThan(BigDecimal amount);
    List<PaymentSettings> findByAllowedPaymentTypesContaining(String paymentType);
}