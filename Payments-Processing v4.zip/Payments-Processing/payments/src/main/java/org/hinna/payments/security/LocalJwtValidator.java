package org.hinna.payments.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

/**
 * Local JWT validator that validates tokens without making network calls.
 * <br>
 * This should be used to replace the userServiceClient.validateToken() calls
 * <br>
 * <br>
 * Login-Authentication team's confirmed JWT structure:
 * <ul>
 *     <li><b>User ID:</b> stored in 'sub' (subject) claim </li>
 *     <li><b>Role:</b> stored in 'role' (subject) claim </li>
 *     <li><b>Authority:</b> stored in 'authority' (subject) claim </li>
 * </ul>
 */
@Component
@Slf4j
public class LocalJwtValidator {

    @Value("${jwt.secret}")
    private String jwtSecret;

    private SecretKey getSigningKey() {
        // Must match the secret used by Login-Authentication MS
        return Keys.hmacShaKeyFor(jwtSecret.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Validate JWT token locally - no network calls
     */
    public boolean validateToken(String token) {
        try {
            Jwts.parser()                           // Create a JWT parser
                    .verifyWith(getSigningKey())    // Set the secret key for verification
                    .build()                        // Build the configured parser
                    .parseSignedClaims(token);      // Extract the claims/payload

            log.debug("Token validation successful - no network call needed");
            return true;
        } catch (SecurityException ex) {
            log.error("Invalid JWT signature: {}", ex.getMessage());
        } catch (MalformedJwtException ex) {
            log.error("Invalid JWT token: {}", ex.getMessage());
        } catch (ExpiredJwtException ex) {
            log.error("Expired JWT token: {}", ex.getMessage());
        } catch (UnsupportedJwtException ex) {
            log.error("Unsupported JWT token: {}", ex.getMessage());
        } catch (IllegalArgumentException ex) {
            log.error("JWT claims string is empty: {}", ex.getMessage());
        } catch (Exception ex) {
            log.error("Unexpected JWT validation error: {}", ex.getMessage());
        }
        return false;
    }

    /**
     * Extract user ID from JWT token locally
     * This replaces jwtDecoder.getUserIdFromToken(token) but works locally
     */
    public Long getUserIdFromToken(String token) {
        try {
            Claims claims = Jwts.parser()
                    .verifyWith(getSigningKey())
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();

            // Confirmed: User ID is stored in the 'sub' (subject) claim
            String subject = claims.getSubject();

            if (subject != null) {
                try {
                    return Long.valueOf(subject);
                } catch (NumberFormatException e) {
                    log.warn("Subject '{}' is not a valid user ID number", subject);
                    return null;
                }
            }

            log.warn("Could not extract userId from token claims: {}", claims.keySet());
            return null;

        } catch (Exception e) {
            log.error("Error extracting userId from token");
            return null;
        }
    }

    /**
     * Extract user role from JWT token locally
     */
    public String getRoleFromToken(String token) {
        try {
            Claims claims = Jwts.parser()
                    .verifyWith(getSigningKey())
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();

            // Confirmed: Role is stored in 'role' claim
            String role = claims.get("role", String.class);

            return role != null ? role: "USER"; // Default role if not found

        } catch (Exception e) {
            log.error("Error extracting role from token", e);
            return "USER"; // Default role
        }
    }

    /**
     * Extract user authority/permissions from JWT token locally
     */
    public String getAuthorityFromToken(String token) {
        try {
            Claims claims = Jwts.parser()
                    .verifyWith(getSigningKey())
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();

            // Confirmed: Authority is stored in 'authority' claim
            return claims.get("authority", String.class);

        } catch (Exception e) {
            log.error("Error extracting authority from token", e);
            return null;
        }
    }

    /**
     * Check if token is expired
     * @param token Token to check
     * @return true if token is expired, false otherwise
     */
    public boolean isTokenExpired(String token) {
        try {
            Claims claims = Jwts.parser()
                    .verifyWith(getSigningKey())
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();

            return claims.getExpiration().before(new Date());
        } catch (Exception e) {
            return true; // If we can't parse it, consider it expired
        }
    }

    /**
     * Get all claims (for debugging)
     */
    public Claims getAllClaims(String token) {
        try {
            return Jwts.parser()
                    .verifyWith(getSigningKey())
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
        } catch (Exception e) {
            log.error("Error extracting claims from token", e);
            return null;
        }
    }
}
