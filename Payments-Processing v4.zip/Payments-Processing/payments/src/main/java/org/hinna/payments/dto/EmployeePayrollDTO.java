package org.hinna.payments.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeePayrollDTO {
    private UUID employeeId;
    private String employeeName;
    private String position;
    private String employmentType;
    private BigDecimal totalGrossAmount;
    private BigDecimal totalNetAmount;
    private BigDecimal totalTaxWithheld;
    private BigDecimal totalDeductions;
    private int paymentCount;
    private LocalDateTime periodStart;
    private LocalDateTime periodEnd;
}
