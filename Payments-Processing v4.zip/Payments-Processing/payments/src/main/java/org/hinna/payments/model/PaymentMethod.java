package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;
import org.hinna.payments.model.enums.PaymentType;

import java.time.LocalDateTime;
import java.util.UUID;

import org.hinna.payments.model.enums.BankAccountVerificationMethod;
import org.hinna.payments.model.enums.BankAccountVerificationStatus;

@Entity
@Table(name = "payment_method")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = "owner")
@EqualsAndHashCode(of = "id")
public class PaymentMethod {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "owner_id")
    private Account owner;

    @Enumerated(EnumType.STRING)
    private PaymentType type;

    @Column(name = "provider_token")
    private String providerToken;

    @Column(name = "last_four_digits")
    private String lastFourDigits;

    @Column(name = "expiry_date")
    private LocalDateTime expiryDate;

    @Column(name = "is_default")
    private Boolean isDefault;

    @Column(name = "is_active")
    private Boolean isActive = true;

    @Column(name = "brand")
    private String brand; // "visa", "mastercard", "amex", etc.

    @Column(name = "wallet_type")
    private String walletType; // "apple_pay", "google_pay" (optional)

    @Enumerated(EnumType.STRING)
    @Column(name = "bank_verification_status", nullable = false)
    private BankAccountVerificationStatus bankVerificationStatus = BankAccountVerificationStatus.UNVERIFIED;

    @Enumerated(EnumType.STRING)
    @Column(name = "bank_verification_method")
    private BankAccountVerificationMethod bankVerificationMethod;

    @Column(name = "bank_last_four")
    private String bankLastFourDigits;

    @Column(name = "bank_fingerprint")
    private String bankFingerprint;

    @Column(name = "bank_mandate_reference")
    private String bankMandateReference;

    @Column(name = "bank_mandate_url")
    private String bankMandateUrl;

    @Column(name = "bank_verified_at")
    private LocalDateTime bankVerifiedAt;

    @Column(name = "bank_linked_at")
    private LocalDateTime bankLinkedAt;

    @Column(name = "ach_account_holder_name")
    private String achAccountHolderName;

    public boolean isAchBankAccount() {
        return this.type == PaymentType.BANK_TRANSFER;
    }

    public boolean isBankAccountVerified() {
        return this.bankVerificationStatus == BankAccountVerificationStatus.VERIFIED;
    }

    public PaymentMethod(Account owner, PaymentType type) {
        this.owner = owner;
        this.type = type;
    }

    @Column(name = "priority")
    private Integer priority; // Lower number = higher priority

    // Business methods
    public boolean isExpired() {
        if (expiryDate == null) {
            return false;
        }
        return LocalDateTime.now().isAfter(expiryDate);
    }

    public String getDisplayName() {
        StringBuilder sb = new StringBuilder();
        sb.append(type.getDisplayName());

        if (lastFourDigits != null && !lastFourDigits.isEmpty()) {
            sb.append(" ending in ").append(lastFourDigits);
        }

        if (expiryDate != null) {
            sb.append(" (exp: ").append(expiryDate.getMonthValue()).append("/")
                    .append(expiryDate.getYear() % 100).append(")");
        }

        return sb.toString();
    }
}
