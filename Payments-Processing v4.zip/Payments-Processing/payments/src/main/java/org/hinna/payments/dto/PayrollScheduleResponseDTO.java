package org.hinna.payments.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PayrollScheduleResponseDTO {
    private UUID id;
    private UUID employeeId;
    private String employeeName;
    private UUID employerId;
    private String employerName;
    private UUID paymentMethodId;
    private String paymentMethodName;
    private String frequency;
    private Integer dayOfMonth;
    private String dayOfWeek;
    private BigDecimal grossAmount;
    private BigDecimal netAmount;
    private BigDecimal taxRate;
    private BigDecimal deductions;
    private String description;
    private boolean isActive;
    private boolean isAchEnabled;
    private LocalDateTime nextPaymentDate;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
