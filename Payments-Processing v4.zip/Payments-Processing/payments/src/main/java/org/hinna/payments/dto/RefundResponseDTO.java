package org.hinna.payments.dto;

import lombok.Data;
import org.hinna.payments.model.enums.PaymentStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
public class RefundResponseDTO {
    private UUID id;
    private UUID paymentId;
    private BigDecimal amount;
    private PaymentStatus status;
    private String reason;
    private String refundReference;
    private LocalDateTime createdAt;
    private LocalDateTime processedAt;
}
