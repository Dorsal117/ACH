package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "location")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = {"owner", "accounts"})
@EqualsAndHashCode(of = "id")
public class Location {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(nullable = false)
    private String locationName;

    private String address;

    @ManyToOne
    @JoinColumn(name = "owner_id")
    private Account owner;

    @Column(name = "location_type")
    private String locationType;

    @OneToMany(mappedBy = "location")
    private List<Account> accounts = new ArrayList<>();

    public Location(String locationName, String address, String locationType) {
        this.locationName = locationName;
        this.address = address;
        this.locationType = locationType;
    }
}
