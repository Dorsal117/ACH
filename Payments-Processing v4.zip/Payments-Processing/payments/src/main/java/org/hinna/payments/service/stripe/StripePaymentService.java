package org.hinna.payments.service.stripe;

import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;

import jakarta.annotation.PostConstruct;

import org.hinna.payments.dto.ValidationResult;
import org.hinna.payments.model.*;
import org.hinna.payments.model.enums.PaymentStatus;
import org.hinna.payments.service.StripeService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
@Primary
public class StripePaymentService implements StripeService {

    @Value("${stripe.secretKey}")
    private String stripeSecretKey;

    @Value("${stripe.currency:cad}")
    private String defaultCurrency;

    @PostConstruct
    public void init() {
        System.out.println("Stripe key loaded: "
                + (stripeSecretKey != null ? stripeSecretKey.substring(0, 10) + "..." : "null"));
    }

    // ======================================================
    // === CORE PAYMENT LOGIC ===
    // ======================================================
    @Override
    public String createPaymentIntent(Payment payment) {
        try {
            Stripe.apiKey = stripeSecretKey;

            if (payment.getAmount() == null) {
                throw new IllegalArgumentException("Payment amount cannot be null.");
            }

            long amountInCents = payment.getAmount().multiply(BigDecimal.valueOf(100)).longValue();

            PaymentIntentCreateParams params = PaymentIntentCreateParams.builder()
                    .setAmount(amountInCents)
                    .setCurrency(defaultCurrency)
                    .setDescription(payment.getDescription() != null ? payment.getDescription() : "Payment")
                    .putMetadata("payment_id", payment.getId() != null ? payment.getId().toString() : "unknown")
                    .build();

            PaymentIntent intent = PaymentIntent.create(params);
            payment.setStatus(PaymentStatus.PROCESSING);

            return intent.getClientSecret();

        } catch (StripeException e) {
            throw new RuntimeException("Stripe API error: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new RuntimeException("Error creating PaymentIntent: " + e.getMessage(), e);
        }
    }

    // ======================================================
    // === STUBS (to satisfy interface) ===
    // ======================================================
    @Override
    public ValidationResult validateStripeKey(String apiKey) {
        return new ValidationResult(true, "Stripe key validated (stub)");
    }

    @Override
    public ValidationResult performFullTest(String apiKey) {
        return new ValidationResult(true, "Stripe full test successful (stub)");
    }

    @Override
    public String createCustomer(Account account) {
        return "cus_dummy123";
    }

    @Override
    public String updateCustomer(Account account) {
        return "cus_updated";
    }

    @Override
    public String getOrCreateCustomer(Account account) {
        return "cus_get_or_create";
    }

    @Override
    public boolean confirmPaymentIntent(String paymentIntentId) {
        return true;
    }

    @Override
    public boolean capturePaymentIntent(String paymentIntentId) {
        return true;
    }

    @Override
    public boolean cancelPaymentIntent(String paymentIntentId, String reason) {
        return true;
    }

    @Override
    public boolean processPayment(Payment payment) {
        return true;
    }

    @Override
    public boolean processRefund(Payment payment, BigDecimal amount) {
        return true;
    }

    @Override
    public String createSetupIntent(Account account) {
        return "setup_intent_dummy";
    }

    @Override
    public String createAchSetupIntent(Account account) {
        return "ach_setup_intent_dummy";
    }

    @Override
    public void refreshBankAccountDetails(PaymentMethod paymentMethod) {
        // No-op stub
    }

    @Override
    public boolean verifyBankAccountMicroDeposits(String paymentMethodId, int firstAmount, int secondAmount) {
        return false;
    }

    @Override
    public boolean attachPaymentMethod(String paymentMethodId, Account account) {
        return true;
    }

    @Override
    public boolean validatePaymentMethod(PaymentMethod paymentMethod) {
        return paymentMethod != null && paymentMethod.getLastFourDigits() != null;
    }

    @Override
    public void deletePaymentMethod(PaymentMethod paymentMethod) {
        // No-op stub
    }

    @Override
    public boolean verifyWebhookSignature(String payload, String sigHeader) {
        return true;
    }

    @Override
    public boolean charge(PaymentMethod method, long amountInCents, String currency) {
        return true;
    }

    @Override
    public void extractAndSetBrandStripe(PaymentMethod paymentMethod,
            com.stripe.model.PaymentMethod stripePaymentMethod) {
        if (stripePaymentMethod != null && stripePaymentMethod.getCard() != null) {
            paymentMethod.setBrand(stripePaymentMethod.getCard().getBrand());
            paymentMethod.setLastFourDigits(stripePaymentMethod.getCard().getLast4());
        }
    }

    @Override
    public boolean processOutgoingPayment(Payroll payroll) {
        return true;
    }
}
