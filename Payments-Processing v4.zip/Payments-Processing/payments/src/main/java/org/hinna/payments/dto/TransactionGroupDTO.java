package org.hinna.payments.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.Month;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * DTO for grouping transaction by month for display in UI
 */
@Data
public class TransactionGroupDTO {
    private int year;
    private int month;
    private String monthName;
    private List<TransactionDTO> transactions = new ArrayList<>();
    private BigDecimal total = BigDecimal.ZERO;
    private boolean isCurrentMonth;

    public TransactionGroupDTO(int year, int month) {
        this.year = year;
        this.month = month;
        this.monthName = Month.of(month).getDisplayName(TextStyle.FULL, Locale.getDefault());
    }

    public void addTransaction(TransactionDTO transaction) {
        this.transactions.add(transaction);
        if (transaction.getAmount() != null) {
            this.total = this.total.add(transaction.getAmount());
        }
    }
}
