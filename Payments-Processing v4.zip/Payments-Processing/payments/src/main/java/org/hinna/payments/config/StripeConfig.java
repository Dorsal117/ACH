package org.hinna.payments.config;

import com.stripe.Stripe;
import jakarta.annotation.PostConstruct;
import org.hinna.payments.service.StripeApiKeyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class StripeConfig {

    @Value("${stripe.api.key}")
    private String stripeApiKey;

    private final StripeApiKeyService stripeApiKeyService;

    @Autowired
    public StripeConfig(StripeApiKeyService stripeApiKeyService) {
        this.stripeApiKeyService = stripeApiKeyService;
    }

    @PostConstruct
    public void init() {
        // Initialize Stripe with API key from application properties
        if (stripeApiKey == null || stripeApiKey.isEmpty()) {
            throw new IllegalStateException("Stripe API key not configured.");
        }

        Stripe.apiKey = stripeApiKey;

        // Optionally store this key in the service for future reference
        try {
            stripeApiKeyService.storeApiKey("stripe_primary", stripeApiKey);
        } catch (Exception e) {
            // Log the error but don't fail startup
            System.err.println("Failed to store Stripe key: " + e.getMessage());
        }
    }
}
