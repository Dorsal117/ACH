package org.hinna.payments.repository;

import org.hinna.payments.model.Account;
import org.hinna.payments.model.PayrollSchedule;
import org.hinna.payments.model.Staff;
import org.hinna.payments.model.enums.PayrollFrequency;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Repository
public interface PayrollScheduleRepository extends JpaRepository<PayrollSchedule, UUID> {

    /**
     * Find active payroll schedules by employee
     */
    List<PayrollSchedule> findByEmployeeAndIsActiveTrue(Staff employee);

    /**
     * Find payroll schedules by employer
     */
    List<PayrollSchedule> findByEmployer(Account employer);

    /**
     * Find active payroll schedules by employer
     */
    List<PayrollSchedule> findByEmployerAndIsActiveTrue(Account employer);

    /**
     * Find payroll schedules by frequency
     */
    List<PayrollSchedule> findByFrequency(PayrollFrequency frequency);

    /**
     * Find payroll schedules with next payment date before specified date
     */
    List<PayrollSchedule> findByNextPaymentDateBeforeAndIsActiveTrue(LocalDateTime date);

    /**
     * Find payroll schedules by ACH payment enabled flag
     */
    List<PayrollSchedule> findByIsAchEnabledTrue();

    /**
     * Search payroll schedules by employee name
     */
    @Query("SELECT ps FROM PayrollSchedule ps WHERE " +
            "ps.employee.firstName LIKE %:searchTerm% OR " +
            "ps.employee.lastName LIKE %:searchTerm%")
    List<PayrollSchedule> searchByEmployeeName(@Param("searchTerm") String searchTerm);
}
