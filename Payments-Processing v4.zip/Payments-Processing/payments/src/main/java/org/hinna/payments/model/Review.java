package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "review")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = {"reviewer", "listing"})
@EqualsAndHashCode(of = "id")
public class Review {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "reviewer_id")
    private Account reviewer;

    @ManyToOne
    @JoinColumn(name = "listing_id")
    private Listing listing;

    @Column(nullable = false)
    private String title;

    private Integer rating;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    public Review(Account reviewer, Listing listing, String title, Integer rating) {
        this.reviewer = reviewer;
        this.listing = listing;
        this.title = title;
        this.rating = rating;
    }

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    public boolean isValidRating() {
        return rating != null && rating >= 1 && rating <= 5;
    }
}
