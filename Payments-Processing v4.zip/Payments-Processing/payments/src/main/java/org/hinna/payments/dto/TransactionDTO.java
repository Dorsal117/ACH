package org.hinna.payments.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * DTO for transaction data to be displayed in the transaction list
 */
@Data
public class TransactionDTO {
    private UUID id;
    private LocalDateTime date;
    private String service;
    private String paymentMethodType;
    private String lastFourDigits;
    private String clientName;
    private BigDecimal amount;
    private String status;

    // Additional fields for detailed view (if needed)
    private String referenceNumber;
    private String description;
}
