package org.hinna.payments.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "location_tax_rule",
        uniqueConstraints = @UniqueConstraint(columnNames = {"location_id", "tax_id", "applicable_from"}))
@Getter
@Setter
@NoArgsConstructor
public class LocationTaxRule {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "location_id", nullable = false)
    private Location location;

    @ManyToOne
    @JoinColumn(name = "tax_id", nullable = false)
    private Tax tax;

    @Column(name = "applicable_from", nullable = false)
    private LocalDate applicableFrom;

    @Column(name = "applicable_to")
    private LocalDate applicableTo;

    @Column(name = "is_active")
    private boolean isActive;

    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

}
