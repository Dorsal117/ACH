package org.hinna.payments.controller.api;

import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.dto.*;
import org.hinna.payments.model.*;
import org.hinna.payments.security.CurrentUserResolver;
import org.hinna.payments.service.PayrollService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Controller for handling payroll operations
 */
@Controller
@RequestMapping("/settings/payroll")
@Slf4j
public class PayrollController {

    private final PayrollService payrollService;
    private final CurrentUserResolver currentUserResolver;

    @Autowired
    public PayrollController(PayrollService payrollService,
                             CurrentUserResolver currentUserResolver) {
        this.payrollService = payrollService;
        this.currentUserResolver = currentUserResolver;
    }

    // =========================================== FRONTEND ENDPOINTS ==================================================

    /**
     * Display the payroll page
     */
    @GetMapping
    public String showPayrollPage(@RequestParam(value = "tab", defaultValue = "auto") String activeTab,
                                  @RequestParam(value = "employerId", required = false) UUID employerId,
                                  Model model) {
        try {
            Account currentUser = currentUserResolver.getCurrentUser();

            // Determine which tabs to show based on user type
            boolean canViewStaffPayroll = this.canViewStaffPayrolls(currentUser);
            boolean canViewPersonalPayroll = this.canViewPersonalPayrolls(currentUser);

            // Auto-select appropriate default tab
            if ("auto".equals(activeTab)) {
                if (canViewStaffPayroll) {
                    activeTab = "staff";
                } else if (canViewPersonalPayroll) {
                    activeTab = "personal";
                } else {
                    model.addAttribute("error", "No payroll access available");
                    return "layout";
                }
            }

            // Validate tab access
            if ("staff".equals(activeTab) && !canViewStaffPayroll) {
                activeTab = "personal";
            }
            if ("personal".equals(activeTab) && !canViewPersonalPayroll) {
                activeTab = "staff";
            }

            // Pass tab visibility to frontend
            model.addAttribute("showStaffTab", canViewStaffPayroll);
            model.addAttribute("showPersonalTab", canViewPersonalPayroll);
            model.addAttribute("activeTab", activeTab);
            model.addAttribute("employerId", employerId);

            // Load initial content for the active tab
            if ("staff".equals(activeTab) && canViewStaffPayroll) {
                List<PayrollDisplayDTO> staffPayrolls = this.getStaffPayrollData(employerId);

                model.addAttribute("error", "Please select an employer");
                model.addAttribute("availableEmployers", getAvailableEmployers());
                model.addAttribute("content", "payroll-select-employer");
                return "layout";

                //                model.addAttribute("activeTab", "staff");

            } else if ("personal".equals(activeTab)) {
                List<PayrollDisplayDTO> personalPayrolls = this.getPersonalPayrollData(this.getCurrentUserId());
                model.addAttribute("payrolls", personalPayrolls);
//                model.addAttribute("activeTab", "personal");
            }

            model.addAttribute("automaticPaymentsEnabled", this.getAutomaticPaymentsStatus(employerId));
            model.addAttribute("content", "payroll-page");
            return "layout";

        } catch (SecurityException e) {
            log.error("Security error in payroll page: {}", e.getMessage());
            model.addAttribute("error", "Authentication required");
            model.addAttribute("content", "error");
            return "layout";
        } catch (Exception e) {
            log.error("Error loading payroll page: {}", e.getMessage());
            model.addAttribute("error", "Error loading payroll data");
            model.addAttribute("content", "payroll-page");
            return "layout";
        }
    }

    /**
     * Handle HTMX request for staff payroll tab
     */
    @GetMapping("/fragments/staff-payroll")
    public String getStaffPayrollFragment(
            @RequestParam(value = "employerId", required = false) UUID employerId,
            Model model) {
        try {
            UUID currentEmployerId = employerId != null ? employerId : this.getCurrentEmployerIdWithFallback();

            if (currentEmployerId == null) {
                model.addAttribute("error", "Please select an employer");
                return "payroll/fragments/error :: error-message";
            }

            List<PayrollDisplayDTO> staffPayrolls = this.getStaffPayrollData(currentEmployerId);

            model.addAttribute("payrolls", staffPayrolls);
            model.addAttribute("automaticPaymentsEnabled", this.getAutomaticPaymentsStatus(currentEmployerId));
            model.addAttribute("employerId", currentEmployerId);

            return "partials/payroll-staff-table :: staff-payroll-content";

        } catch (Exception e) {
            log.error("Error loading staff payroll fragment: {}", e.getMessage());
            model.addAttribute("error", "Error loading staff payroll data");
            return "partials/error :: error-message";
        }
    }

    /**
     * Handle HTMX request for personal payroll tab
     */
    @GetMapping("/fragments/personal-payroll")
    public String getPersonalPayrollFragment(Model model)  {
        try {
            UUID currentUserId = this.getCurrentUserId();
            List<PayrollDisplayDTO> personalPayrolls = this.getPersonalPayrollData(currentUserId);

            model.addAttribute("payroll", personalPayrolls);

            return "partials/payroll-personal-content :: personal-payroll-content";

        } catch (Exception e) {
            log.error("Error loading personal payroll fragment: {}", e.getMessage());
            model.addAttribute("error", "Error loading personal payroll data");
            return "error-page";
        }
    }

    /**
     * Toggle automatic ACH payments
     */
    @PostMapping("/toggle-automatic-payments")
    @ResponseBody
    public String toggleAutomaticPayments(@RequestParam UUID employerId,
                                          @RequestParam boolean enabled) {
        try {
            if (this.canAccessEmployerData(employerId)) {
                return "unauthorized";
            }

            List<PayrollSchedule> schedules = payrollService.getSchedulesByEmployer(employerId);

            for (PayrollSchedule schedule : schedules) {
                payrollService.setAchPaymentEnabled(schedule.getId(), enabled);
            }

            log.info("Automatic payments {} for employer {}", enabled ? "enabled" : "displayed", employerId);

            return "success";

        } catch (Exception e) {
            log.error("Error toggling automatic payments: {}", e.getMessage());
            return "error";
        }
    }

    /**
     * Search and filter payroll records
     */
    @GetMapping("/search")
    public String searchPayrolls(@RequestParam(required = false) String query,
                                 @RequestParam(required = false) String role,
                                 @RequestParam(defaultValue = "staff") String tab,
                                 @RequestParam(required = false) UUID employerId,
                                 Model model) {
        try {
            List<PayrollDisplayDTO> filteredPayrolls;

            if ("staff".equals(tab)) {
                UUID currentEmployerId = employerId != null ? employerId : this.getCurrentEmployerIdWithFallback();
                if (currentEmployerId == null || this.canAccessEmployerData(currentEmployerId)) {
                    model.addAttribute("error", "Access denied");
                    return "payroll/fragments/error :: error-message";
                }

                List<Payroll> payrolls = payrollService.getPayrollsByEmployer(currentEmployerId);
                filteredPayrolls = payrolls.stream()
                        .filter(p -> this.matchesSearchCriteria(p, query, role))
                        .map(this::convertToDisplayDTO)
                        .toList();
            } else {
                List<Payroll> payrolls = payrollService.getPayrollsByEmployee(this.getCurrentUserId());
                filteredPayrolls = payrolls.stream()
                        .filter(p -> this.matchesQuery(p, query))
                        .map(this::convertToDisplayDTO)
                        .toList();
            }

            model.addAttribute("payrolls", filteredPayrolls);

            return "payroll/fragments/payroll-table :: payroll-rows";

        } catch (Exception e) {
            log.error("Error searching/filtering payrolls: {}", e.getMessage());
            model.addAttribute("error", "Error filtering payroll data");
            return "error-page";
        }
    }

    /**
     * Show payroll details modal
     */
    @GetMapping("/details/{payrollId}")
    public String showPayrollDetails(@PathVariable UUID payrollId, Model model) {
        try {
            Payroll payroll = payrollService.getPayrollById(payrollId)
                    .orElseThrow(() -> new RuntimeException("Payroll not found"));

            // Security check
            if (canAccessPayrollData(payroll)) {
                model.addAttribute("error", "Access denied to payroll details");
                return "payroll/fragments/error :: error-message";
            }

            model.addAttribute("payroll", payroll);

            return "payroll/fragments/payroll-details :: payroll-details-modal";

        } catch (Exception e) {
            log.error("Error loading payroll details: {}", e.getMessage());
            model.addAttribute("error", "Error loading payroll details");
            return "error-page";
        }
    }


    // =============================================== API ENDPOINTS ===================================================
    /**
     * Create a new payroll payment
     */
    @PostMapping("/api")
    @ResponseBody
    public ResponseEntity<Payroll> createPayroll(@RequestBody PayrollRequestDTO request) {
        log.info("Creating payroll for employeeId = {}, amount = {}", request.getEmployeeId(), request.getGrossAmount());

        try {
            Payroll payroll = payrollService.createPayroll(request);
            log.info("Payroll created successfully: {}", payroll.getId());
            return ResponseEntity.status(HttpStatus.CREATED).body(payroll);
        } catch (IllegalArgumentException e) {
            log.error("Error creating payroll: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error creating payroll: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error creating payroll");
        }
    }
    /**
     * Get a payroll by ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<Payroll> getPayrollById(@PathVariable("id") UUID id) {
        log.info("Fetching payroll with id={}", id);

        try {
            return payrollService.getPayrollById(id)
                    .map(payroll -> {
                        log.info("Payroll found: {}", payroll.getId());
                        return ResponseEntity.ok(payroll);
                    })
                    .orElseThrow(() -> {
                        log.error("Payroll not found with id={}", id);
                        return new ResponseStatusException(HttpStatus.NOT_FOUND, "Payroll not found");
                    });
        } catch (ResponseStatusException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error retrieving payroll: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving payroll");
        }
    }

    /**
     * Get a payroll by reference number
     */
    @GetMapping("/reference/{referenceNumber}")
    public ResponseEntity<Payroll> getPayrollByReference(@PathVariable("referenceNumber") String referenceNumber) {
        log.info("Fetching payroll with reference number={}", referenceNumber);

        try {
            return payrollService.getPayrollByReferenceNumber(referenceNumber)
                    .map(payroll -> {
                        log.info("Payroll found: {}", payroll.getId());
                        return ResponseEntity.ok(payroll);
                    })
                    .orElseThrow(() -> {
                        log.error("Payroll not found with reference number={}", referenceNumber);
                        return new ResponseStatusException(HttpStatus.NOT_FOUND, "Payroll not found");
                    });
        } catch (ResponseStatusException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error retrieving payroll: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving payroll");
        }
    }

    /**
     * Get payrolls by employee
     */
    @GetMapping("/employee/{employeeId}")
    public ResponseEntity<List<Payroll>> getPayrollsByEmployee(@PathVariable("employeeId") UUID employeeId) {
        log.info("Fetching payrolls for employee={}", employeeId);

        try {
            List<Payroll> payrolls = payrollService.getPayrollsByEmployee(employeeId);
            log.info("Found {} payrolls for employee", payrolls.size());
            return ResponseEntity.ok(payrolls);
        } catch (IllegalArgumentException e) {
            log.error("Error retrieving employee payrolls: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            log.error("Error retrieving employee payrolls: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving employee payrolls");
        }
    }

    /**
     * Get payrolls by employer
     */
    @GetMapping("/employer/{employerId}")
    public ResponseEntity<List<Payroll>> getPayrollsByEmployer(@PathVariable("employerId") UUID employerId) {
        log.info("Fetching payrolls for employer={}", employerId);

        try {
            List<Payroll> payrolls = payrollService.getPayrollsByEmployer(employerId);
            log.info("Found {} payrolls for employer", payrolls.size());
            return ResponseEntity.ok(payrolls);
        } catch (IllegalArgumentException e) {
            log.error("Error retrieving employer payrolls: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            log.error("Error retrieving employer payrolls: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving employer payrolls");
        }
    }

    /**
     * Process a payroll payment
     */
    @PostMapping("/{id}/process")
    @ResponseBody
    public ResponseEntity<String> processPayroll(@PathVariable("id") UUID id) {
        log.info("Processing payroll with id={}", id);

        try {
            Payroll payroll = payrollService.getPayrollById(id)
                            .orElseThrow(() -> new IllegalArgumentException("Payroll not found"));

            // Security check
            if (this.canAccessPayrollData(payroll)) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access denied");
            }

            payrollService.processPayroll(id);
            log.info("Payroll processing initiated: {}", payroll.getId());

            return ResponseEntity.ok("success");

        } catch (IllegalArgumentException e) {
            log.error("Error processing payroll: {}", e.getMessage());
            return ResponseEntity.badRequest().body("error");
        } catch (Exception e) {
            log.error("Error processing payroll: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("error");
        }
    }

    /**
     * Complete a payroll payment
     */
    @PostMapping("/{id}/complete")
    public ResponseEntity<Payroll> completePayroll(@PathVariable("id") UUID id) {
        log.info("Completing payroll with id={}", id);

        try {
            Payroll payroll = payrollService.completePayroll(id);
            log.info("Payroll completed successfully: {}", payroll.getId());
            return ResponseEntity.ok(payroll);
        } catch (IllegalArgumentException e) {
            log.error("Error completing payroll: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (IllegalStateException e) {
            log.error("Invalid state for completing payroll: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            log.error("Error completing payroll: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error completing payroll");
        }
    }

    /**
     * Cancel a payroll payment
     */
    @PostMapping("/{id}/cancel")
    public ResponseEntity<Payroll> cancelPayroll(@PathVariable("id") UUID id) {
        log.info("Cancelling payroll with id={}", id);

        try {
            Payroll payroll = payrollService.cancelPayroll(id);
            log.info("Payroll cancelled successfully: {}", payroll.getId());
            return ResponseEntity.ok(payroll);
        } catch (IllegalArgumentException e) {
            log.error("Error cancelling payroll: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (IllegalStateException e) {
            log.error("Invalid state for cancelling payroll: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            log.error("Error cancelling payroll: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error cancelling payroll");
        }
    }

    /**
     * Process all scheduled payrolls
     */
    @PostMapping("/process-scheduled")
    public ResponseEntity<ProcessResultDTO> processScheduledPayrolls() {
        log.info("Processing all scheduled payrolls");

        try {
            int processed = payrollService.processScheduledPayrolls();
            log.info("Successfully processed {} payrolls", processed);

            ProcessResultDTO result = new ProcessResultDTO(
                    processed,
                    "Successfully processed " + processed + " payrolls"
            );

            return ResponseEntity.ok(result);
        } catch (Exception e) {
            log.error("Error processing scheduled payrolls: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error processing scheduled payrolls");
        }
    }

    /**
     * Create a new payroll schedule
     */
    @PostMapping("/schedule")
    public ResponseEntity<PayrollSchedule> createPayrollSchedule(@RequestBody PayrollScheduleRequestDTO request) {
        log.info("Creating payroll schedule for employeeId={}, employerId={}",
                request.getEmployeeId(), request.getEmployerId());

        try {
            PayrollSchedule schedule = payrollService.createPayrollSchedule(request);
            log.info("Payroll schedule created successfully: {}", schedule.getId());
            return ResponseEntity.status(HttpStatus.CREATED).body(schedule);
        } catch (IllegalArgumentException e) {
            log.error("Error creating payroll schedule: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            log.error("Error creating payroll schedule: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error creating payroll schedule");
        }
    }

    /**
     * Get a payroll schedule by ID
     */
    @GetMapping("/schedule/{id}")
    public ResponseEntity<PayrollSchedule> getPayrollScheduleById(@PathVariable("id") UUID id) {
        log.info("Fetching payroll schedule with id={}", id);

        try {
            return payrollService.getPayrollScheduleById(id)
                    .map(schedule -> {
                        log.info("Payroll schedule found: {}", schedule.getId());
                        return ResponseEntity.ok(schedule);
                    })
                    .orElseThrow(() -> {
                        log.error("Payroll schedule not found with id={}", id);
                        return new ResponseStatusException(HttpStatus.NOT_FOUND, "Payroll schedule not found");
                    });
        } catch (ResponseStatusException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error retrieving payroll schedule: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving payroll schedule");
        }
    }

    /**
     * Get payroll schedules by employee
     */
    @GetMapping("/schedule/employee/{employeeId}")
    public ResponseEntity<List<PayrollSchedule>> getSchedulesByEmployee(@PathVariable("employeeId") UUID employeeId) {
        log.info("Fetching payroll schedules for employee={}", employeeId);

        try {
            List<PayrollSchedule> schedules = payrollService.getSchedulesByEmployee(employeeId);
            log.info("Found {} payroll schedules for employee", schedules.size());
            return ResponseEntity.ok(schedules);
        } catch (IllegalArgumentException e) {
            log.error("Error retrieving employee schedules: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            log.error("Error retrieving employee schedules: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving employee schedules");
        }
    }

    /**
     * Update a payroll schedule
     */
    @PutMapping("/schedule/{id}")
    public ResponseEntity<PayrollSchedule> updatePayrollSchedule(
            @PathVariable("id") UUID id,
            @RequestBody PayrollScheduleRequestDTO request) {
        log.info("Updating payroll schedule with id={}", id);

        try {
            PayrollSchedule schedule = payrollService.updatePayrollSchedule(id, request);
            log.info("Payroll schedule updated successfully: {}", schedule.getId());
            return ResponseEntity.ok(schedule);
        } catch (IllegalArgumentException e) {
            log.error("Error updating payroll schedule: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            log.error("Error updating payroll schedule: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error updating payroll schedule");
        }
    }

    /**
     * Delete a payroll schedule
     */
    @DeleteMapping("/schedule/{id}")
    public ResponseEntity<Void> deletePayrollSchedule(@PathVariable("id") UUID id) {
        log.info("Deleting payroll schedule with id={}", id);

        try {
            payrollService.deletePayrollSchedule(id);
            log.info("Payroll schedule deleted successfully");
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            log.error("Error deleting payroll schedule: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error deleting payroll schedule");
        }
    }

    /**
     * Activate a payroll schedule
     */
    @PostMapping("/schedule/{id}/activate")
    public ResponseEntity<PayrollSchedule> activateSchedule(@PathVariable("id") UUID id) {
        log.info("Activating payroll schedule with id={}", id);

        try {
            PayrollSchedule schedule = payrollService.activateSchedule(id);
            log.info("Payroll schedule activated successfully: {}", schedule.getId());
            return ResponseEntity.ok(schedule);
        } catch (IllegalArgumentException e) {
            log.error("Error activating payroll schedule: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            log.error("Error activating payroll schedule: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error activating payroll schedule");
        }
    }

    /**
     * Deactivate a payroll schedule
     */
    @PostMapping("/schedule/{id}/deactivate")
    public ResponseEntity<PayrollSchedule> deactivateSchedule(@PathVariable("id") UUID id) {
        log.info("Deactivating payroll schedule with id={}", id);

        try {
            PayrollSchedule schedule = payrollService.deactivateSchedule(id);
            log.info("Payroll schedule deactivated successfully: {}", schedule.getId());
            return ResponseEntity.ok(schedule);
        } catch (IllegalArgumentException e) {
            log.error("Error deactivating payroll schedule: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            log.error("Error deactivating payroll schedule: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error deactivating payroll schedule");
        }
    }

    /**
     * Generate payrolls from schedules
     */
    @PostMapping("/generate-scheduled")
    public ResponseEntity<ProcessResultDTO> generateScheduledPayrolls() {
        log.info("Generating payrolls from schedules");

        try {
            int generated = payrollService.generateScheduledPayrolls();
            log.info("Successfully generated {} payrolls", generated);

            ProcessResultDTO result = new ProcessResultDTO(
                    generated,
                    "Successfully generated " + generated + " payrolls"
            );

            return ResponseEntity.ok(result);
        } catch (Exception e) {
            log.error("Error generating scheduled payrolls: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error generating scheduled payrolls");
        }
    }

    /**
     * Get employee payroll summary
     */
    @GetMapping("/summary/employee/{employeeId}")
    public ResponseEntity<EmployeePayrollDTO> getEmployeePayrollSummary(
            @PathVariable("employeeId") UUID employeeId,
            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate) {
        log.info("Fetching payroll summary for employee={} from {} to {}", employeeId, startDate, endDate);

        try {
            EmployeePayrollDTO summary = payrollService.getEmployeePayrollSummary(employeeId, startDate, endDate);
            log.info("Payroll summary retrieved successfully");
            return ResponseEntity.ok(summary);
        } catch (IllegalArgumentException e) {
            log.error("Error retrieving employee payroll summary: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            log.error("Error retrieving employee payroll summary: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving employee payroll summary");
        }
    }

    /**
     * Toggle ACH payment for a schedule
     */
    @PostMapping("/schedule/{id}/ach")
    public ResponseEntity<PayrollSchedule> toggleAchPayment(
            @PathVariable("id") UUID id,
            @RequestParam("enabled") boolean enabled) {
        log.info("Setting ACH payment to {} for schedule with id={}", enabled, id);

        try {
            PayrollSchedule schedule = payrollService.setAchPaymentEnabled(id, enabled);
            log.info("ACH payment setting updated successfully for schedule: {}", schedule.getId());
            return ResponseEntity.ok(schedule);
        } catch (IllegalArgumentException e) {
            log.error("Error toggling ACH payment: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            log.error(" Unexpected error toggling ACH payment: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error toggling ACH payment");
        }
    }

    // =========================================== HELPER METHODS =====================================================

    private List<PayrollDisplayDTO> getStaffPayrollData(UUID employerId) {
        List<Payroll> payrolls = payrollService.getPayrollsByEmployer(employerId);
        return payrolls.stream()
                .map(this::convertToDisplayDTO)
                .collect(Collectors.toList());
    }

    private List<PayrollDisplayDTO> getPersonalPayrollData(UUID userId) {
        try {
            Account currentUser = currentUserResolver.getCurrentUser();

            // If the user is a Staff member, get their payrolls as an employee
            if (currentUser instanceof Staff) {
                List<Payroll> payrolls = payrollService.getPayrollsByEmployee(userId);
                return payrolls.stream()
                        .map(this::convertToDisplayDTO)
                        .collect(Collectors.toList());
            }

            return new ArrayList<>();
        } catch (Exception e) {
            log.error("Error getting personal payroll data: {}", e.getMessage());
            return new ArrayList<>();
        }
    }

    private boolean matchesSearchCriteria(Payroll payroll, String query, String role) {
        boolean queryMatch = query == null || query.trim().isEmpty() || this.matchesQuery(payroll, query);
        boolean roleMatch = role == null || role.isEmpty() || this.matchesRole(payroll, role);

        return queryMatch && roleMatch;
    }

    private boolean matchesQuery(Payroll payroll, String query) {
        if (query == null || query.trim().isEmpty()) return true;

        String lowerQuery = query.toLowerCase();
        return payroll.getEmployee().getFullName().toLowerCase().contains(lowerQuery) ||
                payroll.getReferenceNumber().toLowerCase().contains(lowerQuery) ||
                (payroll.getDescription() != null && payroll.getDescription().toLowerCase().contains(lowerQuery));
    }

    private boolean matchesRole(Payroll payroll, String role) {
        Staff staff = payroll.getEmployee();
        return staff.getPosition() != null && staff.getPosition().equals(role);
    }

    private PayrollDisplayDTO convertToDisplayDTO(Payroll payroll) {
        PayrollDisplayDTO dto = new PayrollDisplayDTO();
        dto.setId(payroll.getId().toString());
        dto.setStaffName(payroll.getEmployee().getFullName());
        dto.setSalary("$" + payroll.getNetAmount().toString());
        dto.setPaymentDate(payroll.getScheduledDate() != null ?
                payroll.getScheduledDate().toString() : "Not scheduled");
        dto.setPaymentMethod(payroll.getPaymentMethod() != null ?
                payroll.getPaymentMethod().getType().getDisplayName() : "Not set");

        Staff staff = payroll.getEmployee();
        dto.setRole(staff.getPosition() != null ? staff.getPosition() : "Staff Member");

        return dto;
    }

    private boolean getAutomaticPaymentsStatus(UUID employerId) {
        if (employerId == null) return false;

        try {
            List<PayrollSchedule> schedules = payrollService.getSchedulesByEmployer(employerId);
            return schedules.stream().anyMatch(PayrollSchedule::isAchEnabled);
        } catch (Exception e) {
            log.error("Error getting automatic payments status: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Get current user ID using CurrentUserResolver
     */
    private UUID getCurrentUserId() {
        try {
            Account currentUser = currentUserResolver.getCurrentUser();
            return currentUser.getId();
        } catch (Exception e) {
            log.error("Error getting current user ID: {}", e.getMessage());
            throw new SecurityException("Error retrieving current user", e);
        }
    }

    /**
     * Get current user's employer ID with fallback
     */
    private UUID getCurrentEmployerIdWithFallback() {
        try {
            Account currentUser = currentUserResolver.getCurrentUser();

            // If current user is a Staff member, get their employer
            if (currentUser instanceof Staff staff) {
                if (staff.getEmployer() != null) {
                    return staff.getEmployer().getId();
                }
            }

            // If current user is a DirectCustomer (business owner), they are the employer
            if (currentUser instanceof DirectCustomer) {
                return currentUser.getId();
            }

            // For other account types, return null to trigger employer selection
            return null;
        } catch (Exception e) {
            log.warn("Could not determine employer ID automatically: {}", e.getMessage());
            return null;
        }
    }

    /**
     * Check if current user can access employer data
     */
    private boolean canAccessEmployerData(UUID employerId) {
        try {
            Account currentUser = currentUserResolver.getCurrentUser();

            // If they are the employer (DirectCustomer), they can access
            if (currentUser.getId().equals(employerId)) {
                return false;
            }

            // If they are staff working for this employer
            if (currentUser instanceof Staff staff) {
                return staff.getEmployer() == null || !staff.getEmployer().getId().equals(employerId);
            }

            // If they are a reseller managing this customer
            if (currentUser instanceof ResellerAccount reseller) {
                return reseller.getCustomers().stream()
                        .noneMatch(customer -> customer.getId().equals(employerId));
            }

            return true;
        } catch (Exception e) {
            log.error("Error checking employer access: {}", e.getMessage());
            return true;
        }
    }

    /**
     * Check if current user can access specific payroll data
     */
    private boolean canAccessPayrollData(Payroll payroll) {
        try {
            Account currentUser = currentUserResolver.getCurrentUser();

            // Can access if it's their own payroll (as employee)
            if (payroll.getEmployee().getId().equals(currentUser.getId())) {
                return false;
            }

            // Can access if they're the employer processing this payroll
            if (payroll.getProcessingAccount().getId().equals(currentUser.getId())) {
                return false;
            }

            // Can access if they can access the employer's data
            return canAccessEmployerData(payroll.getProcessingAccount().getId());

        } catch (Exception e) {
            log.error("Error checking payroll access: {}", e.getMessage());
            return true;
        }
    }

    /**
     * Get list of employers current user can access (for selection dropdown)
     */
    private List<Account> getAvailableEmployers() {
        try {
            Account currentUser = currentUserResolver.getCurrentUser();

            // If they're a DirectCustomer, they can only access their own data
            if (currentUser instanceof DirectCustomer) {
                return List.of(currentUser);
            }

            // If they're a reseller, they can access their customers
            if (currentUser instanceof ResellerAccount reseller) {
                return reseller.getCustomers().stream()
                        .map(customer -> (Account) customer)
                        .collect(Collectors.toList());
            }

            // For other types, return empty list
            return List.of();

        } catch (Exception e) {
            log.error("Error getting available employers: {}", e.getMessage());
            return List.of();
        }
    }

    private boolean canViewStaffPayrolls(Account user) {
        // DirectCustomer can always view staff payroll (their own staff)
        if (user instanceof DirectCustomer) return true;

        // Staff with payroll-admin permission/role
        if (user instanceof Staff staff && Boolean.TRUE.equals(staff.getIsAdmin())) return true;

        // Optional: other advance business logic
        return false;
    }

    private boolean canViewPersonalPayrolls(Account user) {
        // Only staff can view received payroll
        return user instanceof Staff;
    }
}
