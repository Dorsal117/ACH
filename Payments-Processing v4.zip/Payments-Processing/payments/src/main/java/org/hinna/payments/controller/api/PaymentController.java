package org.hinna.payments.controller.api;

import org.hinna.payments.dto.StripeResponseDTO;
import org.hinna.payments.model.Payment;
import org.hinna.payments.service.StripeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.hinna.payments.dto.PaymentRequestDTO;
import org.hinna.payments.dto.PaymentResponseDTO;
import org.hinna.payments.dto.RefundRequestDTO;
import org.hinna.payments.dto.RefundResponseDTO;
import org.hinna.payments.model.*;
import org.hinna.payments.service.*;
import org.hinna.payments.service.impl.PaymentCalculationServiceImpl;
import org.hinna.payments.model.Account;
import org.hinna.payments.model.PaymentMethod;
import org.hinna.payments.model.Refund;
import org.hinna.payments.service.AccountService;
import org.hinna.payments.service.PaymentMethodService;
import org.hinna.payments.service.PaymentService;
import org.hinna.payments.model.*;
import org.hinna.payments.service.*;
import org.hinna.payments.service.impl.PaymentCalculationServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.HashMap;
import java.util.Map;

/**
 * Core payment functionality (create/process payments, view payment history,
 * basic operations used by regular users)
 */
@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentService paymentService;
    private final AccountService accountService;
    private final PaymentMethodService paymentMethodService;
    private final StripeService stripeService;
    private final PaymentCalculationServiceImpl paymentCalculationServiceImpl;

    @Autowired
    public PaymentController(PaymentService paymentService,
            AccountService accountService,
            PaymentMethodService paymentMethodService,
            StripeService stripeService,
            PaymentCalculationServiceImpl paymentCalculationServiceImpl) {
        this.paymentService = paymentService;
        this.accountService = accountService;
        this.paymentMethodService = paymentMethodService;
        this.stripeService = stripeService;
        this.paymentCalculationServiceImpl = paymentCalculationServiceImpl;
    }

    @PostMapping("/checkout/integrated")
    public ResponseEntity<StripeResponseDTO> checkoutProducts(@RequestBody Payment payment) {
        try {
            String clientSecret = stripeService.createPaymentIntent(payment);
            StripeResponseDTO response = new StripeResponseDTO();
            response.setClientSecret(clientSecret);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to create payment intent: " + e.getMessage());
        }
    }

    /**
     * Create a payment
     * 
     * @param paymentRequestDTO PaymentRequestDTO
     */
    @PostMapping
    public ResponseEntity<PaymentResponseDTO> createPayment(@RequestBody PaymentRequestDTO paymentRequestDTO) {
        try {
            // Validate customer exists
            Account customer = accountService.getAccountById(paymentRequestDTO.getCustomerId())
                    .orElseThrow(() -> new IllegalArgumentException("Customer not found"));

            // Validate payment method exists and belongs to customer
            PaymentMethod paymentMethod = paymentMethodService
                    .getPaymentMethodById(paymentRequestDTO.getPaymentMethodId())
                    .orElseThrow(() -> new IllegalArgumentException("Payment method not found"));

            if (!paymentMethod.getOwner().getId().equals(customer.getId())) {
                throw new IllegalArgumentException("Payment method does not belong to customer");
            }

            BigDecimal calculatedTotal = paymentCalculationServiceImpl.calculateTotal(paymentRequestDTO.getAmount());
            Payment payment = new Payment(customer, calculatedTotal, paymentMethod);
            payment.setCurrency(paymentRequestDTO.getCurrency());
            payment.setDescription(paymentRequestDTO.getDescription());
            payment.setReferenceNumber(paymentRequestDTO.getReferenceNumber());

            Payment created = paymentService.createPayment(payment);

            // Create Stripe PaymentIntent
            String clientSecret = stripeService.createPaymentIntent(created);

            // Set the client secret as the reference number if needed (optional)
            created.setReferenceNumber(clientSecret);

            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(this.convertToPaymentResponseDTO(created));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to create payment");
        }
    }

    /**
     * Process a payment
     * 
     * @param id ID of the payment to process
     */
    @PostMapping("/{id}/process")
    public ResponseEntity<PaymentResponseDTO> processPayment(@PathVariable UUID id) {
        try {
            Payment payment = paymentService.getPaymentById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Payment not found"));

            // Attempt to process the payment with Stripe
            boolean success = stripeService.processPayment(payment);
            if (!success) {
                throw new RuntimeException("Stripe payment processing failed or deferred.");
            }

            // Update payment status in our system
            Payment processed = paymentService.processPayment(id);
            return ResponseEntity.ok(this.convertToPaymentResponseDTO(processed));
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to process payment", e);
        }
    }

    /**
     * Cancel a payment
     * 
     * @param id ID of the payment to cancel
     */
    @PostMapping("/{id}/cancel")
    public ResponseEntity<PaymentResponseDTO> cancelPayment(@PathVariable UUID id) {
        try {
            Payment cancelledPayment = paymentService.cancelPayment(id);
            return ResponseEntity.ok(this.convertToPaymentResponseDTO(cancelledPayment));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to cancel payment");
        }
    }

    /**
     * Refund a payment
     * 
     * @param id               ID of the payment to refund
     * @param refundRequestDTO RefundRequestDTO
     */
    @PostMapping("/{id}/refund")
    public ResponseEntity<RefundResponseDTO> refundPayment(@PathVariable UUID id,
            @RequestBody RefundRequestDTO refundRequestDTO) {
        try {
            Payment payment = paymentService.getPaymentById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Payment not found"));

            boolean refunded = stripeService.processRefund(payment, refundRequestDTO.getAmount());
            if (!refunded) {
                throw new RuntimeException("Stripe refund failed");
            }

            Refund refund = paymentService.refundPayment(id, refundRequestDTO.getAmount(),
                    refundRequestDTO.getReason());

            return ResponseEntity.ok(convertToRefundResponseDTO(refund));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to refund payment");
        }
    }

    /**
     * Get a payment by ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<PaymentResponseDTO> getPaymentById(@PathVariable UUID id) {
        return paymentService.getPaymentById(id)
                .map(payment -> ResponseEntity.ok(this.convertToPaymentResponseDTO(payment)))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Payment not found"));
    }

    /**
     * Get all payments made by a customer
     * 
     * @param customerId ID of the customer
     */
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<PaymentResponseDTO>> getPaymentsByCustomer(@PathVariable UUID customerId) {
        try {
            Account customer = accountService.getAccountById(customerId)
                    .orElseThrow(() -> new IllegalArgumentException("Customer not found"));

            List<Payment> payments = paymentService.getPaymentsByCustomer(customer);
            List<PaymentResponseDTO> paymentResponseDTOs = payments.stream()
                    .map(this::convertToPaymentResponseDTO)
                    .collect(Collectors.toList());

            return ResponseEntity.ok(paymentResponseDTOs);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }

    /**
     * Convert Payment to PaymentResponseDTO
     * 
     * @param payment Payment Java object
     * @return PaymentResponseDTO
     */
    private PaymentResponseDTO convertToPaymentResponseDTO(Payment payment) {
        PaymentResponseDTO dto = new PaymentResponseDTO();
        dto.setId(payment.getId());
        dto.setAmount(payment.getAmount());
        dto.setStatus(payment.getStatus());
        dto.setCustomerId(payment.getCustomer().getId());
        dto.setCustomerName(payment.getCustomer().getFullName());
        dto.setPaymentMethodId(payment.getMethod().getId());
        dto.setPaymentMethodType(payment.getMethod().getType());
        dto.setCreatedAt(payment.getCreatedAt());
        dto.setProcessedAt(payment.getProcessedAt());
        dto.setReferenceNumber(payment.getReferenceNumber());
        dto.setDescription(payment.getDescription());
        dto.setCurrency(payment.getCurrency());
        return dto;
    }

    /**
     * Convert Refund to RefundResponseDTO
     * 
     * @param refund Refund Java object
     * @return RefundResponseDTO
     */
    private RefundResponseDTO convertToRefundResponseDTO(Refund refund) {
        RefundResponseDTO dto = new RefundResponseDTO();
        dto.setId(refund.getId());
        dto.setPaymentId(refund.getPayment().getId());
        dto.setAmount(refund.getAmount());
        dto.setStatus(refund.getStatus());
        dto.setReason(refund.getDescription());
        dto.setRefundReference(refund.getRefundReference());
        dto.setCreatedAt(refund.getCreatedAt());
        dto.setProcessedAt(refund.getProcessedAt());

        return dto;
    }

    @Controller
    @RequestMapping("/payment")
    public static class PaymentPageController {

        @GetMapping("/form")
        public String showPaymentForm() {
            return "PaymentForm"; // refers to templates/PaymentForm.html
        }

        @GetMapping("/confirmation")
        public String showPaymentConfirmation() {
            return "PaymentConfirmation"; // refers to templates/PaymentConfirmation.html
        }
    }

    // Serve the PaymentForm.html template
    @GetMapping("/form")
    public String getPaymentForm() {
        return "PaymentForm"; // must match the filename in /templates
    }

    // API endpoint for Stripe (still returns JSON)
    @PostMapping("/create-payment-intent")
    @ResponseBody
    public ResponseEntity<Map<String, String>> createPaymentIntent(@RequestBody Payment payment) {
        try {
            String clientSecret = stripeService.createPaymentIntent(payment);

            Map<String, String> response = new HashMap<>();
            response.put("clientSecret", clientSecret);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            e.printStackTrace();
            Map<String, String> error = new HashMap<>();
            error.put("error", "Could not create payment intent: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    @GetMapping("/confirmation")
    public String showConfirmationPage() {
        return "PaymentConfirmation";

    }
}
