package org.hinna.payments.integration.user.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.integration.user.dto.*;
import org.hinna.payments.model.*;
import org.hinna.payments.model.enums.PaymentStatus;
import org.hinna.payments.repository.BillingHistoryRepository;
import org.hinna.payments.repository.PaymentRepository;
import org.hinna.payments.service.AccountService;
import org.hinna.payments.service.PaymentMethodService;
import org.hinna.payments.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.hinna.payments.controller.api.AccountController.getString;

@RestController
@RequestMapping("/api/vi/integration")
@Tag(name = "Integration", description = "APIs for Login-User Service integration")
@Validated
@Slf4j
public class IntegrationController {

    private final AccountService accountService;
    private final PaymentService paymentService;
    private final PaymentMethodService paymentMethodService;
    private final BillingHistoryRepository billingHistoryRepository;
    private final PaymentRepository paymentRepository;

    @Autowired
    public IntegrationController(AccountService accountService,
                                 PaymentService paymentService,
                                 PaymentMethodService paymentMethodService, BillingHistoryRepository billingHistoryRepository, PaymentRepository paymentRepository) {
        this.accountService = accountService;
        this.paymentService = paymentService;
        this.paymentMethodService = paymentMethodService;
        this.billingHistoryRepository = billingHistoryRepository;
        this.paymentRepository = paymentRepository;
    }

    /**
     * Verify if a user has an account in the payment system
     */
    @Operation(
            summary = "Verify account existence",
            description = "Check if a user from the User Service has an account in the Payment System",
            tags = {"Integration"}
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Account verification information",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = AccountVerificationResponse.class)
                    )
            ),
            @ApiResponse(responseCode = "401", description = "Unauthorized - invalid credentials"),
            @ApiResponse(responseCode = "403", description = "Forbidden - insufficient permissions")
    })
    @GetMapping("/account/verify/{userId}")
    public ResponseEntity<AccountVerificationResponse> verifyAccount(
            @Parameter(description = "User ID from User Service")
            @PathVariable Long userId) {

        log.info("Received account verification request for user ID: {}", userId);

        Optional<Account> accountOpt = accountService.getAccountByExternalUserId(userId);

        if (accountOpt.isEmpty()) {
            log.info("No account found for user ID: {}", userId);
            return ResponseEntity.ok(new AccountVerificationResponse(false, null, null));
        }

        Account account = accountOpt.get();
        String accountType = this.determineAccountType(account);

        AccountVerificationResponse response = new AccountVerificationResponse(
                true,
                account.isActive(),
                accountType
        );

        log.info("Returning account verification for user ID: {}: {}", userId, response);
        return ResponseEntity.ok(response);
    }

    /**
     * Link a user account from User Service to an account in Payment System
     */
    @Operation(
            summary = "Link user to payment account",
            description = "Links a user from the Login-User Service to an account in the Payment System",
            tags = {"Integration"}
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Account successfully linked",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = AccountLinkResponse.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Bad request - invalid parameters"
            ),
            @ApiResponse(responseCode = "404", description = "Account not found"),
            @ApiResponse(responseCode = "409", description = "User already linked to another account")
    })
    @PostMapping("/account/link")
    public ResponseEntity<AccountLinkResponse> linkAccount(@RequestBody @Validated AccountLinkRequest request) {
        log.info("Received account link request: {}", request);

        try {
            Account account = accountService.linkExternalUser(request.getAccountId(), request.getUserId());

            AccountLinkResponse response = new AccountLinkResponse(
                    true,
                    account.getId(),
                    request.getUserId(),
                    "Account successfully linked"
            );

            log.info("Successfully linked account {} to user {}",
                    request.getAccountId(),
                    request.getUserId());

            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            log.warn("Failed to link account: {}", e.getMessage());

            AccountLinkResponse response = new AccountLinkResponse(
                    false,
                    request.getAccountId(),
                    request.getUserId(),
                    e.getMessage()
            );

            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    /**
     * Get payment history for a user
     */
    @Operation(
            summary = "Get user payment history",
            description = "Retrieves payment history for a specific user from the User Service",
            tags = {"Integration"}
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Payment history retrieved successfully",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = PaymentHistoryResponse.class)
                    )
            ),
            @ApiResponse(responseCode = "404", description = "User not found")
    })
    @GetMapping("/user/{userId}/payments")
    public ResponseEntity<PaymentHistoryResponse> getPaymentHistory(
            @Parameter(description = "User ID from User Service")
            @PathVariable Long userId,
            @Parameter(description = "Page number (zero-based)")
            @RequestParam(defaultValue = "0") int page,
            @Parameter(description = "Page size")
            @RequestParam(defaultValue = "20") int size) {

        log.info("Retrieving payment history for user ID: {}", userId);

        Optional<Account> accountOpt = accountService.getAccountByExternalUserId(userId);

        if (accountOpt.isEmpty()) {
            log.warn("No account found for user ID: {}", userId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
                    new PaymentHistoryResponse(
                            false,
                            "User not found",
                            null,
                            0,
                            0,
                            0
                    )
            );
        }

        Account account = accountOpt.get();

        Page<Payment> paymentsPage = paymentService.getPaymentsByCustomer(
                account,
                PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"))
        );

        List<PaymentSummaryDTO> paymentSummaries = paymentsPage.getContent().stream()
                .map(payment -> new PaymentSummaryDTO(
                        payment.getId(),
                        payment.getAmount(),
                        payment.getStatus().name(),
                        payment.getCreatedAt(),
                        payment.getProcessedAt(),
                        payment.getReferenceNumber(),
                        payment.getDescription(),
                        payment.getMethod() != null ? payment.getMethod().getType().getDisplayName() : "Unknown"
                ))
                .toList();

        PaymentHistoryResponse response = new PaymentHistoryResponse(
                true,
                "Payment history retrieved successfully",
                paymentSummaries,
                paymentsPage.getNumber(),
                paymentsPage.getSize(),
                paymentsPage.getTotalElements()
        );

        log.info("Returning payment history for user ID: {}: {} payments",
                userId,
                paymentSummaries.size());

        return ResponseEntity.ok(response);
    }

    /**
     * Get payment methods for a user
     */
    @Operation(
            summary = "Get user payment methods",
            description = "Retrieves available payment methods for a specific user",
            tags = {"Integration"}
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Payment methods retrieved successfully",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = PaymentMethodsResponse.class)
                    )
            ),
            @ApiResponse(responseCode = "404", description = "User not found")
    })
    @GetMapping("/user/{userId}/payment-methods")
    public ResponseEntity<PaymentMethodsResponse> getPaymentMethods(
            @Parameter(description = "User ID from Login-User Service")
            @PathVariable Long userId) {

        log.info("Retrieving payment methods for user ID: {}", userId);

        Optional<Account> accountOpt = accountService.getAccountByExternalUserId(userId);

        if (accountOpt.isEmpty()) {
            log.warn("No account found for user ID: {}", userId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
                    new PaymentMethodsResponse(
                            false,
                            "User not found",
                            null
                    )
            );
        }

        Account account = accountOpt.get();

        List<PaymentMethod> paymentMethods = paymentMethodService.getActivePaymentMethodsByOwner(account);

        List<PaymentMethodDTO> paymentMethodDTOs = paymentMethods.stream()
                .map(pm -> new PaymentMethodDTO(
                        pm.getId(),
                        pm.getType().name(),
                        pm.getLastFourDigits(),
                        pm.getExpiryDate(),
                        pm.getIsDefault(),
                        pm.getDisplayName(),
                        pm.getBrand(),
                        pm.getWalletType()
                ))
                .toList();

        PaymentMethodsResponse response = new PaymentMethodsResponse(
                true,
                "Payment methods retrieved successfully",
                paymentMethodDTOs
        );

        log.info("Returning {} payments methods for user ID: {}",
                paymentMethods.size(),
                userId);

        return ResponseEntity.ok(response);
    }

    /**
     * Get account balance or credit
     */
    @Operation(
            summary = "Get user balance",
            description = "Retrieves current account balance or credit for a specific user",
            tags = {"Integration"}
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Balance information retrieved successfully",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = BalanceResponse.class)
                    )
            ),
            @ApiResponse(responseCode = "404", description = "User not found")
    })
    @GetMapping("/user/{userId}/balance")
    public ResponseEntity<BalanceResponse> getBalance(
            @Parameter(description = "User ID from User Service")
            @PathVariable Long userId) {

        log.info("Retrieving balance for user ID: {}", userId);

        Optional<Account> accountOpt = accountService.getAccountByExternalUserId(userId);

        if (accountOpt.isEmpty()) {
            log.warn("No account found for user ID: {}", userId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
                    new BalanceResponse(
                            false,
                            "User not found",
                            null,
                            null,
                            null
                    )
            );
        }

        Account account = accountOpt.get();

        // Get balance or credit based on account type
        BigDecimal balance = calculateBalance(account);
        BigDecimal availableCredit = getAvailableCredit(account);
        BigDecimal pendingTransactions = getPendingTransactions(account);

        BalanceResponse response = new BalanceResponse(
                true,
                "Balance information retrieved successfully",
                balance,
                availableCredit,
                pendingTransactions
        );

        log.info("Returning balance information for user ID: {}", userId);
        return ResponseEntity.ok(response);
    }

    /**
     * Create a new account in the payment system for a user from the Login-Register microservice
     */
    @PostMapping("/account/create")
    public ResponseEntity<AccountCreationResponse> createAccount(@RequestBody AccountCreationRequest request) {
        log.info("Received request to create account for user ID: {}, role: {}",
                request.getUserId(),
                request.getRole());

        try {
            // Create appropriate account type based on user profile
            Account account = accountService.createAccountForExternalUser(request);

            log.info("Created new account with ID: {} for external user ID: {}",
                    account.getId(),
                    request.getUserId());

            return ResponseEntity.ok(new AccountCreationResponse(
                    true,
                    account.getId(),
                    request.getUserId(),
                    "Account successfully created"
            ));
        } catch (IllegalArgumentException e) {
            log.warn("Failed to create account: {}", e.getMessage());
            return ResponseEntity.badRequest().body(
                    new AccountCreationResponse(
                            false,
                            null,
                            request.getUserId(),
                            e.getMessage()
                    )
            );
        } catch (Exception e) {
            log.error("Error creating account for user ID: {}", request.getUserId(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
                    new AccountCreationResponse(
                            false,
                            null,
                            request.getUserId(),
                            "Failed to create account: " + e.getMessage()
                    )
            );
        }
    }

    /**
     * Helper method to determine account type
     */
    private String determineAccountType(Account account) {
        // Determine account type based on class
        return getString(account);
    }

    /**
     * Health check endpoint
     */
    @Operation(
            summary = "Integration health check",
            description = "Checks if the Payment System integration API is available",
            tags = {"Integration"}
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "System is healthy",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = Map.class)
                    )
            )
    })
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> healthCheck() {
        Map<String, Object> response = Map.of(
                "status", "UP",
                "service", "Payment Service",
                "version", "1.0.0",
                "timestamp", System.currentTimeMillis()
        );

        return ResponseEntity.ok(response);
    }

    /**
     * Helper method to calculate balance
     */
    private BigDecimal calculateBalance(Account account) {
        // For DirectCustomer, can return their credit balance
        if (account instanceof DirectCustomer customer) {
            return customer.getCredit() != null ? customer.getCredit() : BigDecimal.ZERO;
        }

        // For other account types, need to calculate from transaction history
        List<BillingHistory> billingRecords = billingHistoryRepository.findByAccount(account);

        if (billingRecords == null || billingRecords.isEmpty()) {
            return BigDecimal.ZERO;
        }

        // Sum all transaction amounts
        return billingRecords.stream()
                .map(BillingHistory::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * Helper method to get available credit
     */
    private BigDecimal getAvailableCredit(Account account) {
        // Only DirectCustomer has credit
        if (account instanceof DirectCustomer customer) {
            return customer.getCredit() != null ? customer.getCredit() : BigDecimal.ZERO;
        }

        // Other account types don't have credit
        return BigDecimal.ZERO;
    }

    /**
     * Helper method to get pending transactions
     */
    private BigDecimal getPendingTransactions(Account account) {
        // Get all payments with PENDING or PROCESSING status
        List<Payment> pendingPayments = paymentRepository.findByCustomerAndStatusIn(
                account,
                Arrays.asList(PaymentStatus.PENDING, PaymentStatus.PROCESSING)
        );

        if (pendingPayments == null || pendingPayments.isEmpty()) {
            return BigDecimal.ZERO;
        }

        // Sum all pending payment amounts
        return pendingPayments.stream()
                .map(Payment::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
