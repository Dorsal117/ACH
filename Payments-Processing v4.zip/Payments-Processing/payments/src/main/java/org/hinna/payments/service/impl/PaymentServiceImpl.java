package org.hinna.payments.service.impl;

import jakarta.transaction.Transactional;
import org.hinna.payments.model.*;
import org.hinna.payments.model.enums.PaymentStatus;
import org.hinna.payments.model.enums.TransactionStatus;
import org.hinna.payments.model.enums.PaymentType;
import org.hinna.payments.repository.BillingHistoryRepository;
import org.hinna.payments.repository.PaymentRepository;
import org.hinna.payments.repository.PaymentTransactionRepository;
import org.hinna.payments.repository.RefundRepository;
import org.hinna.payments.service.PaymentService;
import org.hinna.payments.service.StripeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;
    private final PaymentTransactionRepository transactionRepository;
    private final BillingHistoryRepository billingHistoryRepository;
    private final RefundRepository refundRepository;
    private final StripeService stripeService;

    @Autowired
    public PaymentServiceImpl(
            PaymentRepository paymentRepository,
            PaymentTransactionRepository transactionRepository,
            BillingHistoryRepository billingHistoryRepository,
            RefundRepository refundRepository,
            StripeService stripeService) {
        this.paymentRepository = paymentRepository;
        this.transactionRepository = transactionRepository;
        this.billingHistoryRepository = billingHistoryRepository;
        this.refundRepository = refundRepository;
        this.stripeService = stripeService;
    }

    @Override
    public Payment createPayment(Payment payment) {
        Payment savedPayment = paymentRepository.save(payment);

        // Create initial transaction record
        PaymentTransaction transaction = new PaymentTransaction(
                savedPayment,
                TransactionStatus.INITIATED,
                savedPayment.getAmount());
        transaction.setMessage("Payment initiated");
        transactionRepository.save(transaction);

        // Create billing history record
        BillingHistory billingRecord = new BillingHistory(
                savedPayment.getCustomer(),
                savedPayment.getAmount(),
                "PAYMENT_INITIATED");
        billingRecord.setDescription("Payment initiated: " + savedPayment.getReferenceNumber());
        billingRecord.setPayment(savedPayment);
        billingHistoryRepository.save(billingRecord);

        return savedPayment;
    }

    @Override
    public Optional<Payment> getPaymentById(UUID paymentId) {
        return paymentRepository.findById(paymentId);
    }

    @Override
    public Optional<Payment> getPaymentByReferenceNumber(String referenceNumber) {
        return paymentRepository.findByReferenceNumber(referenceNumber);
    }

    @Override
    public Page<Payment> getAllPayments(Pageable pageable) {
        return paymentRepository.findAll(pageable);
    }

    @Override
    public List<Payment> getPaymentsByCustomer(Account customer) {
        return paymentRepository.findByCustomer(customer);
    }

    @Override
    public List<Payment> getPaymentsByStatus(PaymentStatus status) {
        return paymentRepository.findByStatus(status);
    }

    @Override
    public List<Payment> getPaymentsByMethod(PaymentMethod method) {
        return paymentRepository.findByMethod(method);
    }

    @Override
    public List<Payment> getPaymentsByDateRange(LocalDateTime start, LocalDateTime end) {
        return paymentRepository.findByCreatedAtBetween(start, end);
    }

    /**
     * Process a payment by ID.
     * 
     * @param id payment ID
     * @return captured payment if success, or else updated failed transaction.
     */
    @Override
    @Transactional
    public Payment processPayment(UUID id) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Payment not found"));

        if (payment.getStatus() != PaymentStatus.PENDING) {
            throw new IllegalArgumentException("Payment is not in a processable state");
        }

        // Update payment status
        payment.setStatus(PaymentStatus.PROCESSING);
        Payment updatedPayment = paymentRepository.save(payment);

        // Create transaction record
        PaymentTransaction transaction = new PaymentTransaction(
                updatedPayment,
                TransactionStatus.INITIATED,
                updatedPayment.getAmount());
        transaction.setMessage("Payment processing initiated");
        transactionRepository.save(transaction);

        // Process payment thorough Stripe or other processor (that might be integrated
        // in the future)
        try {
            boolean success = stripeService.processPayment(updatedPayment);

            if (success) {
                PaymentMethod method = updatedPayment.getMethod();
                boolean isAchDebit = method != null && method.getType() == PaymentType.BANK_TRANSFER;

                if (isAchDebit) {
                    PaymentTransaction pendingTransaction = new PaymentTransaction(
                            updatedPayment,
                            TransactionStatus.PENDING,
                            updatedPayment.getAmount());
                    pendingTransaction.setMessage("ACH debit initiated; awaiting bank confirmation");
                    transactionRepository.save(pendingTransaction);

                    BillingHistory pendingRecord = new BillingHistory(
                            updatedPayment.getCustomer(),
                            updatedPayment.getAmount(),
                            "PAYMENT_PROCESSING");
                    pendingRecord.setDescription("ACH payment processing: " + updatedPayment.getReferenceNumber());
                    pendingRecord.setPayment(updatedPayment);
                    billingHistoryRepository.save(pendingRecord);

                    return updatedPayment;
                }

                return this.capturePayment(id);
            }

        } catch (Exception e) {
            // Handle exception
            updatedPayment.setStatus(PaymentStatus.FAILED);
            paymentRepository.save(updatedPayment);

            // Log error transaction
            PaymentTransaction errorTransaction = new PaymentTransaction(
                    updatedPayment,
                    TransactionStatus.ERROR,
                    updatedPayment.getAmount());
            errorTransaction.setMessage("Payment processing error: " + e.getMessage());
            transactionRepository.save(errorTransaction);

            // Create billing history record
            BillingHistory billingRecord = new BillingHistory(updatedPayment.getCustomer(),
                    updatedPayment.getAmount(), "PAYMENT_ERROR");
            billingRecord.setDescription("Payment error: " + updatedPayment.getReferenceNumber());
            billingRecord.setPayment(updatedPayment);
            billingHistoryRepository.save(billingRecord);

            throw new RuntimeException("Payment processing failed", e);
        }
        return updatedPayment;
    }

    @Override
    @Transactional
    public Payment capturePayment(UUID id) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Payment not found"));

        if (payment.getStatus() != PaymentStatus.PROCESSING) {
            throw new IllegalArgumentException("Payment is not in a processable state");
        }

        // Update payment status
        payment.setStatus(PaymentStatus.COMPLETED);
        payment.setProcessedAt(LocalDateTime.now());
        Payment updatedPayment = paymentRepository.save(payment);

        // Create transaction record
        PaymentTransaction transaction = new PaymentTransaction(
                updatedPayment,
                TransactionStatus.SUCCESS,
                updatedPayment.getAmount());
        transaction.setMessage("Payment captured successfully");
        transactionRepository.save(transaction);

        // Create billing history record
        BillingHistory billingRecord = new BillingHistory(updatedPayment.getCustomer(),
                updatedPayment.getAmount(), "PAYMENT_COMPLETED");
        billingRecord.setDescription("Payment completed: " + updatedPayment.getReferenceNumber());
        billingRecord.setPayment(updatedPayment);
        billingHistoryRepository.save(billingRecord);

        return updatedPayment;
    }

    @Override
    public Refund refundPayment(UUID id, BigDecimal amount, String reason) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Payment not found"));

        if (payment.getStatus() != PaymentStatus.COMPLETED) {
            throw new IllegalArgumentException("Payment is not in a refundable state");
        }

        if (amount.compareTo(payment.getAmount()) > 0) {
            throw new IllegalArgumentException("Refund amount exceeds payment amount");
        }

        // Create refund record
        Refund refund = new Refund(payment, amount);
        refund.setDescription(reason);
        refund.setStatus(PaymentStatus.PENDING);
        Refund savedRefund = refundRepository.save(refund);

        try {
            // Process refund through Stripe or other processor
            boolean success = stripeService.processRefund(payment, amount);

            if (success) {
                // Updated refund status
                savedRefund.setStatus(PaymentStatus.COMPLETED);
                savedRefund.setProcessedAt(LocalDateTime.now());
                refundRepository.save(savedRefund);

                // Update payment status
                if (amount.compareTo(payment.getAmount()) == 0) {
                    payment.setStatus(PaymentStatus.REFUNDED);
                } else {
                    payment.setStatus(PaymentStatus.PARTIAL_REFUNDED);
                }
                paymentRepository.save(payment);

                // Create transaction record
                PaymentTransaction transaction = new PaymentTransaction(
                        payment,
                        TransactionStatus.SUCCESS,
                        amount);
                transaction.setMessage("Refund processed successfully: " + reason);
                transactionRepository.save(transaction);

                // Create billing history record
                BillingHistory billingRecord = new BillingHistory(payment.getCustomer(),
                        amount, "PAYMENT_REFUNDED");
                billingRecord.setDescription("Payment refunded: " + payment.getReferenceNumber());
                billingRecord.setPayment(payment);
                billingHistoryRepository.save(billingRecord);

                return savedRefund;
            } else {
                savedRefund.setStatus(PaymentStatus.FAILED);
                return refundRepository.save(savedRefund);
            }
        } catch (Exception e) {
            savedRefund.setStatus(PaymentStatus.FAILED);
            refundRepository.save(savedRefund);
            throw new RuntimeException("Refund processing failed", e);
        }
    }

    @Override
    @Transactional
    public Payment cancelPayment(UUID id) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Payment not found"));

        if (payment.getStatus() != PaymentStatus.PENDING && payment.getStatus() != PaymentStatus.PROCESSING) {
            throw new IllegalArgumentException("Payment is not in a cancellable state");
        }

        // Update payment status
        payment.setStatus(PaymentStatus.CANCELLED);
        Payment updatedPayment = paymentRepository.save(payment);

        // Create transaction record
        PaymentTransaction transaction = new PaymentTransaction(
                updatedPayment,
                TransactionStatus.DECLINED,
                updatedPayment.getAmount());
        transaction.setMessage("Payment cancelled");
        transactionRepository.save(transaction);

        // Create billing history record
        BillingHistory billingRecord = new BillingHistory(updatedPayment.getCustomer(),
                updatedPayment.getAmount(), "PAYMENT_CANCELLED");
        billingRecord.setDescription("Payment cancelled: " + updatedPayment.getReferenceNumber());
        billingRecord.setPayment(updatedPayment);
        billingHistoryRepository.save(billingRecord);

        return updatedPayment;
    }

    @Override
    public List<Payment> searchPayments(String searchTerm) {
        // Placeholder - Would depend on additional repository methods
        return List.of();
    }

    @Override
    public Page<Payment> getPaymentsByCustomer(Account customer, Pageable pageable) {
        return paymentRepository.findByCustomer(customer, pageable);
    }
}
