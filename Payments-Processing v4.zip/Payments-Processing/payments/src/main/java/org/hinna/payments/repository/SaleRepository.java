package org.hinna.payments.repository;

import org.hinna.payments.model.Listing;
import org.hinna.payments.model.Sale;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Repository
public interface SaleRepository extends JpaRepository<Sale, UUID> {
    List<Sale> findByNameContaining(String name);
    List<Sale> findByIsActiveTrue();
    List<Sale> findByStartDateBeforeAndEndDateAfter(LocalDate now, LocalDate now2);
    List<Sale> findByApplicableListingsContaining(Listing listing);
    List<Sale> findByDiscountType(Sale.DiscountType discountType);
}
