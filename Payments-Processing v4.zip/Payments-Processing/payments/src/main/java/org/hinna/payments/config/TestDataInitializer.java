package org.hinna.payments.config;

import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.model.*;
import org.hinna.payments.model.enums.PaymentStatus;
import org.hinna.payments.model.enums.PaymentType;
import org.hinna.payments.repository.AccountRepository;
import org.hinna.payments.repository.PaymentMethodRepository;
import org.hinna.payments.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;

@Component
@Profile({"dev", "demo"})
@Slf4j
public class TestDataInitializer implements CommandLineRunner {

    private final PaymentRepository paymentRepository;
    private final AccountRepository accountRepository;
    private final PaymentMethodRepository paymentMethodRepository;

    @Autowired
    public TestDataInitializer(PaymentRepository paymentRepository,
                               AccountRepository accountRepository,
                               PaymentMethodRepository paymentMethodRepository) {
        this.paymentRepository = paymentRepository;
        this.accountRepository = accountRepository;
        this.paymentMethodRepository = paymentMethodRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        // Check if we already have data
        if (paymentRepository.count() > 0) {
            log.info("Database already contains data, skipping initialization");
            return;
        }

        // Create test account
        log.info("Initializing test data...");

        Account johnSmith = new Account("Jonathan", "Smith", "john@example.com");
        Account emmaSmith = new Account("Emma", "Smith", "email@example.com");
        Account kateSmith = new Account("Kate", "Smith", "kate@example.com");

        accountRepository.saveAll(Arrays.asList(johnSmith, emmaSmith, kateSmith));

        // Create payment methods
        PaymentMethod johnCC = new PaymentMethod(johnSmith, PaymentType.CREDIT_CARD);
        johnCC.setLastFourDigits("1234");

        PaymentMethod emmaCC = new PaymentMethod(emmaSmith, PaymentType.CREDIT_CARD);
        emmaCC.setLastFourDigits("1234");

        PaymentMethod kateCC = new PaymentMethod(kateSmith, PaymentType.CREDIT_CARD);
        kateCC.setLastFourDigits("1234");

        paymentMethodRepository.saveAll(Arrays.asList(johnCC, emmaCC, kateCC));

        // Create payments for different months
        // January
        createPayment(johnSmith, johnCC, "Music Lesson M60", new BigDecimal("10.00"),
                LocalDateTime.of(2024, 1, 24, 10, 0));
        createPayment(johnSmith, johnCC, "Music Lesson M60", new BigDecimal("10.00"),
                LocalDateTime.of(2024, 1, 26, 10, 0));
        createPayment(johnSmith, johnCC, "Music Lesson M60", new BigDecimal("10.00"),
                LocalDateTime.of(2024, 1, 28, 10, 0));

        // February
        createPayment(johnSmith, johnCC, "Music Lesson M60", new BigDecimal("10.00"),
                LocalDateTime.of(2024, 2, 24, 10, 0));
        createPayment(johnSmith, johnCC, "Music Lesson M60", new BigDecimal("10.00"),
                LocalDateTime.of(2024, 2, 26, 10, 0));
        createPayment(johnSmith, johnCC, "Music Lesson M60", new BigDecimal("10.00"),
                LocalDateTime.of(2024, 2, 28, 10, 0));

        // March
        createPayment(johnSmith, johnCC, "Music Lesson M60", new BigDecimal("10.00"),
                LocalDateTime.of(2024, 3, 24, 10, 0));
        createPayment(kateSmith, kateCC, "Music Lesson M61", new BigDecimal("10.00"),
                LocalDateTime.of(2024, 3, 24, 11, 0));
        createPayment(emmaSmith, emmaCC, "Music Lesson M62", new BigDecimal("10.00"),
                LocalDateTime.of(2024, 3, 24, 12, 0));

        log.info("Test data initialization completed");
    }

    private void createPayment(Account customer, PaymentMethod method, String description,
                               BigDecimal amount, LocalDateTime date) {
        Payment payment = new Payment(customer, amount, method);
        payment.setDescription(description);
        payment.setStatus(PaymentStatus.COMPLETED);
        payment.setCreatedAt(date);
        payment.setProcessedAt(date.plusMinutes(5));
        paymentRepository.save(payment);
    }
}
