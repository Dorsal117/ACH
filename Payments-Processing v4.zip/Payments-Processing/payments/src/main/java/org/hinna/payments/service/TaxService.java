package org.hinna.payments.service;

import org.hinna.payments.model.Tax;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;
import java.util.List;

public interface TaxService {

    /**
     * Creates a new tax rule with percentage validation.
     */
    Tax createTax(Tax tax);

    /**
     * Retrieve all applicable taxes for a location and date.
     */
    List<Tax> getApplicableTaxes(UUID locationId, LocalDate date);

     /**
     * Calculate total amount with applicable taxes, including compound tax logic.
     */
    BigDecimal applyTaxes(BigDecimal amount, UUID locationId, LocalDate date);
}
