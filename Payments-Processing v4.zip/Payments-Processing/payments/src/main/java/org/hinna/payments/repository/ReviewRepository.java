package org.hinna.payments.repository;

import org.hinna.payments.model.Account;
import org.hinna.payments.model.Listing;
import org.hinna.payments.model.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface ReviewRepository extends JpaRepository<Review, UUID> {
    List<Review> findByReviewer(Account reviewer);
    List<Review> findByListing(Listing listing);
    List<Review> findByRating(Integer rating);
    List<Review> findByListingOrderByRatingDesc(Listing listing);
    List<Review> findByListingAndRatingGreaterThanEqual(Listing listing, Integer rating);
}
