package org.hinna.payments.model.enums;

/**
 * Enum for different payroll trigger types
 */
public enum PayrollTriggerType {
    MANUAL,
    LESSON_CANCELLATION,
    SUBSTITUTE_PAYMENT,
    ADJUSTED_PAYMENT,
    SCHEDULED
}
