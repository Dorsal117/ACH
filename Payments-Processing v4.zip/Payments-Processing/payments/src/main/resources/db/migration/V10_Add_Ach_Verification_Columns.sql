ALTER TABLE payment_method
    ADD COLUMN bank_verification_status VARCHAR(32) NOT NULL DEFAULT 'UNVERIFIED',
    ADD COLUMN bank_verification_method VARCHAR(32),
    ADD COLUMN bank_last_four VARCHAR(50),
    ADD COLUMN bank_fingerprint VARCHAR(128),
    ADD COLUMN bank_mandate_reference VARCHAR(64),
    ADD COLUMN bank_mandate_url VARCHAR(255),
    ADD COLUMN bank_verified_at TIMESTAMP,
    ADD COLUMN bank_linked_at TIMESTAMP,
    ADD COLUMN ach_account_holder_name VARCHAR(255);