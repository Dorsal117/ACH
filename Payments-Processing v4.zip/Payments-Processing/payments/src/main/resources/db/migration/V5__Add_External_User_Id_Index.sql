-- Add index for faster lookups by external user ID
CREATE INDEX idx_account_external_user_id ON account(external_user_id);