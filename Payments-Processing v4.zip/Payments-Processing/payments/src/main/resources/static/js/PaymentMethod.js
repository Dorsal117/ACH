document.querySelector(".add-method").addEventListener("click", function (e) {
    e.preventDefault();
    document.getElementById("payment-method-modal").style.display = "block";
});

function closeModal() {
    document.getElementById("payment-method-modal").style.display = "none";
}

document.querySelectorAll(".method-option").forEach(button => {
    button.addEventListener("click", function () {
        const methodType = this.getAttribute("data-method");
        fetch('/api/payment-methods', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type: methodType })
        }).then(res => {
            if (res.ok) {
                alert(methodType + " added as preferred payment method.");
                closeModal();
            } else {
                alert("Error adding payment method.");
            }
        });
    });
});