document.addEventListener("DOMContentLoaded", () => {
    // Add Currency Form Logic
    const addBtn = document.getElementById("add-currency-btn");
    const form = document.getElementById("currency-form");
    const cancelBtn = document.getElementById("cancel-currency");
    const saveBtn = document.getElementById("save-currency");

    addBtn?.addEventListener("click", (e) => {
        e.preventDefault();
        form?.classList.remove("hidden");
    });

    cancelBtn?.addEventListener("click", () => {
        form?.classList.add("hidden");
    });

    saveBtn?.addEventListener("click", () => {
        const dropdown = document.getElementById("new-currency");
        const selectedOption = dropdown.options[dropdown.selectedIndex];

        if (!selectedOption || !selectedOption.value) {
            alert("Please select a currency.");
            return;
        }

        const currencyDropdown = document.getElementById("currency");
        const newOption = document.createElement("option");
        newOption.value = selectedOption.value;
        newOption.textContent = selectedOption.text;
        currencyDropdown.appendChild(newOption);

        alert(`Currency "${selectedOption.text}" added.`);
        form.classList.add("hidden");
    });

    // Add Tax Form Logic
    const addTaxBtn = document.getElementById("add-tax-btn");
    const taxForm = document.getElementById("tax-form");
    const taxList = document.getElementById("tax-list");

    const saveTaxBtn = document.getElementById("save-tax-btn");
    const cancelTaxBtn = document.getElementById("cancel-tax-btn");

    addTaxBtn?.addEventListener("click", (e) => {
        e.preventDefault();
        taxForm.classList.remove("hidden");
    });

    cancelTaxBtn?.addEventListener("click", () => {
        clearTaxForm();
        taxForm.classList.add("hidden");
    });

    saveTaxBtn?.addEventListener("click", () => {
        const nameInput = document.getElementById("tax-name-input");
        const valueInput = document.getElementById("tax-value-input");
        const locationSelect = document.getElementById("tax-location-input");

        const name = nameInput.value.trim();
        let value = valueInput.value.trim();
        const location = locationSelect.value.trim();

        if (!name || !value || !location) {
            alert("Please fill out all tax fields.");
            return;
        }

        // Strip percentage symbol if present
        if (value.endsWith('%')) {
            value = value.slice(0, -1).trim();
        }

        const numericValue = parseFloat(value);
        if (isNaN(numericValue) || numericValue < 0 || numericValue > 100) {
            alert("Tax value must be a number between 0 and 100.");
            return;
        }

        const formattedValue = `${numericValue}%`;

        const newRow = document.createElement("div");
        newRow.classList.add("tax-row");
        newRow.innerHTML = `
      <div class="tax-col">
        <label class="tax-label">Name</label>
        <input type="text" value="${name}" />
      </div>
      <div class="tax-col">
        <label class="tax-label">Value</label>
        <input type="text" value="${formattedValue}" />
      </div>
      <div class="tax-col">
        <label class="tax-label">Location</label>
        <select>
          <option selected>${location}</option>
        </select>
      </div>
    `;

        taxList.appendChild(newRow);
        clearTaxForm();
        taxForm.classList.add("hidden");
    });

    function clearTaxForm() {
        document.getElementById("tax-name-input").value = "";
        document.getElementById("tax-value-input").value = "";
        document.getElementById("tax-location-input").selectedIndex = 0;
    }
});
