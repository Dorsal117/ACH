document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("payment-form");

    if (form) {
        form.addEventListener("submit", function (event) {
            const clickedButton = document.activeElement;

            // Check if the clicked button is the back button
            if (clickedButton && clickedButton.classList.contains("back-btn")) {
                window.location.href = "/teacher-selection";
                return;
            }

            event.preventDefault(); // Stop normal form submission

            // Check validation only for the "Complete Purchase" button
            if (typeof window.isPaymentFormValid === "function" && window.isPaymentFormValid()) {
                window.location.href = "/payment/confirmation";
            }

            // If invalid, the error is already shown from inside isPaymentFormValid()
        });
    }
});
