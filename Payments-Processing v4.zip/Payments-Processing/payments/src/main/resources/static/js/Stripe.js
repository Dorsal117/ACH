const StripeCardState = {
    initPromise: null,
    stripe: null,
    elements: null,
    cardNumber: null,
    cardExpiry: null,
    cardCvc: null,
    clientSecret: null,
    listenersBound: false,
    bankTransfer: { clientSecret: null, initialized: false },
    activeMethod: 'card'
};

function togglePanel(selector, visible) {
    const panel = document.querySelector(selector);
    if (!panel) {
        return;
    }
    visible ? panel.removeAttribute('hidden') : panel.setAttribute('hidden', '');
}

function setActiveMethod(method) {
    StripeCardState.activeMethod = method;
    togglePanel('#card-payment-panel', method === 'card');
    togglePanel('#bank-transfer-panel', method === 'bank_transfer');

    if (method === 'bank_transfer' && !StripeCardState.bankTransfer.initialized) {
        prepareBankTransfer();
    }
}

function wirePaymentMethodSelection() {
    const options = document.querySelectorAll('.method-option');
    options.forEach(option => {
        option.addEventListener('click', () => {
            options.forEach(o => o.classList.remove('selected'));
            option.classList.add('selected');
            setActiveMethod(option.dataset.method === 'BANK_TRANSFER' ? 'bank_transfer' : 'card');
        });
    });
}

function resolvePublishableKey() {
    const body = document.body;
    if (!body) {
        return null;
    }
    const provided = (body.getAttribute('data-stripe-publishable-key') || '').trim();
    if (provided) {
        return provided;
    }
    const fallback = (body.getAttribute('data-default-stripe-key') || '').trim();
    return fallback || null;
}

async function getStripeInstance() {
    if (StripeCardState.initPromise) {
        await StripeCardState.initPromise;
        return StripeCardState.stripe;
    }
    StripeCardState.initPromise = (async () => {
        const key = resolvePublishableKey();
        if (!key) {
            console.error('Stripe publishable key missing.');
            return null;
        }
        StripeCardState.stripe = Stripe(key);
        StripeCardState.elements = StripeCardState.stripe.elements();
        window.__stripe = StripeCardState.stripe;
        return StripeCardState.stripe;
    })();
    await StripeCardState.initPromise;
    return StripeCardState.stripe;
}

function ensureCardElements() {
    if (!StripeCardState.elements) {
        return;
    }
    const style = {
        base: {
            fontSize: '14px',
            color: '#32325d',
            '::placeholder': { color: '#aab7c4' }
        }
    };
    if (!StripeCardState.cardNumber) {
        StripeCardState.cardNumber = StripeCardState.elements.create('cardNumber', { style });
    }
    if (!StripeCardState.cardExpiry) {
        StripeCardState.cardExpiry = StripeCardState.elements.create('cardExpiry', { style });
    }
    if (!StripeCardState.cardCvc) {
        StripeCardState.cardCvc = StripeCardState.elements.create('cardCvc', { style });
    }

    mountElementOnce('#card-number', StripeCardState.cardNumber);
    mountElementOnce('#exp-date', StripeCardState.cardExpiry);
    mountElementOnce('#cvv', StripeCardState.cardCvc);

    if (!StripeCardState.listenersBound) {
        bindCardListeners();
        StripeCardState.listenersBound = true;
    }
}

function mountElementOnce(selector, element) {
    const container = document.querySelector(selector);
    if (container && !container.querySelector('iframe')) {
        element.mount(selector);
    }
}

function bindCardListeners() {
    const formError = document.getElementById('form-error');
    const expError = document.getElementById('exp-error');

    const setFormError = (message) => {
        if (formError) {
            formError.textContent = message || '';
        }
    };
    const setExpError = (message) => {
        if (expError) {
            expError.textContent = message || '';
        }
    };

    if (StripeCardState.cardNumber) {
        StripeCardState.cardNumber.on('change', (event) => {
            setFormError(event.error ? event.error.message : '');
        });
    }
    if (StripeCardState.cardExpiry) {
        StripeCardState.cardExpiry.on('change', (event) => {
            setExpError(event.error ? event.error.message : '');
        });
    }
    if (StripeCardState.cardCvc) {
        StripeCardState.cardCvc.on('change', (event) => {
            setFormError(event.error ? event.error.message : '');
        });
    }
}

async function fetchTestIntent(paymentMethodType = 'card') {
    const response = await fetch('/api/test/stripe/intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            amount: 120.0,
            name: 'Test User',
            email: 'test@example.com',
            paymentMethodType
        })
    });
    // …existing error handling…
    const secret = await response.text();
    if (paymentMethodType === 'us_bank_account') {
        StripeCardState.bankTransfer.clientSecret = secret;
    } else {
        StripeCardState.clientSecret = secret;
    }
}

async function prepareBankTransfer() {
    const error = document.getElementById('ach-error');
    const status = document.getElementById('ach-status');
    if (error) error.textContent = '';
    if (status) status.textContent = '';

    await fetchTestIntent('us_bank_account');
    if (!StripeCardState.bankTransfer.clientSecret) {
        if (error) error.textContent = 'Unable to initialize bank transfer. Please try again.';
        return;
    }

    if (!StripeCardState.bankTransfer.initialized) {
        ['ach-account-holder-name', 'ach-account-holder-email'].forEach(id => {
            const field = document.getElementById(id);
            field && field.addEventListener('input', () => {
                if (error) error.textContent = '';
            });
        });
        StripeCardState.bankTransfer.initialized = true;
    }
}

async function handleBankTransferPurchase() {
    const stripe = StripeCardState.stripe;
    const clientSecret = StripeCardState.bankTransfer.clientSecret;
    const error = document.getElementById('ach-error');
    const status = document.getElementById('ach-status');

    if (error) error.textContent = '';
    if (status) status.textContent = '';

    if (!stripe || !clientSecret) {
        if (error) error.textContent = 'Bank transfer is not ready yet.';
        return;
    }

    const name = document.getElementById('ach-account-holder-name')?.value.trim();
    const email = document.getElementById('ach-account-holder-email')?.value.trim();
    const holderType = document.getElementById('ach-account-holder-type')?.value || 'individual';

    if (!name || !email) {
        if (error) error.textContent = 'Name and email are required for bank transfer.';
        return;
    }

    try {
        const { error: collectError } = await stripe.collectBankAccountForPayment(clientSecret, {
            payment_method_type: 'us_bank_account',
            payment_method_data: {
                billing_details: { name, email },
                us_bank_account: { account_holder_type: holderType }
            }
        });
        if (collectError) throw collectError;

        const result = await stripe.confirmUsBankAccountPayment(clientSecret);
        if (result.error) throw result.error;

        if (status) status.textContent = 'Bank details submitted. Payment will process once your bank confirms.';
    } catch (err) {
        if (error) error.textContent = err.message || 'Unable to complete bank transfer.';
    }
}


document.addEventListener('DOMContentLoaded', async () => {
    const stripe = await getStripeInstance();
    if (!stripe) {
        const formError = document.getElementById('form-error');
        if (formError) {
            formError.textContent = 'Stripe configuration is missing. Please contact support.';
        }
        return;
    }

    ensureCardElements();
    wirePaymentMethodSelection();
    setActiveMethod('card');
    await fetchTestIntent('card');

    const completeButton = document.getElementById('complete-btn');
    if (completeButton) {
        completeButton.addEventListener('click', async () => {
            if (StripeCardState.activeMethod === 'bank_transfer') {
                await handleBankTransferPurchase();
            } else {
                await handleCompletePurchase();
            }
        });
    }
});



document.addEventListener('DOMContentLoaded', async () => {
    const stripe = await getStripeInstance();
    if (!stripe) {
        const formError = document.getElementById('form-error');
        if (formError) {
            formError.textContent = 'Stripe configuration is missing. Please contact support.';
        }
        return;
    }

    ensureCardElements();
    wirePaymentMethodSelection();
    setActiveMethod('card');
    await fetchTestIntent('card');

    const completeButton = document.getElementById('complete-btn');
    if (completeButton) {
        completeButton.addEventListener('click', async () => {
            if (StripeCardState.activeMethod === 'bank_transfer') {
                await handleBankTransferPurchase();
            } else {
                await handleCompletePurchase();
            }
        });
    }
});

