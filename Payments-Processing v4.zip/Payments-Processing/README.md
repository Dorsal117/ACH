# HINNA Payments System Implementation

## Project Overview
This project implements a robust Payments System for the HINNA platform. The system handles transaction processing, invoice generation, and seamless integration with third-party payment processors.

## Key Features
- Complete payment processing workflow with Stripe integration
- Multi-payment method support with fallback capabilities
- User hierarchy management (SaaS -> Reseller -> Business -> Staff/Client)
- Customizable system settings for billing and usage parameters
- Transaction history and reporting capabilities
- Account credit management system

## Deployment Environment
### JDK Version
This project uses **JDK21.0.2 (Oracle OpenJDK)** as the Java development platform.

### Tech Stack
- **Backend:** Java with Spring Boot framework
- **Database Management:** PostgreSQL with Flyway for migrations
= **Message Broker:** RabbitMQ for asynchronous communication
- **CI/CD:** Jenkins pipeline
- **Frontend:** Thymeleaf templating engine with htmx
- **Hosting:** AWS Cloud

### Development Tools
- **GitHub** for version control
- **Jira** for agile project management
- **Slack** and **Microsoft Teams** for team communication
- **Zoom** for meetings
- **Figma** for UI/UX design
= **Miro** for collaborative planning

### Project Structure
The project follows a standard Spring Boot application structure with clear separation of concerns:
```
src/
├── main/
│   ├── java/org/hinna/payments/
│   │   ├── config/       # Configuration classes
│   │   ├── controller/   # REST API controllers
│   │   ├── dto/          # Data Transfer Objects
│   │   ├── exception/    # Custom exceptions
│   │   ├── model/        # Entity models
│   │   ├── repository/   # Database repositories
│   │   ├── service/      # Business logic services
│   │   └── util/         # Utility classes
│   └── resources/
│       ├── db/migration/ # Flyway migrations
│       ├── static/       # Static resources
│       └── templates/    # Thymeleaf templates
└── test/                 # Test classes
```

### Git Workflow
The project uses a Gitflow branching strategy:
- **main** - Production-ready code
- **develop** - Integration branch for development
- **feature/*** - Feature branches (naming: feature/JIRA-ID-description)
- **release/*** - Release preparation branches
- **hotfix/*** - Emergency fixes for production

All code changes require pull requests with at least one review before merging.
