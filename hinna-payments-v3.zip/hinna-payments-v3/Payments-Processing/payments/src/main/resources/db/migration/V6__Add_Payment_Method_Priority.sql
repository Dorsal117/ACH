-- Ensure payment method priority is properly constrained

-- Add a unique constraint to ensure each payment method for a user has a unique priority
-- This would need to be enforced at the application level or with triggers for more complex logic
ALTER TABLE payment_method
ADD CONSTRAINT unique_payment_method_priority_per_owner
UNIQUE (owner_id, priority);