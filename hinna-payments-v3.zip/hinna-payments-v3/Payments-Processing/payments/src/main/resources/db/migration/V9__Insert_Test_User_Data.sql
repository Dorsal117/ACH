-- Insert test locations first (no created_at/updated_at in Location entity)
INSERT INTO location (id, location_name, address, location_type)
VALUES
    ('55555555-5555-5555-5555-555555555555', 'Main Office', '123 Test Street, Test City', 'OFFICE'),
    ('66666666-6666-6666-6666-666666666666', 'Music Studio', '456 Music Ave, Test City', 'STUDIO')
ON CONFLICT (id) DO NOTHING;

-- Insert test SaaS account
INSERT INTO account (id, first_name, last_name, email, address, mobile_phone, created_at, updated_at, is_active, external_user_id)
VALUES (
    gen_random_uuid(),
    'Test',
    'SaaS Owner',
    'saas@test.com',
    '123 SaaS Street',
    '555-0001',
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP,
    true,
    12345
) ON CONFLICT (email) DO NOTHING;

-- Insert test Direct Customer (Business)
INSERT INTO account (id, first_name, last_name, email, address, mobile_phone, created_at, updated_at, is_active, external_user_id)
VALUES (
    '11111111-1111-1111-1111-111111111111',
    'Test',
    'Business Owner',
    'business@test.com',
    '123 Business Street',
    '555-0002',
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP,
    true,
    12346
) ON CONFLICT (email) DO NOTHING;

-- Insert into direct_customer table
INSERT INTO direct_customer (id, business_name, business_type, credit)
VALUES (
    '11111111-1111-1111-1111-111111111111',
    'Test Music Academy',
    'Education',
    1000.00
) ON CONFLICT (id) DO NOTHING;

-- Insert test Staff/Employees
INSERT INTO account (id, first_name, last_name, email, address, mobile_phone, created_at, updated_at, is_active, external_user_id)
VALUES
    ('22222222-2222-2222-2222-222222222222', 'John', 'Teacher', 'john.teacher@test.com', '123 Teacher Lane', '555-0101', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, true, 12347),
    ('33333333-3333-3333-3333-333333333333', 'Jane', 'Instructor', 'jane.instructor@test.com', '456 Music Ave', '555-0102', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, true, 12348),
    ('44444444-4444-4444-4444-444444444444', 'Bob', 'Piano Teacher', 'bob.piano@test.com', '789 Piano St', '555-0103', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, true, 12349)
ON CONFLICT (email) DO NOTHING;

-- Insert into staff table
INSERT INTO staff (id, position, department, is_admin, employer_id)
VALUES
    ('22222222-2222-2222-2222-222222222222', 'Piano Instructor', 'Music', false, '11111111-1111-1111-1111-111111111111'),
    ('33333333-3333-3333-3333-333333333333', 'Violin Instructor', 'Music', false, '11111111-1111-1111-1111-111111111111'),
    ('44444444-4444-4444-4444-444444444444', 'Voice Instructor', 'Music', true, '11111111-1111-1111-1111-111111111111')
ON CONFLICT (id) DO NOTHING;

-- Insert test payment methods
INSERT INTO payment_method (id, owner_id, type, last_four_digits, is_default, is_active)
VALUES (
    gen_random_uuid(),
    '11111111-1111-1111-1111-111111111111',
    'BANK_TRANSFER',
    '1234',
    true,
    true
) ON CONFLICT DO NOTHING;