-- First, create a temporary column with the new type
ALTER TABLE account ADD COLUMN dob_date DATE;

-- Drop the old column and rename the new one
ALTER TABLE account DROP COLUMN dob;
ALTER TABLE account RENAME COLUMN dob_date TO dob;