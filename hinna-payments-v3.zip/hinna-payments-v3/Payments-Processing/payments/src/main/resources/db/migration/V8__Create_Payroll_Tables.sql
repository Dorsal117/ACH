-- Create PayrollSchedule table
CREATE TABLE IF NOT EXISTS payroll_schedule (
    id UUID PRIMARY KEY,
    employee_id UUID NOT NULL,
    employer_id UUID NOT NULL,
    payment_method_id UUID,
    frequency VARCHAR(20) NOT NULL,
    day_of_month INTEGER,
    day_of_week VARCHAR(10),
    gross_amount DECIMAL(19, 4) NOT NULL,
    tax_rate DECIMAL(5, 2),
    deductions DECIMAL(19, 4),
    description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_ach_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    next_payment_date TIMESTAMP,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    CONSTRAINT fk_payroll_schedule_employee FOREIGN KEY (employee_id) REFERENCES staff(id),
    CONSTRAINT fk_payroll_schedule_employer FOREIGN KEY (employer_id) REFERENCES account(id),
    CONSTRAINT fk_payroll_schedule_payment_method FOREIGN KEY (payment_method_id) REFERENCES payment_method(id)
);

-- Create index for faster lookups
CREATE INDEX idx_payroll_schedule_employee ON payroll_schedule(employee_id);
CREATE INDEX idx_payroll_schedule_employer ON payroll_schedule(employer_id);
CREATE INDEX idx_payroll_schedule_next_payment ON payroll_schedule(next_payment_date);
CREATE INDEX idx_payroll_schedule_active ON payroll_schedule(is_active);

-- Create Payroll table
CREATE TABLE IF NOT EXISTS payroll (
    id UUID PRIMARY KEY,
    employee_id UUID NOT NULL,
    processing_account_id UUID NOT NULL,
    payment_method_id UUID,
    gross_amount DECIMAL(19, 4) NOT NULL,
    net_amount DECIMAL(19, 4) NOT NULL,
    tax_withheld DECIMAL(19, 4) NOT NULL DEFAULT 0,
    deductions DECIMAL(19, 4) NOT NULL DEFAULT 0,
    description TEXT,
    reference_number VARCHAR(100),
    pay_period_start TIMESTAMP,
    pay_period_end TIMESTAMP,
    scheduled_date TIMESTAMP,
    processed_date TIMESTAMP,
    status VARCHAR(20) NOT NULL,
    is_automatic BOOLEAN NOT NULL DEFAULT FALSE,
    is_ach_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    error_message TEXT,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    CONSTRAINT fk_payroll_employee FOREIGN KEY (employee_id) REFERENCES staff(id),
    CONSTRAINT fk_payroll_processing_account FOREIGN KEY (processing_account_id) REFERENCES account(id),
    CONSTRAINT fk_payroll_payment_method FOREIGN KEY (payment_method_id) REFERENCES payment_method(id)
);

-- Create index for faster lookups
CREATE INDEX idx_payroll_employee ON payroll(employee_id);
CREATE INDEX idx_payroll_processing_account ON payroll(processing_account_id);
CREATE INDEX idx_payroll_status ON payroll(status);
CREATE INDEX idx_payroll_scheduled_date ON payroll(scheduled_date);
CREATE INDEX idx_payroll_reference_number ON payroll(reference_number);