-- Create Account table (base class for user hierarchy)
CREATE TABLE account (
    id UUID PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    address VARCHAR(255),
    mobile_phone VARCHAR(20),
    home_phone VARCHAR(20),
    dob VARCHAR(20),
    gender VARCHAR(20),
    profile_picture_path VARCHAR(255),
    qr_code_path VARCHAR(255),
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    location_id UUID,
    external_user_id BIGINT -- Added for User Service integration
);

-- Create Location table
CREATE TABLE location (
    id UUID PRIMARY KEY,
    location_name VARCHAR(100) NOT NULL,
    address VARCHAR(255),
    owner_id UUID,
    location_type VARCHAR(50),
    CONSTRAINT fk_location_owner FOREIGN KEY (owner_id) REFERENCES account(id)
);

-- Add foreign key constraint to Account for location
ALTER TABLE account ADD CONSTRAINT fk_account_location FOREIGN KEY (location_id) REFERENCES location(id);

-- Create SaaS Account table
CREATE TABLE saas_account (
    id UUID PRIMARY KEY,
    company_name VARCHAR(100) NOT NULL,
    plan_type VARCHAR(50) NOT NULL,
    subscription_start TIMESTAMP,
    subscription_end TIMESTAMP,
    CONSTRAINT fk_saas_account FOREIGN KEY (id) REFERENCES account(id)
);

-- Create Reseller Account table
CREATE TABLE reseller_account (
    id UUID PRIMARY KEY,
    company_name VARCHAR(100) NOT NULL,
    reseller_code VARCHAR(50) NOT NULL UNIQUE,
    saas_account_id UUID,
    commission_rate DECIMAL(5,2) NOT NULL,
    CONSTRAINT fk_reseller_account FOREIGN KEY (id) REFERENCES account(id),
    CONSTRAINT fk_reseller_saas FOREIGN KEY (saas_account_id) REFERENCES saas_account(id)
);

-- Create Direct Customer table
CREATE TABLE direct_customer (
    id UUID PRIMARY KEY,
    business_name VARCHAR(100) NOT NULL,
    business_type VARCHAR(50),
    tax_id VARCHAR(50),
    family_id UUID,
    credit DECIMAL(19,4) DEFAULT 0,
    allow_bookings_family_df BOOLEAN DEFAULT FALSE,
    allow_payments_family_df BOOLEAN DEFAULT FALSE,
    allow_refunds_family_df BOOLEAN DEFAULT FALSE,
    allow_email_reports_df BOOLEAN DEFAULT FALSE,
    reseller_id UUID,
    CONSTRAINT fk_direct_customer FOREIGN KEY (id) REFERENCES account(id),
    CONSTRAINT fk_customer_reseller FOREIGN KEY (reseller_id) REFERENCES reseller_account(id)
);

-- Create Staff table
CREATE TABLE staff (
    id UUID PRIMARY KEY,
    position VARCHAR(100),
    department VARCHAR(100),
    biography TEXT,
    url_website VARCHAR(255),
    facebook VARCHAR(255),
    instagram VARCHAR(255),
    tiktok VARCHAR(255),
    is_admin BOOLEAN DEFAULT FALSE,
    employer_id UUID,
    staff_group_id UUID,
    CONSTRAINT fk_staff FOREIGN KEY (id) REFERENCES account(id),
    CONSTRAINT fk_staff_employer FOREIGN KEY (employer_id) REFERENCES direct_customer(id)
);

-- Create Permission table
CREATE TABLE permission (
    id UUID PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    resource_type VARCHAR(50),
    action VARCHAR(50),
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    created_by UUID
);

-- Create Staff Group table
CREATE TABLE staff_group (
    id UUID PRIMARY KEY,
    group_name VARCHAR(100) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    admin_id UUID
);

-- Create Staff Group Permission junction table
CREATE TABLE staff_group_permission (
    staff_group_id UUID NOT NULL,
    permission_id UUID NOT NULL,
    PRIMARY KEY (staff_group_id, permission_id),
    CONSTRAINT fk_staff_group_permission_group FOREIGN KEY (staff_group_id) REFERENCES staff_group(id),
    CONSTRAINT fk_staff_group_permission_perm FOREIGN KEY (permission_id) REFERENCES permission(id)
);

-- Create Admin Group table
CREATE TABLE admin_group (
    id UUID PRIMARY KEY,
    group_name VARCHAR(100) NOT NULL,
    base_permissions TEXT,
    types VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE
);

-- Create Admin Group Permission junction table
CREATE TABLE admin_group_permission (
    admin_group_id UUID NOT NULL,
    permission_id UUID NOT NULL,
    PRIMARY KEY (admin_group_id, permission_id),
    CONSTRAINT fk_admin_group_permission_group FOREIGN KEY (admin_group_id) REFERENCES admin_group(id),
    CONSTRAINT fk_admin_group_permission_perm FOREIGN KEY (permission_id) REFERENCES permission(id)
);

-- Create Database Table table (for admin access control)
CREATE TABLE database_table (
    id UUID PRIMARY KEY,
    table_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    schema_name VARCHAR(50)
);

-- Create Admin table
CREATE TABLE admin (
    id UUID PRIMARY KEY,
    account_id UUID UNIQUE,
    admin_type VARCHAR(50),
    roles_overview TEXT,
    tables_accessible TEXT,
    tables_created TEXT,
    base_permissions TEXT,
    admin_group_id UUID,
    CONSTRAINT fk_admin_account FOREIGN KEY (account_id) REFERENCES account(id),
    CONSTRAINT fk_admin_group FOREIGN KEY (admin_group_id) REFERENCES admin_group(id)
);

-- Create Admin Accessible Table junction table
CREATE TABLE admin_accessible_table (
    admin_id UUID NOT NULL,
    table_id UUID NOT NULL,
    PRIMARY KEY (admin_id, table_id),
    CONSTRAINT fk_admin_accessible_admin FOREIGN KEY (admin_id) REFERENCES admin(id),
    CONSTRAINT fk_admin_accessible_table FOREIGN KEY (table_id) REFERENCES database_table(id)
);

-- Create Admin Created Table junction table
CREATE TABLE admin_created_table (
    admin_id UUID NOT NULL,
    table_id UUID NOT NULL,
    PRIMARY KEY (admin_id, table_id),
    CONSTRAINT fk_admin_created_admin FOREIGN KEY (admin_id) REFERENCES admin(id),
    CONSTRAINT fk_admin_created_table FOREIGN KEY (table_id) REFERENCES database_table(id)
);

-- Create Admin Table Access table
CREATE TABLE admin_table_access (
    id UUID PRIMARY KEY,
    admin_id UUID NOT NULL,
    table_id UUID NOT NULL,
    access_level VARCHAR(20) NOT NULL,
    is_creator BOOLEAN DEFAULT FALSE,
    CONSTRAINT fk_admin_table_access_admin FOREIGN KEY (admin_id) REFERENCES admin(id),
    CONSTRAINT fk_admin_table_access_table FOREIGN KEY (table_id) REFERENCES database_table(id)
);

-- Create Payment Method table
CREATE TABLE payment_method (
    id UUID PRIMARY KEY,
    owner_id UUID NOT NULL,
    type VARCHAR(20) NOT NULL,
    provider_token VARCHAR(255),
    last_four_digits VARCHAR(4),
    expiry_date TIMESTAMP,
    is_default BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    priority INTEGER, -- Added for payment method prioritization
    CONSTRAINT fk_payment_method_owner FOREIGN KEY (owner_id) REFERENCES account(id)
);

-- Create Payment table
CREATE TABLE payment (
    id UUID PRIMARY KEY,
    amount DECIMAL(19,4) NOT NULL,
    status VARCHAR(20) NOT NULL,
    customer_id UUID,
    method_id UUID,
    created_at TIMESTAMP NOT NULL,
    processed_at TIMESTAMP,
    reference_number VARCHAR(100),
    description TEXT,
    CONSTRAINT fk_payment_customer FOREIGN KEY (customer_id) REFERENCES account(id),
    CONSTRAINT fk_payment_method FOREIGN KEY (method_id) REFERENCES payment_method(id)
);

-- Create Payment Transaction table
CREATE TABLE payment_transaction (
    id UUID PRIMARY KEY,
    payment_id UUID NOT NULL,
    status VARCHAR(20) NOT NULL,
    provider_reference VARCHAR(100),
    timestamp TIMESTAMP NOT NULL,
    message TEXT,
    amount DECIMAL(19,4) NOT NULL,
    CONSTRAINT fk_payment_transaction_payment FOREIGN KEY (payment_id) REFERENCES payment(id)
);

-- Create Billing History table
CREATE TABLE billing_history (
    id UUID PRIMARY KEY,
    account_id UUID NOT NULL,
    transaction_date TIMESTAMP NOT NULL,
    amount DECIMAL(19,4) NOT NULL,
    description TEXT,
    transaction_type VARCHAR(50) NOT NULL,
    created_at TIMESTAMP NOT NULL,
    payment_id UUID,
    CONSTRAINT fk_billing_history_account FOREIGN KEY (account_id) REFERENCES account(id),
    CONSTRAINT fk_billing_history_payment FOREIGN KEY (payment_id) REFERENCES payment(id)
);

-- Create Invoice table
CREATE TABLE invoice (
    id UUID PRIMARY KEY,
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id UUID NOT NULL,
    status VARCHAR(20) NOT NULL,
    subtotal DECIMAL(19,4) NOT NULL,
    tax_amount DECIMAL(19,4) NOT NULL,
    total_amount DECIMAL(19,4) NOT NULL,
    issue_date TIMESTAMP NOT NULL,
    due_date TIMESTAMP NOT NULL,
    notes TEXT,
    payment_id UUID,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP,
    paid_at TIMESTAMP,
    CONSTRAINT fk_invoice_customer FOREIGN KEY (customer_id) REFERENCES account(id),
    CONSTRAINT fk_invoice_payment FOREIGN KEY (payment_id) REFERENCES payment(id)
);

-- Create Invoice Item table
CREATE TABLE invoice_item (
    id UUID PRIMARY KEY,
    invoice_id UUID NOT NULL,
    description TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    price DECIMAL(19,4) NOT NULL,
    tax_rate DECIMAL(5,2) NOT NULL,
    item_type VARCHAR(20),
    item_id UUID,
    service_id UUID,
    CONSTRAINT fk_invoice_item_invoice FOREIGN KEY (invoice_id) REFERENCES invoice(id)
);

-- Create Refund table
CREATE TABLE refund (
    id UUID PRIMARY KEY,
    payment_id UUID NOT NULL,
    amount DECIMAL(19,4) NOT NULL,
    status VARCHAR(20) NOT NULL,
    reason_code VARCHAR(50),
    description TEXT,
    refund_reference VARCHAR(100),
    created_at TIMESTAMP NOT NULL,
    processed_at TIMESTAMP,
    CONSTRAINT fk_refund_payment FOREIGN KEY (payment_id) REFERENCES payment(id)
);

-- Create Listing table (base class for items and services)
CREATE TABLE listing (
    id UUID PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(19,4) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL
);

-- Create Item table
CREATE TABLE item (
    id UUID PRIMARY KEY,
    sku VARCHAR(50),
    stock_quantity INTEGER,
    manufacturer VARCHAR(100),
    CONSTRAINT fk_item_listing FOREIGN KEY (id) REFERENCES listing(id)
);

-- Create Service table
CREATE TABLE service (
    id UUID PRIMARY KEY,
    duration_minutes INTEGER,
    is_recurring BOOLEAN DEFAULT FALSE,
    frequency VARCHAR(50),
    CONSTRAINT fk_service_listing FOREIGN KEY (id) REFERENCES listing(id)
);

-- Create Sale table
CREATE TABLE sale (
    id UUID PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    start_date DATE,
    end_date DATE,
    discount_type VARCHAR(20) NOT NULL,
    discounted_value DECIMAL(19,4) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE
);

-- Create Listing Sale junction table
CREATE TABLE listing_sale (
    listing_id UUID NOT NULL,
    sale_id UUID NOT NULL,
    PRIMARY KEY (listing_id, sale_id),
    CONSTRAINT fk_listing_sale_listing FOREIGN KEY (listing_id) REFERENCES listing(id),
    CONSTRAINT fk_listing_sale_sale FOREIGN KEY (sale_id) REFERENCES sale(id)
);

-- Create Coupon table
CREATE TABLE coupon (
    id UUID PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    discount_type VARCHAR(20) NOT NULL,
    discount_value DECIMAL(19,4) NOT NULL,
    usage_limit INTEGER,
    usage_count INTEGER DEFAULT 0,
    expiry_date DATE,
    is_active BOOLEAN DEFAULT TRUE
);

-- Create Listing Coupon junction table
CREATE TABLE listing_coupon (
    listing_id UUID NOT NULL,
    coupon_id UUID NOT NULL,
    PRIMARY KEY (listing_id, coupon_id),
    CONSTRAINT fk_listing_coupon_listing FOREIGN KEY (listing_id) REFERENCES listing(id),
    CONSTRAINT fk_listing_coupon_coupon FOREIGN KEY (coupon_id) REFERENCES coupon(id)
);

-- Create Review table
CREATE TABLE review (
    id UUID PRIMARY KEY,
    reviewer_id UUID NOT NULL,
    listing_id UUID NOT NULL,
    title VARCHAR(100) NOT NULL,
    rating INTEGER,
    created_at TIMESTAMP NOT NULL,
    CONSTRAINT fk_review_reviewer FOREIGN KEY (reviewer_id) REFERENCES account(id),
    CONSTRAINT fk_review_listing FOREIGN KEY (listing_id) REFERENCES listing(id)
);

-- Create Payment Settings table
CREATE TABLE payment_settings (
    id UUID PRIMARY KEY,
    account_id UUID UNIQUE,
    retry_attempts INTEGER DEFAULT 3,
    retry_interval_minutes INTEGER DEFAULT 60,
    auto_invoice BOOLEAN DEFAULT FALSE,
    allowed_payment_types VARCHAR(255) DEFAULT 'CREDIT_CARD,BANK_TRANSFER',
    minimum_payment_amount DECIMAL(19,4) DEFAULT 5.00,
    CONSTRAINT fk_payment_settings_account FOREIGN KEY (account_id) REFERENCES account(id)
);

-- Create Stripe Customer table
CREATE TABLE stripe_customer (
    id UUID PRIMARY KEY,
    account_id UUID NOT NULL UNIQUE,
    stripe_customer_id VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    CONSTRAINT fk_stripe_customer_account FOREIGN KEY (account_id) REFERENCES account(id)
);

-- Create Stripe Webhook Event table
CREATE TABLE stripe_webhook_event (
    id UUID PRIMARY KEY,
    stripe_event_id VARCHAR(100) NOT NULL UNIQUE,
    event_type VARCHAR(100),
    payload TEXT NOT NULL,
    processed BOOLEAN NOT NULL DEFAULT FALSE,
    received_at TIMESTAMP NOT NULL,
    processed_at TIMESTAMP
);