function selectTeacher(el) {
    document.querySelectorAll('.teacher-card').forEach(c => c.classList.remove('selected'));
    el.classList.add('selected');
    document.getElementById('selectedTeacherId').value = el.dataset.id;

    // Reset previous time slot
    document.getElementById('selectedTime').value = '';
    document.querySelectorAll('.time-slot').forEach(ts => {
        ts.classList.remove('selected');
        ts.classList.add('disabled');
    });

    // Enable selected teacher’s slots
    const id = el.dataset.id;
    document.querySelectorAll(`.time-slots[data-teacher-id='${id}'] .time-slot`)
        .forEach(slot => slot.classList.remove('disabled'));
}

function selectTime(event, el) {
    event.stopPropagation();
    if (el.classList.contains('disabled')) return;
    document.querySelectorAll('.time-slot').forEach(t => t.classList.remove('selected'));
    el.classList.add('selected');
    document.getElementById('selectedTime').value = el.dataset.time;
}

function validateNext(event) {
    const clickedButton = document.activeElement;

    if (clickedButton.name === "action" && clickedButton.value === "next") {
        return validateTeacherSelection();
    }

    // Allow form submit for Back button
    return true;
}

function validateTeacherSelection() {
    const teacherId = document.getElementById('selectedTeacherId').value;
    const time = document.getElementById('selectedTime').value;
    const errorBox = document.getElementById('teacher-form-error');

    let errors = [];

    if (!teacherId) {
        errors.push("• Please select a teacher.");
    }

    if (!time) {
        errors.push("• Please select a time slot.");
    }

    if (errors.length > 0) {
        errorBox.innerHTML = errors.map(e => `<div>${e}</div>`).join('');
        return false;
    }

    errorBox.innerHTML = '';
    return true;
}


