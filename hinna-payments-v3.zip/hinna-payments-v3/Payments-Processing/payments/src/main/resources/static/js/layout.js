let sidebarOpen = false;

document.addEventListener("DOMContentLoaded", function () {
    const sidebarBlack = document.getElementById("sidebar-black");
    const sidebarButtons = document.querySelectorAll(".sidebar-btn");

    // Sidebar button click handler
    sidebarButtons.forEach(button => {
        button.addEventListener("click", function (e) {
            if (e.target.tagName === 'INPUT' || e.target.closest('.credit-card-toggles')) {
                return;
            }

            const isSettings = this.id === "settings-toggle-btn";

            if (isSettings) {
                e.preventDefault();

                if (!sidebarOpen) {
                    htmx.ajax('GET', '/partials/sidebar-settings.html', {
                        target: '#sidebar-black',
                        swap: 'innerHTML'
                    });
                    sidebarBlack.classList.remove('hidden');
                    sidebarOpen = true;
                } else {
                    sidebarBlack.classList.add('hidden');
                    sidebarOpen = false;
                }
            } else {
                // Hide black sidebar if any other sidebar button is clicked
                sidebarBlack.classList.add('hidden');
                sidebarOpen = false;
            }

            // Activate clicked button only
            sidebarButtons.forEach(btn => btn.classList.remove("active"));
            this.classList.add("active");
        });
    });

    // Run when HTMX loads settings sidebar content
    document.body.addEventListener('htmx:afterSwap', function (evt) {
        if (evt.detail.target.id === "sidebar-black") {
            setupDropdowns();
        }
    });

    function setupDropdowns() {
        const toggles = document.querySelectorAll('.dropdown-toggle');
        toggles.forEach(toggle => {
            toggle.addEventListener('click', function () {
                const menu = this.nextElementSibling;
                if (menu && menu.classList.contains('dropdown-menu')) {
                    menu.classList.toggle('hidden');
                    const arrow = this.querySelector('.arrow');
                    if (arrow) {
                        arrow.textContent = menu.classList.contains('hidden') ? '▸' : '▾';
                    }
                }
            });
        });
    }
});