/**
 * Client-side functionality for the transaction page
 */
const maxYear = new Date().getFullYear();

document.addEventListener('DOMContentLoaded', function () {
    // Get current values from the page
    const yearLabel = document.querySelector('.year-label');
    let currentYear = parseInt(yearLabel.textContent);

    const searchInput = document.getElementById('transaction-search');
    const searchBtn = document.getElementById('search-btn');
    const prevYearBtn = document.getElementById('prev-year');
    const nextYearBtn = document.getElementById('next-year');
    const maxYear = new Date().getFullYear();

    // Handle search button click
    searchBtn.addEventListener('click', function () {
        searchTransactions();
    })

    // Handle enter key in search input
    searchInput.addEventListener('keyup', function (event) {
        if (event.key === 'Enter') {
            searchTransactions();
        }
    })

    // Handle previous year button click
    prevYearBtn.addEventListener('click', function () {
        if (currentYear > 2000) {
            currentYear--;
            updateYearDisplay();
            loadTransactionsForYear(currentYear);
        }
    });

    // Handle next year button click
    nextYearBtn.addEventListener('click', function () {
        if (currentYear < maxYear) {
            currentYear++;
            updateYearDisplay();
            loadTransactionsForYear(currentYear);
        }
    });

    // Initialize dropdown menus for the three-dot actions
    initializeDropdowns();

    /**
     * Search transactions based on the search input
     */
    function searchTransactions() {
        const searchTerm = searchInput.value.trim();
        loadTransactionsForYear(currentYear, searchTerm);
    }

    /**
     * Disable user to go beyond current year
     */
    function updateYearDisplay() {
        yearLabel.textContent = currentYear;

        // Disable or enable the next button
        nextYearBtn.disabled = currentYear >= maxYear;

        // (Optional) prevent going before 2000 or any min year
        prevYearBtn.disabled = currentYear <= 2000;
    }

    /**
     * Load transactions for a specific year and optional search term
     */
    function loadTransactionsForYear(year, searchTerm = '') {
        // Show loading indicator
        const container = document.getElementById('transactions-container');
        container.innerHTML = '<div class="loading">Loading transactions...</div>';

        // Build query string
        let url =  `/payments/transactions/api?year=${year}`;
        if (searchTerm) {
            url += `&searchTerm=${encodeURIComponent(searchTerm)}`;
        }

        // Fetch transactions from the server
        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                renderTransactions(data);
            })
            .catch(error => {
                console.error('Error fetching transactions:', error);
                container.innerHTML = `<div class="error">Error loading transactions: ${error.message}</div>`
            })
    }

    /**
     * Render transactions in the UI
     */
    function renderTransactions(groups) {
        const container = document.getElementById('transactions-container');

        // Clear container
        container.innerHTML = '';

        // Show messages if no transactions
        if (!groups || groups.length === 0) {
            container.innerHTML = '<div class="no-transactions"><p>No transactions found for the selected criteria.</p></div>'
            return;
        }

        // Render EACH month group
        groups.forEach(group => {
            const monthGroup = document.createElement('div');
            monthGroup.className = 'transaction-month-group';

            let html = `
                <table class="transaction-table">
                    <tr class="month-header">
                        <td colspan="6">
                            <span class="month-title">${group.monthName} ${group.year}</span>
                            ${group.currentMonth ? '<span class="month-indicator">This Month</span>' : ''}
                        </td>
                    </tr>
                    <tbody>
            `;

            // Render each transaction in this month
            group.transactions.forEach(transaction => {
                const date = new Date(transaction.date);
                const formattedDate = date.toISOString().split('T')[0]; // YYYY-MM-DD

                html += `
                    <tr>
                        <td>${formattedDate}</td>
                        <td>${transaction.service}</td>
                        <td>
                            <img src="/images/Visa.png" class="visa-img"  alt=""/> 
                            •••• •••• •••• ${transaction.lastFourDigits}
                        </td>
                        <td>${transaction.clientName}</td>
                        <td>$${Number(transaction.amount).toFixed(2)}</td>
                        <td>
                            <div class="dropdown">
                                <span class="dots">⋯</span>
                                <div class="dropdown-content">
                                    <a href="/payments/transactions/${transaction.id}">View Details</a>
                                    ${transaction.status === 'COMPLETED' ? '<a href="#">Download Receipt</a>' : ''}
                                </div>
                            </div>
                        </td>
                    </tr>
                `;
            });

            html += `
                    </tbody>
                    <tfoot>
                        <tr class="month-container">
                            <td colspan="4" class="monthly-label">Monthly Total:</td>
                            <td class="monthly-total">$${Number(group.total).toFixed(2)}</td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            `;

            monthGroup.innerHTML = html;
            container.appendChild(monthGroup);
        });

        // Reinitialize dropdowns after rendering
        initializeDropdowns();
    }

    /**
     * Initialize dropdown menus for transaction actions
     */
    function initializeDropdowns() {
        const dots = document.querySelectorAll('.dots');

        dots.forEach(dot => {
            dot.addEventListener('click', function(e) {
                e.stopPropagation();

                // Close all dropdowns
                document.querySelectorAll('.dropdown-content').forEach(dropdown => {
                    if (dropdown !== this.nextElementSibling) {
                        dropdown.classList.remove('show');
                    }
                });

                // Toggle this dropdown
                const dropdown = this.nextElementSibling;
                dropdown.classList.toggle('show');
            })
        })

        // Close dropdowns when clicking outside
        document.addEventListener('click', function() {
            document.querySelectorAll('.dropdown-content').forEach(dropdown => {
                dropdown.classList.remove('show');
            })
        })
    }

    /**
     * Format currency as USD
     */
    function formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 2
        }).format(amount);
    }

    /**
     * Format date in YYYY-MM-DD format
     */
    function formatDate(dateString) {
        const date = new Date(dateString);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    /**
     * Get payment method icon based on type
     */
    function getPaymentMethodIcon(type) {
        switch (type) {
            case 'CREDIT_CARD':
                return '/images/Visa.png';
            case 'PAYPAL':
                return '/images/paypal.png';
            case 'BANK_TRANSFER':
                return '/images/bank.png';
            default:
                return '/images/Visa.png';
        }
    }

    updateYearDisplay();
})