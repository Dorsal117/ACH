(function () {
    const METHOD_CARD = 'card';
    const METHOD_ACH = 'ach';
    const methodMap = {
        [METHOD_CARD]: 'STRIPE',
        [METHOD_ACH]: 'BANK_TRANSFER'
    };

    function qs(selector) {
        return document.querySelector(selector);
    }

    function qsa(selector) {
        return Array.from(document.querySelectorAll(selector));
    }

    function setAchError(message) {
        const node = qs('#ach-error');
        if (node) {
            node.textContent = message || '';
        }
    }

    function setAchMessage(message) {
        const node = qs('#ach-message');
        if (node) {
            node.textContent = message || '';
        }
    }

    function setActiveMethod(method) {
        const body = document.body;
        if (body) {
            body.dataset.checkoutMethod = method;
        }

        const cardPane = qs('#card-pane');
        const achPane = qs('#ach-pane');

        if (cardPane) {
            const isCard = method === METHOD_CARD;
            cardPane.hidden = !isCard;
            cardPane.classList.toggle('active', isCard);
        }

        if (achPane) {
            const isAch = method === METHOD_ACH;
            achPane.hidden = !isAch;
            achPane.classList.toggle('active', isAch);
            if (isAch && typeof window.AchPayment?.refresh === 'function') {
                window.AchPayment.refresh();
            }
        }

        const options = qsa('#payment-methods-list .method-option');
        options.forEach((option) => {
            const target = option.dataset.method;
            const shouldSelect = target === methodMap[method];
            option.classList.toggle('selected', shouldSelect);
        });

        if (method === METHOD_ACH) {
            setAchError('');
            setAchMessage('Select a verified bank account and click Complete Purchase to start the ACH payment.');
        } else {
            setAchMessage('');
        }
    }

    function getActiveMethod() {
        const body = document.body;
        return body?.dataset.checkoutMethod || METHOD_CARD;
    }

    function toggleButtonLoading(button, isLoading, label) {
        if (!button) {
            return;
        }
        if (isLoading) {
            if (!button.dataset.originalText) {
                button.dataset.originalText = button.textContent;
            }
            button.disabled = true;
            if (label) {
                button.textContent = label;
            }
        } else {
            button.disabled = false;
            if (button.dataset.originalText) {
                button.textContent = button.dataset.originalText;
                delete button.dataset.originalText;
            }
        }
    }

    async function processAchPayment(button) {
        const form = qs('#payment-form');
        const accountId = form?.dataset.accountId;
        if (!accountId) {
            setAchError('Sign in to continue with ACH payments.');
            return;
        }

        const paymentState = window.AchPayment || {};
        const methodId = typeof paymentState.getSelectedMethodId === 'function'
            ? paymentState.getSelectedMethodId()
            : null;

        if (!methodId) {
            setAchError('Select a verified bank account before continuing.');
            return;
        }

        const method = typeof paymentState.getMethodById === 'function'
            ? paymentState.getMethodById(methodId)
            : null;

        const isVerified = method && (method.bankAccountVerified === true ||
            (method.bankVerificationStatus && method.bankVerificationStatus.toUpperCase() === 'VERIFIED'));

        if (!isVerified) {
            setAchError('Selected bank account must be verified before it can be used.');
            return;
        }

        const amountRaw = form?.dataset.grandTotal || '0';
        const parsedAmount = Number.parseFloat(amountRaw);
        if (!Number.isFinite(parsedAmount) || parsedAmount <= 0) {
            setAchError('Unable to determine payment amount.');
            return;
        }

        const currency = (form?.dataset.achCurrency || 'usd').toUpperCase();
        const payload = {
            customerId: accountId,
            paymentMethodId: methodId,
            amount: Number(parsedAmount.toFixed(2)),
            description: 'ACH checkout payment',
            currency
        };

        toggleButtonLoading(button, true, 'Processing...');
        setAchError('');
        setAchMessage('Submitting ACH payment...');

        try {
            const response = await fetch('/api/payments', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                const errorBody = await response.text();
                throw new Error(errorBody || 'ACH payment could not be created.');
            }

            const result = await response.json();
            setAchMessage('ACH payment submitted. We will update the status once the bank confirms the debit.');

            if (method?.achAccountHolderName) {
                sessionStorage.setItem('cardName', method.achAccountHolderName);
            }
            sessionStorage.setItem('lastPaymentMethod', 'ach');

            setTimeout(() => {
                window.location.href = '/payment/confirmation';
            }, 1500);
        } catch (err) {
            setAchError(err.message || 'Unexpected error while creating ACH payment.');
            throw err;
        } finally {
            toggleButtonLoading(button, false);
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        setActiveMethod(METHOD_CARD);

        const options = qsa('#payment-methods-list .method-option');
        options.forEach((option) => {
            option.addEventListener('click', () => {
                const method = option.dataset.method;
                if (method === methodMap[METHOD_CARD]) {
                    setActiveMethod(METHOD_CARD);
                } else if (method === methodMap[METHOD_ACH]) {
                    setActiveMethod(METHOD_ACH);
                }
            });
        });

        const completeButton = qs('#complete-btn');
        if (completeButton) {
            completeButton.addEventListener('click', async (event) => {
                if (getActiveMethod() !== METHOD_ACH) {
                    return;
                }
                event.preventDefault();
                try {
                    await processAchPayment(completeButton);
                } catch (err) {
                    // Errors already routed to UI via setAchError
                }
            });
        }
    });
})();
