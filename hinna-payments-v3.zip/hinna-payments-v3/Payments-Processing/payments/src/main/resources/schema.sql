CREATE TABLE transactions (
                              id UUID PRIMARY KEY,
                              date VARCHAR(255),
                              service VARCHAR(255),
                              payment_method VARCHAR(255),
                              client VARCHAR(255),
                              total DOUBLE
);

CREATE TABLE payroll (
                         id VARCHAR(255) PRIMARY KEY,
                         staff_name VARCHAR(255),
                         role VARCHAR(255),
                         payment_method VARCHAR(255),
                         payment_date DATE,
                         salary DOUBLE
);

