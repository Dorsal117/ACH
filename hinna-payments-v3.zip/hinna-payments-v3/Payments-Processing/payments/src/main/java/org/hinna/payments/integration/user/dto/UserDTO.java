package org.hinna.payments.integration.user.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hinna.payments.model.Account;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Data Transfer Object for user information from the User Service/
 * Represents the structure of user data as it comes from the User Service API and is used for
 * integration between classes
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserDTO {

    // Core user identifiers
    private Long userId;
    private String email;

    // Basic information
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private LocalDate birthday;
    private String profilePicturePath;

    // Address information
    private String address;
    private String city;
    private String province;
    private String postalCode;
    private String country;

    // Role and account info
    private String role;  // CLIENT, STAFF, BUSINESS, RESELLER, SAAS, ADMIN
    private LocalDate dateEnrolled;

    // Business-specific fields
    private String businessName;
    private String businessType;
    private String taxId;

    // Reseller/SaaS-specific fields
    private String companyName;

    // Account status
    private boolean active;
    private LocalDateTime lastLogin;

    // Helper methods
    /**
     * Helper method to check if this user represents a business
     */
    public boolean isBusiness() {
        return "BUSINESS".equals(role);
    }

    /**
     * Helper method to check if this user represents a reseller
     */
    public boolean isReseller() {
        return "RESELLER".equals(role);
    }

    /**
     * Helper method to check if this user represents a SaaS account
     */
    public boolean isSaas() {
        return "SAAS".equals(role);
    }

    /**
     * Helper method to check if this user represents a client
     */
    public boolean isClient() {
        return "CLIENT".equals(role);
    }

    /**
     * Helper method to check if this user represents a staff member
     */
    public boolean isStaff() {
        return "STAFF".equals(role);
    }

    /**
     * Helper method to check if this user is an admin
     */
    public boolean isAdmin() {
        return "ADMIN".equals(role);
    }

    /**
     * Helper method to get full name
     */
    public String getFullName() {
        return firstName + " " + lastName;
    }

    /**
     * Helper method to get full address
     */
    public String getFullAddress() {
        StringBuilder sb = new StringBuilder();
        if (address != null && !address.isBlank()) {
            sb.append(address);
        }
        if (city != null && !city.isBlank()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(city);
        }
        if (province != null && !province.isBlank()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(province);
        }
        if (postalCode != null && !postalCode.isBlank()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(postalCode);
        }
        if (country != null && !country.isBlank()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(country);
        }
        return sb.toString();
    }

}
