package org.hinna.payments.integration.user.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Response DTO for payment history endpoint.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Response containing user payment history")
public class PaymentHistoryResponse {

    @Schema(description = "Whether the request was successful", example = "true")
    private boolean success;

    @Schema(description = "Message describing the result", example = "Payment history retrieved successfully")
    private String message;

    @Schema(description = "List of payment summaries")
    private List<PaymentSummaryDTO> payments;

    @Schema(description = "Current page number (zero-based)", example = "0")
    private int page;

    @Schema(description = "Size of each page", example = "20")
    private int pageSize;

    @Schema(description = "Total number of payments", example = "42")
    private long totalElements;
}
