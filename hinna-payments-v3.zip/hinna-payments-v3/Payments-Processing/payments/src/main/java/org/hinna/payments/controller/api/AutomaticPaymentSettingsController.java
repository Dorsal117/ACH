package org.hinna.payments.controller.api;

import org.hinna.payments.integration.user.dto.AutomaticPaymentSettingsDTO;
import org.hinna.payments.service.PaymentSettingsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/payment-settings/automatic")
public class AutomaticPaymentSettingsController {

    private final PaymentSettingsService paymentSettingsService;

    @Autowired
    public AutomaticPaymentSettingsController(PaymentSettingsService paymentSettingsService) {
        this.paymentSettingsService = paymentSettingsService;
    }

    @GetMapping("/{accountId}")
    public ResponseEntity<AutomaticPaymentSettingsDTO> getAutomaticPaymentSettings(@PathVariable UUID accountId) {
        try {
            AutomaticPaymentSettingsDTO settings = paymentSettingsService.getAutomaticPaymentSettings(accountId);
            return ResponseEntity.ok(settings);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    public ResponseEntity<AutomaticPaymentSettingsDTO> updateAutomaticPaymentSettings(
            @PathVariable UUID accountId,
            @RequestBody AutomaticPaymentSettingsDTO settings) {
        try {
            AutomaticPaymentSettingsDTO updatedSettings = paymentSettingsService
                    .updateAutomaticPaymentSettings(accountId, settings);
            return ResponseEntity.ok(updatedSettings);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}
