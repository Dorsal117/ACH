package org.hinna.payments.integration.booking.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.sql.Date;
import java.util.List;
import java.util.UUID;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Data
public class CreateServiceRequest extends BaseEntity implements IBaseRequest {
    private UUID businessId;
    private Integer attendees;
    private Boolean onlineClass;
    private String location;
    private List<PriceRequest> prices;
    private String service_type;
    private String creator;
    private String category;
    private String description;
    private String instructions;
    private Integer registrationFee;
    private Date registrationStartDate;
    private Date registrationEndDate;
    private Date withdrawWindowStartDate;
    private Date withdrawWindowEndDate;
    private boolean withdrawPeriodRefund;
    private String waitListType;
}
