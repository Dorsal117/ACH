package org.hinna.payments.dto;

import lombok.Data;

import java.util.UUID;

@Data
public class PasswordRequestDTO {
    private UUID accountId; // For identifying the user (if needed)
    private String currentPassword; // For validation when changing password
    private String newPassword; // For change/reset
    private String resetToken; // For password reset via token
}
