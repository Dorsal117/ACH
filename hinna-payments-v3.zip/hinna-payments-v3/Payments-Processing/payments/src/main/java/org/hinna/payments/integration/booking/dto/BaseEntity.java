package org.hinna.payments.integration.booking.dto;

import org.springframework.util.ObjectUtils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * Base entity class to match the booking service's BaseEntity
 */
public abstract class BaseEntity {
    public List<String> checkForNullFields() {
        List<String> nullFields = new ArrayList<>();
        for (Field field : this.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            try {
                Object value = field.get(this);
                if (ObjectUtils.isEmpty(value)) {
                    nullFields.add(field.getName());
                }
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }
        return nullFields;
    }
}
