package org.hinna.payments.controller.api;

import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.dto.TransactionDTO;
import org.hinna.payments.dto.TransactionGroupDTO;
import org.hinna.payments.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.Year;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("/settings/transactions")
@Slf4j
public class TransactionController {

    private final TransactionService transactionService;

    @Autowired
    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    /**
     * Display the transactions page with grouped transactions by month
     */
    @GetMapping
    public String getTransactionPage(
            @RequestParam(required = false) Integer year,
            @RequestParam(required = false) String searchTerm,
            Model model
    ) {
        try {
            // Use current year if not provided
            if (year == null) {
                year = Year.now().getValue();
            }

            // Get transactions grouped by month
            log.info("Fetching transactions for year: {} ", year);
            List<TransactionGroupDTO> transactionGroups = transactionService.getTransactionsGroupedByMonth(year, searchTerm);
            if (transactionGroups == null) {
                transactionGroups = List.of();
            }
            log.info("Retrieved {} transaction groups", transactionGroups.size());

            model.addAttribute("transactionGroups", transactionGroups);
            model.addAttribute("selectedYear", year);
            model.addAttribute("currentYear", Year.now().getValue());
            model.addAttribute("searchTerm", searchTerm != null ? searchTerm : "");
            model.addAttribute("content", "payment-transactions");
            return "layout";
        } catch (Exception e) {
            log.error("Error loading transaction page", e);
            model.addAttribute("errorMessage", "Error processing transactions: " + e.getMessage());
            model.addAttribute("content", "error");
            return "layout";
        }

    }

    /**
     * REST endpoint to get transaction data for AJAX calls
     */
    @GetMapping("/api")
    @ResponseBody
    public List<TransactionGroupDTO> getTransactions(
            @RequestParam(required = false) Integer year,
            @RequestParam(required = false) String searchTerm
    ) {
        // Use current year if not provided

        if (year == null) {
            year = Year.now().getValue();
        }

        return transactionService.getTransactionsGroupedByMonth(year, searchTerm);
    }

    /**
     * Get transaction details for a specific transaction
     */
    @GetMapping("/{id}")
    public String getTransactionDetails(@PathVariable UUID id, Model model) {
        TransactionDTO transaction = transactionService.getTransactionById(id);
        model.addAttribute("transaction", transaction);
        return "transaction-details";
    }
}
