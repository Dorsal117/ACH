package org.hinna.payments.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hinna.payments.model.enums.PayrollStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PayrollResponseDTO {
    private UUID id;
    private UUID employeeId;
    private String employeeName;
    private String position;
    private UUID processingAccountId;
    private String processingAccountName;
    private UUID paymentMethodId;
    private String paymentMethodName;
    private BigDecimal grossAmount;
    private BigDecimal netAmount;
    private BigDecimal taxWithheld;
    private BigDecimal deductions;
    private String description;
    private String referenceNumber;
    private LocalDateTime payPeriodStart;
    private LocalDateTime payPeriodEnd;
    private LocalDateTime scheduledDate;
    private LocalDateTime processedDate;
    private PayrollStatus status;
    private boolean isAutomatic;
    private boolean isAchEnabled;
    private String errorMessage;
}
