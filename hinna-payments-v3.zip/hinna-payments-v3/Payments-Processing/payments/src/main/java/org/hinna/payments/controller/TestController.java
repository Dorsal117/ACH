package org.hinna.payments.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

    @GetMapping("/")
    public String root() {
        return "Welcome to the HINNA Payment Service!";
    }

    @GetMapping("/api/public/hello")
    public String publicHello() {
        return "Hello! This is a public endpoint.";
    }

    @GetMapping("/api/protected/hello")
    public String protectedHello() {
        return "Hello! This is a protected endpoint that should only be accessible when authenticated.";
    }
}