package org.hinna.payments.integration.booking.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Event sent when a service is booked
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BookingCreatedEvent {
    private UUID bookingId;
    private UUID businessId;
    private Integer attendees;
    private Boolean onlineClass;
    private String location;
    private String serviceType;
    private String category;
    private String description;
    private List<PriceDto> prices;
    private LocalDateTime bookingTime;
    private Date registrationStartDate;
    private Date registrationEndDate;
    private Date withdrawWindowStartDate;
    private Date withdrawWindowEndDate;
    private boolean withdrawPeriodRefund;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PriceDto {
        private Double amount;
        private Integer classDuration;
        private String billingFrequency;
    }
}
