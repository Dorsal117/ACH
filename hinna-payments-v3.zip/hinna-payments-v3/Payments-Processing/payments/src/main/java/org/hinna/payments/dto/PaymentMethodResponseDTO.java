package org.hinna.payments.dto;

import lombok.Data;
import org.hinna.payments.model.enums.PaymentType;

import java.util.UUID;

import org.hinna.payments.model.enums.BankAccountVerificationMethod;
import org.hinna.payments.model.enums.BankAccountVerificationStatus;

/**
 * Data Transfer Object for payment method response
 */
@Data
public class PaymentMethodResponseDTO {
    private UUID id;
    private UUID ownerId;
    private String ownerName;
    private PaymentType type;
    private String lastFourDigits;
    private String expiryDate; // MM/YY
    private Boolean isDefault;
    private Boolean isActive;
    private Boolean expired;
    private String displayName;
    private String brand;
    private String walletType;
    private BankAccountVerificationStatus bankVerificationStatus;
    private BankAccountVerificationMethod bankVerificationMethod;
    private Boolean bankAccountVerified;
    private String bankMandateReference;
    private String bankMandateUrl;
}
