package org.hinna.payments.client;

import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.exception.AuthenticationException;
import org.hinna.payments.exception.ServiceUnavailableException;
import org.hinna.payments.integration.user.dto.UserDTO;
import org.hinna.payments.model.requests.LoginRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Client for communicating with the User Service API.
 */
@Slf4j
@Service
public class UserServiceClient {
    private final RestTemplate restTemplate;
    private final String userServiceBaseUrl;

    @Autowired
    public UserServiceClient(RestTemplate restTemplate,
                             @Value("${hinna.user-service.url}") String userServiceBaseUrl) {
        this.restTemplate = restTemplate;
        this.userServiceBaseUrl = userServiceBaseUrl;
    }

    /**
     * Authenticate user and get JWT token
     * @param email user email
     * @param password user password
     * @return JWT token
     */
    public String authenticate(String email, String password) {
        try {
            String url = userServiceBaseUrl + "/api/auth/token";
            LoginRequest loginRequest = new LoginRequest(email, password);

            ResponseEntity<String> response = restTemplate.postForEntity(
                    url, loginRequest, String.class
            );

            if (response.getStatusCode().is2xxSuccessful()) {
                return response.getBody();
            } else {
                throw new AuthenticationException("Failed to authenticate with user service");
            }
        } catch (HttpClientErrorException.Unauthorized e) {
            throw new AuthenticationException("Invalid credentials", e);
        } catch (RestClientException e) {
            log.error("Authentication failed", e);
            throw new AuthenticationException("Authentication failed: " + e.getMessage());
        }
    }

    /**
     * Validate a JWT token with the user service
     * @param token JWT token
     * @return true if token is valid
     */
    public boolean validateToken(String token) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(token);
            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<Void> response = restTemplate.exchange(
                    userServiceBaseUrl + "/api/auth/validate-token",
                    HttpMethod.GET,
                    entity,
                    Void.class);

            return response.getStatusCode().is2xxSuccessful();
        } catch (HttpClientErrorException.Unauthorized e) {
            return false;
        } catch (Exception e) {
            log.error("Token validation failed", e);
            return false;
        }
    }

    /**
     * Get user details by ID
     * @param userId user ID
     * @return UserDTO or null if not found
     * @throws ServiceUnavailableException if the User Service is unavailable
     */
    public UserDTO getUserById(Long userId) throws ServiceUnavailableException {
        try {
            String url = userServiceBaseUrl + "/api/user/" + userId;

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<UserDTO> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    entity,
                    UserDTO.class
            );

            return response.getBody();
        } catch (HttpClientErrorException.NotFound e) {
            return null;
        } catch (ResourceAccessException e) {
            log.error("Failed to connect to User Service", e);
            throw new ServiceUnavailableException("User Service is currently unavailable");
        } catch (Exception e) {
            log.error("Failed to get user by ID: {}", userId, e);
            return null;
        }
    }

    /**
     * Get user details by email
     * @param email user email
     * @return UserDTO or null if not found
     * @throws ServiceUnavailableException if the User Service is unavailable
     */
    public UserDTO getUserByEmail(String email) throws ServiceUnavailableException {
        try {
            String url = userServiceBaseUrl + "/api/user/email/" + email;

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<UserDTO> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    entity,
                    UserDTO.class);

            return response.getBody();
        } catch (HttpClientErrorException.NotFound e) {
            return null;
        } catch (ResourceAccessException e) {
            log.error("Failed to connect to User Service", e);
            throw new ServiceUnavailableException("User Service is currently unavailable");
        } catch (Exception e) {
            log.error("Failed to get user by email: {}", email, e);
            return null;
        }
    }

    /**
     * Get users by role
     * @param role Role to search for
     * @return List of users or empty list if none found
     * @throws ServiceUnavailableException if the User Service is unavailable
     */
    public List<UserDTO> getUsersByRole(String role) throws ServiceUnavailableException {
        try {
            String url = userServiceBaseUrl + "/api/user/role/" + role;

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<List<UserDTO>> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    entity,
                    new ParameterizedTypeReference<List<UserDTO>>() {});

            return response.getBody();
        } catch (ResourceAccessException e) {
            log.error("Failed to connect to User Service", e);
            throw new ServiceUnavailableException("User Service is currently unavailable");
        } catch (Exception e) {
            log.error("Failed to get users by role: {}", role, e);
            return Collections.emptyList();
        }
    }

    /**
     * Check service health
     * @return true if service is healthy
     */
    public boolean isHealthy() {
        try {
            String url = userServiceBaseUrl + "/api/health";

            ResponseEntity<Map<String, String>> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<Map<String, String>>() {});

            if (!response.getStatusCode().is2xxSuccessful()) return false;
            response.getBody();
            return "UP".equals(response.getBody().get("status"));
        } catch (Exception e) {
            log.error("Health check failed", e);
            return false;
        }
    }
}
