package org.hinna.payments.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * DTO for payment gateway settings responses
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentGatewaySettingsResponseDTO {

    private boolean connected;

    private boolean apiKeyConfigured;

    private boolean webhookSecretConfigured;

    private String provider;

    private boolean testMode;

    private String currency;

    private LocalDateTime lastConfiguredAt;

    // The status of the payment gateway
    private String status;

    // The account type
    private String accountType;

    // The webhook URL that should be used in the Stripe dashboard
    private String webhookUrl;
}
