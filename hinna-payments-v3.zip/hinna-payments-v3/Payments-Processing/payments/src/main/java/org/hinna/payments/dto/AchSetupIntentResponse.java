package org.hinna.payments.dto;

import lombok.Data;

@Data
public class AchSetupIntentResponse {
    private String clientSecret;
}
