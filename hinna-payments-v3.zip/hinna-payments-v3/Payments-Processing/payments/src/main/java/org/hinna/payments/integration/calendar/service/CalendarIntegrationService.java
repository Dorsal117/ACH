package org.hinna.payments.integration.calendar.service;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.integration.calendar.config.CalendarRabbitConfig;
import org.hinna.payments.integration.calendar.dto.CalendarEvent;
import org.hinna.payments.integration.calendar.dto.PaymentStatusUpdate;
import org.hinna.payments.model.Account;
import org.hinna.payments.model.Invoice;
import org.hinna.payments.model.InvoiceItem;
import org.hinna.payments.model.Payment;
import org.hinna.payments.service.AccountService;
import org.hinna.payments.service.InvoiceService;
import org.hinna.payments.service.PaymentService;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

@Service
@Slf4j
public class CalendarIntegrationService {
    private final RabbitTemplate rabbitTemplate;
    private final AccountService accountService;
    private final InvoiceService invoiceService;
    private final PaymentService paymentService;

    // In-memory storage for scheduled payments (would be in database in production)
    private final Map<String, Date> scheduledPayments = new HashMap<>();
    private final Map<String, String> eventPaymentMap = new HashMap<>();

    @Autowired
    public CalendarIntegrationService(RabbitTemplate rabbitTemplate,
                                      AccountService accountService,
                                      InvoiceService invoiceService,
                                      PaymentService paymentService) {
        this.rabbitTemplate = rabbitTemplate;
        this.accountService = accountService;
        this.invoiceService = invoiceService;
        this.paymentService = paymentService;
    }

    /**
     * Listens for calendar event and schedules payments if needed
     * @param event CalendarEvent
     */
    @RabbitListener(queues = CalendarRabbitConfig.CALENDAR_EVENT_QUEUE)
    @Transactional
    public void handleCalendarEvent(CalendarEvent event) {
        log.info("Received calendar event: {}", event);

        try {
            // Check if payment is required (can use tags or other logic
            boolean requiresPayment = this.isPaymentRequired(event);

            if (requiresPayment) {
                // Schedule payment for this event
                this.schedulePaymentForEvent(event);
            }
        } catch (Exception e) {
            log.error("Error processing calendar event", e);
        }

    }

    /**
     * Determine if an event requires payment
     * @param event CalendarEvent
     * @return true if a payment is required, false otherwise
     */
    private boolean isPaymentRequired(CalendarEvent event) {
        // Logic to determine if payment is required
        // Could be based on tags, event type, ...

        // For now, assume that events with tags containing "paid" require payment
        if (event.getTags() != null) {
            return event.getTags().stream()
                    .anyMatch(tag -> tag.toLowerCase().contains("paid"));
        }

        // Or could use a property directly if added to the model
        return event.getPaymentRequired() != null && event.getPaymentRequired();
    }

    /**
     * Schedule a payment for a calendar event
     * @param event CalendarEvent
     */
    private void schedulePaymentForEvent(CalendarEvent event) {
        log.info("Scheduling payment for event: {}", event.getEvent_id());

        // Find the account (assuming company_id maps to an account)
        String accountId = event.getCompany_id();
        if (accountId == null) {
            log.warn("No company_id provided for event: {}", event.getEvent_id());
            return;
        }

        Optional<Account> accountOpt = accountService.getAccountById(UUID.fromString(accountId));
        if (accountOpt.isEmpty()) {
            log.error("Cannot find account for company: {}", accountId);
            return;
        }

        Account account = accountOpt.get();

        // Create or get invoice
        Invoice invoice = this.createInvoiceForEvent(event, account);

        // Schedule payment for 24 hours before event
        Date eventTime = event.getStart_time();
        Calendar cal = Calendar.getInstance();
        cal.setTime(eventTime);
        cal.add(Calendar.HOUR, -24); // 24 hour before
        Date scheduledTime = cal.getTime();

        // Store scheduled payment (in-memory for now, would be in DB in prod)
        scheduledPayments.put(event.getEvent_id(), scheduledTime);

        // Update calendar with payment status "SCHEDULED"
        this.updateCalendarPaymentStatus(event.getEvent_id(), null, "SCHEDULED", null);

        log.info("Payment scheduled for event {} at {}", event.getEvent_id(), scheduledTime);
    }

    /**
     * Create an invoice for a calendar event
     * @param event CalendarEvent
     * @param account Account
     */
    private Invoice createInvoiceForEvent(CalendarEvent event, Account account) {
        log.info("Create invoice for event: {}", event.getEvent_id());

        // Create invoice
        LocalDateTime dueDate = event.getStart_time().toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime();

        Invoice invoice = new Invoice(account, LocalDateTime.now(), dueDate);

        // Create a line item for the event
        InvoiceItem item = new InvoiceItem(
                event.getTitle(), // Use event title as item description
                1,
                BigDecimal.valueOf(100.00), // Sample price, would be determined by business logic
                BigDecimal.valueOf(13.00) // Default tax rate
        );

        // Add metadata to link back to calendar event
        item.setItemType("CALENDAR_EVENT");

        // Add item to invoice
        invoice.addItem(item);

        // Save invoice
        return invoiceService.createInvoice(invoice);
    }

    /**
     * Send payment status update to calendar service
     * @param eventId Event's ID
     * @param paymentId Payment's ID
     * @param status Payment status
     * @param amount Payment amount
     */
    public void updateCalendarPaymentStatus(String eventId, String paymentId, String status, Double amount) {
        log.info("Updating calendar payment status for event: {}", eventId);

        PaymentStatusUpdate update = PaymentStatusUpdate.builder()
                .event_id(eventId)
                .paymentId(paymentId)
                .paymentStatus(status)
                .updateTime(new Date())
                .amount(amount)
                .build();

        rabbitTemplate.convertAndSend(
                CalendarRabbitConfig.CALENDAR_EXCHANGE,
                CalendarRabbitConfig.PAYMENT_STATUS_KEY,
                update
        );

        // If we have a paymentId, store the mapping
        if (paymentId != null) {
            eventPaymentMap.put(eventId, paymentId);
        }
    }

    /**
     * Update calendar when a payment's status changes
     * @param eventId Event's ID
     * @param payment Payment
     */
    public void notifyCalendarOfPaymentUpdate(String eventId, Payment payment) {
        log.info("Notifying calendar of payment update for event: {}", eventId);

        this.updateCalendarPaymentStatus(
                eventId,
                payment.getId().toString(),
                payment.getStatus().name(),
                payment.getAmount().doubleValue()
        );
    }

    @Scheduled(fixedRate = 3600000) // 1 hour
    public void processScheduledPayments() {
        log.info("Processing scheduled payments");

        Date now = new Date();

        // Find due scheduled payments
        for (Map.Entry<String, Date> entry : scheduledPayments.entrySet()) {
            String eventId = entry.getKey();
            Date scheduledTime = entry.getValue();

            if (scheduledTime.before(now)) {
                this.processPaymentForEvent(eventId);
            }
        }
    }

    /**
     * Process payment for event
     * @param eventId Event's ID
     */
    private void processPaymentForEvent(String eventId) {
        log.info("Process payment for event: {}", eventId);

        // In a real implementation, I believe:
        // 1. Find the customer's default payment method
        // 2. Process payment through Stripe
        // 3. Update calendar with payment status

        // For now, simulate successful payment
        this.updateCalendarPaymentStatus(eventId, UUID.randomUUID().toString(), "PAID", 100.00);

        // Remove from scheduled payments
        scheduledPayments.remove(eventId);
    }

    /**
     * Get the payment ID for an event
     * @param eventId Event's ID
     * @return Optional String
     */
    public Optional<String> getPaymentIdForEvent(String eventId) {
        return Optional.ofNullable(eventPaymentMap.get(eventId));
    }

    /**
     * Manual method to trigger payment processing for testing
     * @param eventId Event's ID
     */
    public void triggerPaymentForEvent(String eventId) {
        this.processPaymentForEvent(eventId);
    }
}
