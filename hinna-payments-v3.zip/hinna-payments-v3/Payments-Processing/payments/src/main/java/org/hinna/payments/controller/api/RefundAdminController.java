package org.hinna.payments.controller.api;

import org.hinna.payments.model.Refund;
import org.hinna.payments.service.RefundService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.UUID;

@RestController
@RequestMapping("/api/refunds")
public class RefundAdminController {

    private static final Logger logger = LoggerFactory.getLogger(RefundAdminController.class);

    private final RefundService refundService;

    @Autowired
    public RefundAdminController(RefundService refundService) {
        this.refundService = refundService;
    }

    /**
     * Request a new refund for a specific payment.
     *
     * @param paymentId ID of the payment to refund
     * @param amount Amount to refund
     * @param reason Reason for refund
     * @return Refund entity details
     */
    @PostMapping("/request")
    public ResponseEntity<Refund> requestRefund(
            @RequestParam UUID paymentId,
            @RequestParam BigDecimal amount,
            @RequestParam String reason
    ) {
        logger.info("Requesting refund for paymentId={}, amount={}, reason={}", paymentId, amount, reason);

        Refund refund = refundService.requestRefund(paymentId, amount, reason);

        logger.info("Refund requested successfully: {}", refund.getId());

        return ResponseEntity.ok(refund);
    }

    /**
     * Approve a pending refund.
     *
     * @param refundId ID of the refund to approve
     * @return Updated Refund entity
     */
    @PostMapping("/{refundId}/approve")
    public ResponseEntity<Refund> approveRefund(@PathVariable UUID refundId) {
        logger.info("Approving refund with id={}", refundId);

        Refund refund = refundService.approveRefund(refundId);

        logger.info("Refund approved successfully: {}", refund.getId());

        return ResponseEntity.ok(refund);
    }

    /**
     * Reject a pending refund with a reason.
     *
     * @param refundId ID of the refund to reject
     * @param rejectionReason Reason for rejecting the refund
     * @return Updated Refund entity
     */
    @PostMapping("/{refundId}/reject")
    public ResponseEntity<Refund> rejectRefund(
            @PathVariable UUID refundId,
            @RequestParam String rejectionReason
    ) {
        logger.info("Rejecting refund with id={} for reason={}", refundId, rejectionReason);

        Refund refund = refundService.rejectRefund(refundId, rejectionReason);

        logger.info("Refund rejected successfully: {}", refund.getId());

        return ResponseEntity.ok(refund);
    }
}
