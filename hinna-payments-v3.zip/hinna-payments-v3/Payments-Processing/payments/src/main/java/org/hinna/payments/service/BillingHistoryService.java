package org.hinna.payments.service;

import org.hinna.payments.model.Account;
import org.hinna.payments.model.BillingHistory;
import org.hinna.payments.model.Payment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface BillingHistoryService {
    BillingHistory createBillingRecord(BillingHistory billingHistory);
    Optional<BillingHistory> getBillingRecordById(UUID id);
    Page<BillingHistory> getAllBillingRecords(Pageable pageable);
    List<BillingHistory> getBillingRecordsByAccount(Account account);
    List<BillingHistory> getBillingRecordsByPayment(Payment payment);
    List<BillingHistory> getBillingRecordsByDateRange(LocalDateTime start, LocalDateTime end);
    List<BillingHistory> getBillingRecordsByType(String transactionType);
    List<BillingHistory> getRecentBillingRecords(Account account, int limit);
}
