package org.hinna.payments.service;

import org.hinna.payments.model.Permission;
import org.hinna.payments.model.StaffGroup;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public interface StaffGroupService {
    StaffGroup createStaffGroup(StaffGroup staffGroup);
    Optional<StaffGroup> getStaffGroupById(UUID id);
    Optional<StaffGroup> getStaffGroupByName(String name);
    Page<StaffGroup> getAllStaffGroups(Pageable pageable);
    List<StaffGroup> getActiveStaffGroups();
    StaffGroup updateStaffGroup(UUID groupId, StaffGroup staffGroupDetails);
    void deleteStaffGroup(UUID groupId);
    StaffGroup addPermission(UUID groupId, UUID permissionId);
    StaffGroup removePermission(UUID groupId, UUID permissionId);
    Set<Permission> getPermissionsByGroupId(UUID groupId);
    boolean hasPermission(UUID groupId, String permissionName);
}
