package org.hinna.payments.integration.pat;

import org.hinna.payments.integration.config.RabbitMQConfig;
import org.hinna.payments.model.Payment;
import org.hinna.payments.model.PaymentSettings;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class PATIntegrationService {

    private final RabbitTemplate rabbitTemplate;

    @Autowired
    public PATIntegrationService(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    /**
     * Creates a workflow in PAT for payment retry handling
     * @param accountId Account to create workflow for
     * @param settings Payment settings to use for configuration
     * @return UUID of the created workflow
     */
    public UUID createPaymentRetryWorkflow(UUID accountId, PaymentSettings settings) {
        // Create a workflow with scheduled trigger for payment retry
        Map<String, Object> workflowData = new HashMap<>();
        workflowData.put("workflow_name", "Payment Retry Workflow");
        workflowData.put("account_id", accountId.toString());
        workflowData.put("isEnabled", true);
        workflowData.put("steps", this.createPaymentRetrySteps(settings));

        // Send workflow creation request
        return (UUID) rabbitTemplate.convertSendAndReceive(
                RabbitMQConfig.PAT_EXCHANGE,
                "workflow.create",
                workflowData,
                message -> {
                    // Set message properties if needed
                    return message;
                }
        );
    }

    /**
     * Triggers a payment retry workflow for a failed payment
     * @param paymentId The payment ID to retry
     */
    public void triggerPaymentRetryWorkflow(UUID paymentId, Payment payment) {
        Map<String, Object> message = new HashMap<>();
        message.put("trigger_type", "PAYMENT_RETRY");
        message.put("payment_id", paymentId.toString());
        message.put("customer_id", payment.getCustomer().getId().toString());
        message.put("amount", payment.getAmount());
        message.put("payment_method_id", payment.getMethod().getId().toString());
        message.put("description", "Automatic payment retry for failed payment");

        rabbitTemplate.convertAndSend(
                RabbitMQConfig.PAT_EXCHANGE,
                RabbitMQConfig.PAT_WORKFLOW_EXECUTE_KEY,
                message
        );
    }

    /**
     * Trigger a negative balance charge workflow in PAT
     * @param accountId The account ID to charge
     * @param amount The amount to charge
     */
    public void triggerNegativeBalanceChargeWorkflow(UUID accountId, BigDecimal amount) {
        Map<String, Object> message = new HashMap<>();
        message.put("trigger_type", "NEGATIVE_BALANCE_CHARGE");
        message.put("account_id", accountId.toString());
        message.put("amount", amount);
        message.put("description", "Automatic charge for negative balance account");

        rabbitTemplate.convertAndSend(
                RabbitMQConfig.PAT_EXCHANGE,
                RabbitMQConfig.PAT_WORKFLOW_EXECUTE_KEY,
                message
        );
    }

    /**
     * Create payment notification step
     * @param payment The payment to notify about
     */
    public void createPaymentNotificationStep(Payment payment) {
        Map<String, Object> stepData = new HashMap<>();
        stepData.put("step_type", "EMAIL");
        stepData.put("recipient_id", payment.getCustomer().getId().toString());
        stepData.put("email", payment.getCustomer().getEmail());
        stepData.put("body", createPaymentEmailBody(payment));
        stepData.put("subject", "Payment Notification: " + payment.getReferenceNumber());

        rabbitTemplate.convertAndSend(
                RabbitMQConfig.PAT_EXCHANGE,
                RabbitMQConfig.PAT_STEP_EXECUTE_KEY,
                stepData
        );
    }
    
    // Helper methods to create workflow components
    private Map<String, Object> createPaymentRetrySteps(PaymentSettings settings) {
        // Create a map of steps based on settings
        Map<String, Object> steps = new HashMap<>();

        // Payment processing step
        Map<String, Object> processStep = new HashMap<>();
        processStep.put("step_type", "PAYMENT_PROCESS");
        processStep.put("charge_amount", settings.isChargeForRetry() ? settings.getRetryChargeAmount() : BigDecimal.ZERO);

        // Notification step
        Map<String, Object> notifyStep = new HashMap<>();
        notifyStep.put("step_type", "EMAIL");
        notifyStep.put("subject", "Payment Retry Notification");
        notifyStep.put("body", "Your payment has been retried and was successful.");

        // Conditional for success/failure
        Map<String, Object> conditional = new HashMap<>();
        conditional.put("expression", "payment.status == 'COMPLETED'");

        // Add steps to workflow
        steps.put("process", processStep);
        steps.put("notify", notifyStep);
        steps.put("check_result", conditional);

        return steps;
    }

    private String createPaymentEmailBody(Payment payment) {
        return "Dear Customer,\n\n" +
                "This is a notification about payment " + payment.getReferenceNumber() + ".\n" +
                "Amount: " + payment.getAmount() + "\n" +
                "Status: " + payment.getStatus() + "\n\n" +
                "Thank you for using our services.";
    }
}
