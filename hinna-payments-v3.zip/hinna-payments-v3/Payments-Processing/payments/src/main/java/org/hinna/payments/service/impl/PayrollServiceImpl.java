package org.hinna.payments.service.impl;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.dto.EmployeePayrollDTO;
import org.hinna.payments.dto.PayrollRequestDTO;
import org.hinna.payments.dto.PayrollScheduleRequestDTO;
import org.hinna.payments.integration.pat.PayrollPATIntegrationService;
import org.hinna.payments.model.*;
import org.hinna.payments.model.enums.PayrollFrequency;
import org.hinna.payments.model.enums.PayrollStatus;
import org.hinna.payments.repository.*;
import org.hinna.payments.service.PayrollService;
import org.hinna.payments.service.StripeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class PayrollServiceImpl implements PayrollService {

    private final PayrollRepository payrollRepository;
    private final PayrollScheduleRepository payrollScheduleRepository;
    private final StaffRepository staffRepository;
    private final AccountRepository accountRepository;
    private final PaymentMethodRepository paymentMethodRepository;
    private final StripeService stripeService;
    private final PayrollPATIntegrationService patIntegrationService;

    @Autowired
    public PayrollServiceImpl(PayrollRepository payrollRepository, PayrollScheduleRepository payrollScheduleRepository, StaffRepository staffRepository, AccountRepository accountRepository, PaymentMethodRepository paymentMethodRepository, StripeService stripeService, PayrollPATIntegrationService patIntegrationService) {
        this.payrollRepository = payrollRepository;
        this.payrollScheduleRepository = payrollScheduleRepository;
        this.staffRepository = staffRepository;
        this.accountRepository = accountRepository;
        this.paymentMethodRepository = paymentMethodRepository;
        this.stripeService = stripeService;
        this.patIntegrationService = patIntegrationService;
    }

    @Override
    @Transactional
    public Payroll createPayroll(PayrollRequestDTO payrollRequest) {
        // Validate employee exists
        Staff employee = staffRepository.findById(payrollRequest.getEmployeeId())
                .orElseThrow(() -> new IllegalArgumentException("Employee not found"));

        // Validate processing account exists
        Account processingAccount = accountRepository.findById(payrollRequest.getProcessingAccountId())
                .orElseThrow(() -> new IllegalArgumentException("Processing account not found"));

        // Validate payment method if provided
        PaymentMethod paymentMethod = null;
        if (payrollRequest.getPaymentMethodId() != null) {
            paymentMethod = paymentMethodRepository.findById(payrollRequest.getPaymentMethodId())
                    .orElseThrow(() -> new IllegalArgumentException("Payment method not found"));
        }

        // Calculate net amount
        BigDecimal netAmount = payrollRequest.getGrossAmount();
        if (payrollRequest.getTaxWithheld() != null) {
            netAmount = netAmount.subtract(payrollRequest.getTaxWithheld());
        }
        if (payrollRequest.getDeductions() != null) {
            netAmount = netAmount.subtract(payrollRequest.getTaxWithheld());
        }

        // Ensure net amount is not negative
        netAmount = netAmount.max(BigDecimal.ZERO);

        // Create payroll
        Payroll payroll = Payroll.builder()
                .employee(employee)
                .processingAccount(processingAccount)
                .paymentMethod(paymentMethod)
                .grossAmount(payrollRequest.getGrossAmount())
                .netAmount(netAmount)
                .taxWithheld(payrollRequest.getTaxWithheld() != null ? payrollRequest.getTaxWithheld() : BigDecimal.ZERO)
                .deductions(payrollRequest.getDeductions() != null ? payrollRequest.getDeductions() : BigDecimal.ZERO)
                .description(payrollRequest.getDescription())
                .payPeriodStart(payrollRequest.getPayPeriodStart())
                .payPeriodEnd(payrollRequest.getPayPeriodEnd())
                .scheduledDate(payrollRequest.getScheduledDate() != null ? payrollRequest.getScheduledDate() : LocalDateTime.now())
                .status(PayrollStatus.SCHEDULED)
                .isAutomatic(payrollRequest.isAutomatic())
                .isAchEnabled(payrollRequest.isAchEnabled())
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        Payroll savedPayroll = payrollRepository.save(payroll);

        // Trigger PAT workflow if automatic
        if (savedPayroll.isAutomatic()) {
            patIntegrationService.triggerPayrollProcessingWorkflow(savedPayroll.getId(), savedPayroll);
        }

        return savedPayroll;
    }

    @Override
    public Optional<Payroll> getPayrollById(UUID payrollId) {
        return payrollRepository.findById(payrollId);
    }

    @Override
    public Optional<Payroll> getPayrollByReferenceNumber(String referenceNumber) {
        return payrollRepository.findByReferenceNumber(referenceNumber);
    }

    @Override
    public List<Payroll> getPayrollsByEmployee(UUID employeeId) {
        Staff employee = staffRepository.findById(employeeId)
                .orElseThrow(() -> new IllegalArgumentException("Employee not found"));
        return payrollRepository.findByEmployee(employee);
    }

    @Override
    public List<Payroll> getPayrollsByEmployer(UUID employerId) {
        Account employer = accountRepository.findById(employerId)
                .orElseThrow(() -> new IllegalArgumentException("Employer not found"));
        return payrollRepository.findByProcessingAccount(employer);
    }

    @Override
    public List<Payroll> getPayrollsByStatus(PayrollStatus status) {
        return payrollRepository.findByStatus(status);
    }

    @Override
    public List<Payroll> getScheduledPayrolls(LocalDateTime start, LocalDateTime end) {
        return payrollRepository.findByScheduledDateBetweenAndStatus(start, end, PayrollStatus.SCHEDULED);
    }

    @Override
    @Transactional
    public Payroll processPayroll(UUID payrollId) {
        Payroll payroll = payrollRepository.findById(payrollId)
                .orElseThrow(() -> new IllegalArgumentException("Payment not found"));

        if (payroll.getStatus() != PayrollStatus.SCHEDULED) {
            throw new IllegalStateException("Payroll is not in scheduled state");
        }

        // Update status to processing
        payroll.setStatus(PayrollStatus.PROCESSING);
        return payrollRepository.save(payroll);
    }

    @Override
    public Payroll completePayroll(UUID payrollId) {
        Payroll payroll = payrollRepository.findById(payrollId)
                .orElseThrow(() -> new IllegalArgumentException("Payroll not found"));

        if (payroll.getStatus() != PayrollStatus.PROCESSING) {
            throw new IllegalStateException("Payroll is not in processing state");
        }

        // Integrate with Stripe to process the payment
        boolean success = stripeService.processOutgoingPayment(payroll);

        if (success) {
            // Update status to completed
            payroll.setStatus(PayrollStatus.COMPLETED);
            payroll.setProcessedDate(LocalDateTime.now());

            // Send notification
            patIntegrationService.createPayrollNotificationStep(payroll);
        } else {
            payroll.setStatus(PayrollStatus.FAILED);
            payroll.setErrorMessage("Payment processing failed");
        }

        return payrollRepository.save(payroll);
    }

    @Override
    public Payroll cancelPayroll(UUID payrollId) {
        return null;
    }

    @Override
    @Transactional
    public int processScheduledPayrolls() {
        return 0;
    }

    @Override
    @Transactional
    public PayrollSchedule createPayrollSchedule(PayrollScheduleRequestDTO scheduleDTO) {
        // Validate employee exists
        Staff employee = staffRepository.findById(scheduleDTO.getEmployeeId())
                .orElseThrow(() -> new IllegalArgumentException("Employee not found"));

        // Validate employer exists
        Account employer = accountRepository.findById(scheduleDTO.getEmployerId())
                .orElseThrow(() -> new IllegalArgumentException("Employer not found"));

        // Validate payment method if provided
        PaymentMethod paymentMethod = null;
        if (scheduleDTO.getPaymentMethodId() != null) {
            paymentMethod = paymentMethodRepository.findById(scheduleDTO.getPaymentMethodId())
                    .orElseThrow(() -> new IllegalArgumentException("Payment method not found"));
        }

        // Parse frequency
        PayrollFrequency frequency;
        try {
            frequency = PayrollFrequency.valueOf(scheduleDTO.getFrequency());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid frequency: " + scheduleDTO.getFrequency());
        }

        // Parse day of week if provided
        DayOfWeek dayOfWeek = null;
        if (scheduleDTO.getDayOfWeek() != null && !scheduleDTO.getDayOfWeek().isEmpty()) {
            try {
                dayOfWeek = DayOfWeek.valueOf(scheduleDTO.getDayOfWeek());
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("Invalid day of week: "  + scheduleDTO.getDayOfWeek());
            }
        }

        // Create schedule
        PayrollSchedule schedule = PayrollSchedule.builder()
                .employee(employee)
                .employer(employer)
                .employer(employer)
                .paymentMethod(paymentMethod)
                .frequency(frequency)
                .dayOfMonth(scheduleDTO.getDayOfMonth())
                .dayOfWeek(dayOfWeek)
                .grossAmount(scheduleDTO.getGrossAmount())
                .taxRate(scheduleDTO.getTaxRate())
                .deductions(scheduleDTO.getDeductions())
                .description(scheduleDTO.getDescription())
                .isActive(scheduleDTO.isActive())
                .isAchEnabled(scheduleDTO.isAchEnabled())
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        // Calculate next payment date
        schedule.calculateNextPaymentDate();

        PayrollSchedule savedSchedule = payrollScheduleRepository.save(schedule);

        // Create PAT workflow for this schedule
        if (savedSchedule.isActive()) {
            patIntegrationService.createPayrollScheduleWorkflow(
                    savedSchedule.getEmployer().getId(),
                    savedSchedule.getId()
            );
        }

        return savedSchedule;
    }

    @Override
    public Optional<PayrollSchedule> getPayrollScheduleById(UUID scheduleId) {
        return payrollScheduleRepository.findById(scheduleId);
    }

    @Override
    public List<PayrollSchedule> getSchedulesByEmployee(UUID employeeId) {
        Staff employee = staffRepository.findById(employeeId)
                .orElseThrow(() -> new IllegalArgumentException("Employee not found"));
        return payrollScheduleRepository.findByEmployeeAndIsActiveTrue(employee);
    }

    @Override
    public List<PayrollSchedule> getSchedulesByEmployer(UUID employerId) {
        Account employer = accountRepository.findById(employerId)
                .orElseThrow(() -> new IllegalArgumentException("Employer not found"));
        return payrollScheduleRepository.findByEmployerAndIsActiveTrue(employer);
    }

    @Override
    @Transactional
    public PayrollSchedule updatePayrollSchedule(UUID scheduleId, PayrollScheduleRequestDTO scheduleDTO) {
        PayrollSchedule schedule = payrollScheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new IllegalArgumentException("Payroll schedule not found"));

        // Update employee if provided
        if (scheduleDTO.getEmployeeId() != null) {
            Staff employee = staffRepository.findById(scheduleDTO.getEmployeeId())
                    .orElseThrow(() -> new IllegalArgumentException("Employee not found"));
            schedule.setEmployee(employee);
        }

        // Update employer if provided
        if (scheduleDTO.getEmployerId() != null) {
            Account employer = accountRepository.findById(scheduleDTO.getEmployerId())
                    .orElseThrow(() -> new IllegalArgumentException("Employer not found"));
            schedule.setEmployer(employer);
        }

        // Update payment method if provided
        if (scheduleDTO.getPaymentMethodId() != null) {
            PaymentMethod paymentMethod = paymentMethodRepository.findById(scheduleDTO.getPaymentMethodId())
                    .orElseThrow(() -> new IllegalArgumentException("Payment method not found"));
            schedule.setPaymentMethod(paymentMethod);
        }

        // Update frequency if provided
        if (scheduleDTO.getFrequency() != null && !scheduleDTO.getFrequency().isEmpty()) {
            try {
                PayrollFrequency frequency = PayrollFrequency.valueOf(scheduleDTO.getFrequency());
                schedule.setFrequency(frequency);
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("Invalid frequency: " + scheduleDTO.getFrequency());
            }
        }

        // Update day of week if provided
        if (scheduleDTO.getDayOfWeek() != null && !scheduleDTO.getDayOfWeek().isEmpty()) {
            try {
                DayOfWeek dayOfWeek = DayOfWeek.valueOf(scheduleDTO.getDayOfWeek());
                schedule.setDayOfWeek(dayOfWeek);
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("Invalid day of week: " + scheduleDTO.getDayOfWeek());
            }
        }

        // Update day of month if provided
        if (scheduleDTO.getDayOfMonth() != null) {
            schedule.setDayOfMonth(scheduleDTO.getDayOfMonth());
        }

        // Update amounts and rates
        if (scheduleDTO.getGrossAmount() != null) {
            schedule.setGrossAmount(scheduleDTO.getGrossAmount());
        }
        if (scheduleDTO.getTaxRate() != null) {
            schedule.setTaxRate(scheduleDTO.getTaxRate());
        }
        if (scheduleDTO.getDeductions() != null) {
            schedule.setDeductions(scheduleDTO.getDeductions());
        }

        // Update description
        if (scheduleDTO.getDescription() != null) {
            schedule.setDescription(scheduleDTO.getDescription());
        }

        // Track if active status changed
        boolean wasActive = schedule.isActive();
        boolean willBeActive = scheduleDTO.isActive();

        // Update flags
        schedule.setActive(scheduleDTO.isActive());
        schedule.setAchEnabled(scheduleDTO.isAchEnabled());

        // Update timestamp
        schedule.setUpdatedAt(LocalDateTime.now());

        // Recalculate next payment date
        schedule.calculateNextPaymentDate();

        PayrollSchedule updatedSchedule = payrollScheduleRepository.save(schedule);

        // Update PAT workflow if active status changed
        if (!wasActive && willBeActive) {
            // Create workflow if activated
            patIntegrationService.createPayrollScheduleWorkflow(
                    updatedSchedule.getEmployer().getId(),
                    updatedSchedule.getId());
        }

        return updatedSchedule;
    }

    @Override
    @Transactional
    public void deletePayrollSchedule(UUID scheduleId) {
        payrollScheduleRepository.findById(scheduleId);
    }

    @Override
    @Transactional
    public PayrollSchedule activateSchedule(UUID scheduleId) {
        PayrollSchedule schedule = payrollScheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new IllegalArgumentException("Payroll schedule not found"));

        schedule.setActive(true);
        schedule.setUpdatedAt(LocalDateTime.now());
        schedule.calculateNextPaymentDate();

        PayrollSchedule activatedSchedule = payrollScheduleRepository.save(schedule);

        // Create PAT workflow
        patIntegrationService.createPayrollScheduleWorkflow(
                activatedSchedule.getEmployer().getId(),
                activatedSchedule.getId());

        return activatedSchedule;
    }

    @Override
    @Transactional
    public PayrollSchedule deactivateSchedule(UUID scheduleId) {
        PayrollSchedule schedule = payrollScheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new IllegalArgumentException("Payroll schedule not found"));

        schedule.setActive(false);
        schedule.setUpdatedAt(LocalDateTime.now());

        return payrollScheduleRepository.save(schedule);
    }

    @Override
    @Transactional
    public int generateScheduledPayrolls() {
        // Get active schedules with next payment date before or equal to now
        LocalDateTime now = LocalDateTime.now();
        List<PayrollSchedule> dueSchedules = payrollScheduleRepository.findByNextPaymentDateBeforeAndIsActiveTrue(now);

        int generated = 0;
        for (PayrollSchedule schedule : dueSchedules) {
            try {
                // Create payroll from schedule
                BigDecimal netAmount = schedule.calculateNetAmount();

                Payroll payroll = Payroll.builder()
                        .employee(schedule.getEmployee())
                        .processingAccount(schedule.getEmployer())
                        .paymentMethod(schedule.getPaymentMethod())
                        .grossAmount(schedule.getGrossAmount())
                        .netAmount(netAmount)
                        .taxWithheld(schedule.getTaxRate() != null ?
                                schedule.getGrossAmount().multiply(schedule.getTaxRate()).divide(new BigDecimal("100"), 2, java.math.RoundingMode.HALF_UP) :
                                BigDecimal.ZERO)
                        .deductions(schedule.getDeductions() != null ? schedule.getDeductions() : BigDecimal.ZERO)
                        .description(schedule.getDescription() != null ?
                                schedule.getDescription() :
                                "Scheduled payment for " + schedule.getEmployee().getFullName())
                        .payPeriodStart(schedule.getNextPaymentDate().minusDays(this.getDaysInPeriod(schedule.getFrequency())))
                        .payPeriodEnd(schedule.getNextPaymentDate())
                        .scheduledDate(schedule.getNextPaymentDate())
                        .status(PayrollStatus.SCHEDULED)
                        .isAutomatic(true)
                        .isAchEnabled(schedule.isAchEnabled())
                        .createdAt(LocalDateTime.now())
                        .updatedAt(LocalDateTime.now())
                        .build();

                Payroll savedPayroll = payrollRepository.save(payroll);

                // Update next payment date in schedule
                schedule.calculateNextPaymentDate();
                schedule.setUpdatedAt(LocalDateTime.now());
                payrollScheduleRepository.save(schedule);

                // Trigger PAT workflow
                patIntegrationService.triggerPayrollProcessingWorkflow(savedPayroll.getId(), savedPayroll);

                generated++;
            } catch (Exception e) {
                log.error("Error generating payroll for schedule {}: {}", schedule.getId(), e.getMessage());
            }
        }

        return generated;
    }

    /**
     * Helper method to get the number of days in a payment period
     */
    private int getDaysInPeriod(PayrollFrequency frequency) {
        return switch (frequency) {
            case WEEKLY -> 7;
            case BI_WEEKLY -> 14;
            case SEMI_MONTHLY -> 15;
            case MONTHLY -> 30;
        };
    }


    @Override
    public BigDecimal calculatePayrollExpense(UUID employerId, LocalDateTime start, LocalDateTime end) {
        Account employer = accountRepository.findById(employerId)
                .orElseThrow(() -> new IllegalArgumentException("Employer not found"));

        // Get all completed payrolls for the employer in the date range
        List<Payroll> payrolls = payrollRepository.findByProcessingAccount(employer);

        // Filter by process date in range and completed status
        List<Payroll> completedPayrolls = payrolls.stream()
                .filter(p -> p.getStatus() == PayrollStatus.COMPLETED &&
                        p.getProcessedDate() != null &&
                        !p.getProcessedDate().isBefore(start) &&
                        !p.getProcessedDate().isAfter(end))
                .toList();

        // Sum up the gross amounts
        return completedPayrolls.stream()
                .map(Payroll::getGrossAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    @Override
    public EmployeePayrollDTO getEmployeePayrollSummary(UUID employeeId, LocalDateTime start, LocalDateTime end) {
        Staff employee = staffRepository.findById(employeeId)
                .orElseThrow(() -> new IllegalArgumentException("Employee not found"));

        // Get all completed payrolls for the employee in the date range
        List<Payroll> payrolls = payrollRepository.findByEmployee(employee);

        // Filter by processed date in range and completed status
        List<Payroll> completedPayrolls = payrolls.stream()
                .filter(p -> p.getStatus() == PayrollStatus.COMPLETED &&
                        p.getProcessedDate() != null &&
                        !p.getProcessedDate().isBefore(start) &&
                        !p.getProcessedDate().isAfter(end))
                .toList();

        // Calculate totals
        BigDecimal totalGross = BigDecimal.ZERO;
        BigDecimal totalNet = BigDecimal.ZERO;
        BigDecimal totalTax = BigDecimal.ZERO;
        BigDecimal totalDeductions = BigDecimal.ZERO;

        for (Payroll payroll : completedPayrolls) {
            totalGross = totalGross.add(payroll.getGrossAmount());
            totalNet = totalNet.add(payroll.getNetAmount());
            totalTax = totalTax.add(payroll.getTaxWithheld());
            totalDeductions = totalDeductions.add(payroll.getDeductions());
        }

        // Build the summary DTO
        return EmployeePayrollDTO.builder()
                .employeeId(employee.getId())
                .employeeName(employee.getFullName())
                .position(employee.getPosition())
                .employmentType("Full-Time") // This would come from employee details in a real implementation
                .totalGrossAmount(totalGross)
                .totalNetAmount(totalNet)
                .totalTaxWithheld(totalTax)
                .totalDeductions(totalDeductions)
                .paymentCount(completedPayrolls.size())
                .periodStart(start)
                .periodEnd(end)
                .build();
    }

    @Override
    @Transactional
    public PayrollSchedule setAchPaymentEnabled(UUID scheduleId, boolean enabled) {
        PayrollSchedule schedule = payrollScheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new IllegalArgumentException("Payroll schedule not found"));

        schedule.setAchEnabled(enabled);
        schedule.setUpdatedAt(LocalDateTime.now());

        return payrollScheduleRepository.save(schedule);
    }

    @Override
    public List<Payroll> searchPayrolls(String searchTerm) {
        // Simplified implementation. Should implement more sophisticated search
        if (searchTerm == null || searchTerm.isEmpty()) {
            return new ArrayList<>();
        }

        // Try to parse as UUID for employee ID
        UUID employeeId = null;
        try {
            employeeId = UUID.fromString(searchTerm);
        } catch (IllegalArgumentException e) {
            // Not a valid UUID, leave as null
        }

        return List.of();
    }

    @Override
    @Transactional
    public PayrollSchedule updatePaymentMethod(UUID scheduleId, UUID paymentMethodId) {
        PayrollSchedule schedule = payrollScheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new IllegalArgumentException("Payroll schedule not found"));

        PaymentMethod paymentMethod = paymentMethodRepository.findById(paymentMethodId)
                .orElseThrow(() -> new IllegalArgumentException("Payment method not found"));

        schedule.setPaymentMethod(paymentMethod);
        schedule.setUpdatedAt(LocalDateTime.now());

        return payrollScheduleRepository.save(schedule);
    }
}
