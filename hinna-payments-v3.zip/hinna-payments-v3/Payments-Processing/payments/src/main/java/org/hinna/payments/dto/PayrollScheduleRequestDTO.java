package org.hinna.payments.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PayrollScheduleRequestDTO {
    private UUID employeeId;
    private UUID employerId;
    private UUID paymentMethodId;
    private String frequency;
    private Integer dayOfMonth;
    private String dayOfWeek;
    private BigDecimal grossAmount;
    private BigDecimal taxRate;
    private BigDecimal deductions;
    private String description;
    private boolean isActive;
    private boolean isAchEnabled;
}
