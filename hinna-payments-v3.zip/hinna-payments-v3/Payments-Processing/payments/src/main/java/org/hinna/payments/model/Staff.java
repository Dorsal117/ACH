package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "staff")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = {"employer", "staffGroup"}, callSuper = true)
public class Staff extends Account {

    private String position;

    private String department;

    @Column(name = "biography")
    private String biography;

    @Column(name = "url_website")
    private String urlWebsite;

    private String facebook;

    private String instagram;

    private String tiktok;

    @Column(name = "is_admin")
    private Boolean isAdmin;

    @ManyToOne
    @JoinColumn(name = "employer_id")
    private DirectCustomer employer;

    @ManyToOne
    @JoinColumn(name = "staff_group_id")
    private StaffGroup staffGroup;
}
