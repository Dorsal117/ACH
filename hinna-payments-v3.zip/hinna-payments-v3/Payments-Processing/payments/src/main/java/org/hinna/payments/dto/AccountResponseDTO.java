package org.hinna.payments.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Data Transfer Object for account responses
 */
@Data
public class AccountResponseDTO {
    private UUID id;
    private String firstName;
    private String lastName;
    private String email;
    private String mobilePhone;
    private String homePhone;
    private String address;
    private String dob;
    private String gender;
    private String profilePicturePath;
    private String qrCodePath;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private String accountType; // CLIENT, BUSINESS, STAFF, RESELLER, SAAS
    private boolean active;
}
