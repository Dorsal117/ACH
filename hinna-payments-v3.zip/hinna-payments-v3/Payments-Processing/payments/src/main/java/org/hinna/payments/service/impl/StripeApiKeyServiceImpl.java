package org.hinna.payments.service.impl;

import org.hinna.payments.model.*;
import org.hinna.payments.repository.StripeApiKeyRepository;
import org.hinna.payments.security.EncryptionUtil;
import org.hinna.payments.service.StripeApiKeyService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class StripeApiKeyServiceImpl implements StripeApiKeyService {

    private static final Logger log = LoggerFactory.getLogger(StripeApiKeyServiceImpl.class);
    private final StripeApiKeyRepository stripeApiKeyRepository;
    private final EncryptionUtil encryptionUtil;

    @Autowired
    public StripeApiKeyServiceImpl(StripeApiKeyRepository repository,
                                   @Value("${encryption.key}") String encryptionKey) {
        this.stripeApiKeyRepository = repository;
        this.encryptionUtil = new EncryptionUtil(encryptionKey);
    }

    @Override
    public void storeApiKey(String keyAlias, String apiKey) {
        try {
            // Encrypt the API key
            String encrypted = encryptionUtil.encrypt(apiKey);

            // Check if key already exists
            Optional<StripeApiKey> existingKey = stripeApiKeyRepository.findByKeyAlias(keyAlias);

            StripeApiKey entity;
            if (existingKey.isPresent()) {
                // Updating existing
                entity = existingKey.get();
                entity.setEncryptedKey(encrypted);
            } else {
                // Created new key
                entity = new StripeApiKey(keyAlias, encrypted);
            }

            stripeApiKeyRepository.save(entity);
            log.info("Stored API key with alias: {}", keyAlias);
        } catch (Exception e) {
            log.error("Failed to encrypt and store API key: {}", e.getMessage());
            throw new RuntimeException("Failed to encrypt and store API key", e);
        }
    }

    @Override
    public String getDecryptedKey(String keyAlias) {
        try {
            Optional<StripeApiKey> result = stripeApiKeyRepository.findByKeyAlias(keyAlias);
            if (result.isEmpty()) {
                throw new IllegalStateException("API key not found for alias: " + keyAlias);
            }
            return encryptionUtil.decrypt(result.get().getEncryptedKey());
        } catch (Exception e) {
            log.error("Failed to retrieve or decrypt API key: {}", e.getMessage());
            throw new RuntimeException("Failed to retrieve or decrypt API key", e);
        }
    }

    @Override
    public boolean hasApiKeyAlias(String keyAlias) {
        return stripeApiKeyRepository.findByKeyAlias(keyAlias).isPresent();
    }

    @Override
    @Transactional
    public boolean deleteApiKey(String keyAlias) {
        Optional<StripeApiKey> key = stripeApiKeyRepository.findByKeyAlias(keyAlias);
        if (key.isPresent()) {
            stripeApiKeyRepository.delete(key.get());
            log.info("Deleted API key with alias: {}", keyAlias);
            return true;
        }
        return false;
    }
}
