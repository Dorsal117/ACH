package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;
import org.hinna.payments.model.enums.TransactionStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "payment_transaction")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = "payment")
@EqualsAndHashCode(of = "id")
public class PaymentTransaction {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "payment_id")
    private Payment payment;

    @Enumerated(EnumType.STRING)
    private TransactionStatus status;

    @Column(name = "provider_reference")
    private String providerReference;

    private LocalDateTime timestamp;

    private String message;

    @Column(precision = 19, scale = 4)
    private BigDecimal amount;

    public PaymentTransaction(Payment payment, TransactionStatus status, BigDecimal amount) {
        this.payment = payment;
        this.status = status;
        this.amount = amount;
        this.timestamp = LocalDateTime.now();
    }

    @PrePersist
    public void onCreate() {
        if (this.timestamp == null) {
            this.timestamp = LocalDateTime.now();
        }
    }
}