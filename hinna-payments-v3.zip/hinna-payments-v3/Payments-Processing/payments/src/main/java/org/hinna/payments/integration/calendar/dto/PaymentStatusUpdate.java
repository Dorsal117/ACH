package org.hinna.payments.integration.calendar.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * Payment status update for calendar events
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentStatusUpdate {
    private String event_id;
    private String paymentId;
    private String paymentStatus;
    private Date updateTime;
    private Double amount;
}
