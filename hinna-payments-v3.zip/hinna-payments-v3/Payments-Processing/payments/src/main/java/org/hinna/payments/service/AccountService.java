package org.hinna.payments.service;

import org.hinna.payments.integration.user.dto.AccountCreationRequest;
import org.hinna.payments.model.Account;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Service for managing accounts in the payment system
 * Modified to work with the User Service integration
 */
public interface AccountService {

    Account createAccountForExternalUser(AccountCreationRequest request);

    /**
     * Get an account by ID
     * @param accountId Account ID
     * @return Optional containing the account if found
     */
    Optional<Account> getAccountById(UUID accountId);

    /**
     * Get an account by email
     * @param email Email address
     * @return Optional containing the account if found
     */
    Optional<Account> getAccountByEmail(String email);

    /**
     * Get an account by external User ID (from User Service)
     * @param externalUserId User ID from User Service
     * @return Optional containing the account if found
     */
    Optional<Account> getAccountByExternalUserId(Long externalUserId);

    /**
     * Get all accounts with pagination
     * @param pageable Pagination parameters
     * @return Page of accounts
     */
    Page<Account> getAllAccounts(Pageable pageable);

    /**
     * Update an account
     * @param id Account ID
     * @param accountDetails Updated account details
     * @return Updated account
     */
    Account updateAccount(UUID id,Account accountDetails);

    boolean isEmailTaken(String email);

    /**
     * Search accounts by name or email
     * @param searchTerm Search term
     * @return List of matching accounts
     */
    List<Account> searchAccounts(String searchTerm);

    /**
     * Get all active accounts
     * @return List of active accounts
     */
    List<Account> getActiveAccounts();

    /**
     * Link an account to an external user
     * @param accountId Account ID
     * @param externalUserId User ID from User Service
     * @return Updated account
     */
    Account linkExternalUser(UUID accountId, Long externalUserId);

    List<Account> findAccountsWithNegativeBalance();
}
