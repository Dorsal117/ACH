package org.hinna.payments.integration.user.service;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.integration.user.config.UserServiceRabbitMQConfig;
import org.hinna.payments.integration.user.dto.UserCreatedEvent;
import org.hinna.payments.integration.user.mapper.UserAccountMapper;
import org.hinna.payments.model.Account;
import org.hinna.payments.repository.AccountRepository;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * Service for handling User Service events and integrating with the payment system.
 */
@Service
@Slf4j
public class UserIntegrationService {

//    private final RabbitTemplate rabbitTemplate;
//    private final AccountRepository accountRepository;
//    private final UserAccountMapper userAccountMapper;
//
//    @Autowired
//    public UserIntegrationService(RabbitTemplate rabbitTemplate, AccountRepository accountRepository, UserAccountMapper userAccountMapper) {
//        this.rabbitTemplate = rabbitTemplate;
//        this.accountRepository = accountRepository;
//        this.userAccountMapper = userAccountMapper;
//    }
//
//    /**
//     * Process user created events from the user service
//     * @param event UserCreatedEvent
//     */
//    @RabbitListener(queues = UserServiceRabbitMQConfig.USER_CREATED_QUEUE)
//    @Transactional
//    public void handleUserCreateEvent(UserCreatedEvent event) {
//        log.info("Received user created event: {}");
//    }
}
