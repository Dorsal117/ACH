package org.hinna.payments.integration.booking.service;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.integration.config.RabbitMQConfig;
import org.hinna.payments.integration.booking.dto.BookingCancelledEvent;
import org.hinna.payments.integration.booking.dto.BookingCreatedEvent;
import org.hinna.payments.integration.booking.dto.BookingPaidEvent;
import org.hinna.payments.model.*;
import org.hinna.payments.model.enums.PaymentStatus;
import org.hinna.payments.service.AccountService;
import org.hinna.payments.service.InvoiceService;
import org.hinna.payments.service.PaymentService;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class BookingIntegrationService {

    // Simple in-memory map to store booking to invoice mapping
    // Would be stored in a database
    private final Map<UUID, UUID> bookingInvoiceMap = new HashMap<>();

    private final RabbitTemplate rabbitTemplate;
    private final AccountService accountService;
    private final InvoiceService invoiceService;
    private final PaymentService paymentService;

    @Autowired
    public BookingIntegrationService(RabbitTemplate rabbitTemplate,
                                     AccountService accountService,
                                     InvoiceService invoiceService,
                                     PaymentService paymentService) {
        this.rabbitTemplate = rabbitTemplate;
        this.accountService = accountService;
        this.invoiceService = invoiceService;
        this.paymentService = paymentService;
    }

    /**
     * Process booking created events from the booking service
     * @param event BookingCreatedEvent
     */
    @RabbitListener(queues = RabbitMQConfig.BOOKING_CREATED_QUEUE)
    @Transactional
    public void handleBookingCreatedEvent(BookingCreatedEvent event) {
        log.info("Received booing created event: {}", event);

        try {
            // Find the business account (businessId maps to an account)
            Optional<Account> accountOpt = accountService.getAccountById(event.getBusinessId());
            if (accountOpt.isEmpty()) {
                log.error("Cannot find account for business: {}", event.getBusinessId());
                return;
            }

            Account account = accountOpt.get();

            // Create invoice for the booking
            Invoice invoice = new Invoice(account, LocalDateTime.now(), LocalDateTime.now().plusDays(30));

            // Add invoice items based on the pricing structure
            if (event.getPrices() != null && !event.getPrices().isEmpty()) {
                for (BookingCreatedEvent.PriceDto priceDto : event.getPrices()) {
                    // Handle each price entry as a separate line item
                    String itemDescription = this.generateItemDescription(event, priceDto);

                    // Convert to BigDecimal for invoice item
                    BigDecimal priceAmount = BigDecimal.valueOf(priceDto.getAmount());

                    // Default tax rate (would be configurable later)
                    BigDecimal taxRate = new BigDecimal("13.00");

                    // Create invoice item
                    InvoiceItem item = new InvoiceItem(
                            itemDescription,
                            1, // Quantity
                            priceAmount,
                            taxRate
                    );

                    // Add reference information
                    item.setItemType(event.getServiceType());
                    item.setItemId(event.getBookingId());

                    // Add to invoice
                    invoice.addItem(item);
                }
            } else {
                // If no prices provided, create a generic line item
                InvoiceItem item = new InvoiceItem(
                        "Booking: " + event.getBookingId(),
                        1, // quantity
                        BigDecimal.ZERO, // No price specified
                        new BigDecimal("13.00") // Default tax rate
                );

                item.setItemType(event.getServiceType());
                item.setItemId(event.getBookingId());

                invoice.addItem(item);
            }

            // Save the invoice
            Invoice savedInvoice = invoiceService.createInvoice(invoice);

            log.info("Created invoice {} for booking {}", savedInvoice.getId(), event.getBookingId());

            // Store the mapping between booking ID and invoiceID for future reference
            // Would typically be stored in a database
            bookingInvoiceMap.put(event.getBookingId(), savedInvoice.getId());

        } catch (Exception e) {
            log.error("Error processing booking created event", e);
        }
    }

    /**
     * Generate an appropriate description for the invoice item
     */
    private String generateItemDescription(BookingCreatedEvent event, BookingCreatedEvent.PriceDto priceDto) {
        StringBuilder description = new StringBuilder();

        if (event.getServiceType() != null) {
            description.append(event.getServiceType());
        } else {
            description.append("Service");
        }

        if (event.getCategory() != null) {
            description.append(" - ").append(event.getCategory());
        }

        if (priceDto.getClassDuration() != null) {
            description.append(" (").append(priceDto.getClassDuration()).append(" minutes");
        }

        return description.toString();
    }

    /**
     * Process booking cancelled events from the booking service
     * @param event BookingCancelledEvent
     */
    @RabbitListener(queues = RabbitMQConfig.BOOKING_CANCELLED_QUEUE)
    @Transactional
    public void handleBookingCancelledEvent(BookingCancelledEvent event) {
        log.info("Received booking cancelled event: {}", event);

        try {
            if (event.getRefundRequested() && event.getPaymentId() != null) {
                // Get the payment
                Optional<Payment> paymentOpt = paymentService.getPaymentById(event.getPaymentId());

                if (paymentOpt.isEmpty()) {
                    log.error("Cannot find payment with ID: {}", event.getPaymentId());
                    return;
                }

                Payment payment = paymentOpt.get();

                // Determine refund amount based on policy
                BigDecimal refundAmount = calculateRefundAmount(payment, event);

                if (refundAmount.compareTo(BigDecimal.ZERO) > 0) {
                    // Use existing refundPayment method
                    Refund refund = paymentService.refundPayment(
                            payment.getId(),
                            refundAmount,
                            "Booking cancelled: " + event.getCancellationReason()
                    );

                    // Notify booking service
                    this.publishRefundProcessedEvent(
                            event.getBookingId(),
                            payment.getId(),
                            refund.getAmount() // Use the actual refunded amount from the result
                    );

                    log.info("Processed refund of {} for cancelled booking: {}",
                            refundAmount, event.getBookingId());
                }
            }
        } catch (Exception e) {
            log.error("Error processing booking cancelled event", e);
        }
    }

    private BigDecimal calculateRefundAmount(Payment payment, BookingCancelledEvent event) {
        // Apply refund policy
        if (event.getIsWithinWithdrawWindow()) {
            return payment.getAmount(); // Full refund
        } else {
            return BigDecimal.ZERO;
        }
    }

    /**
     * Publish payment processed event to notify the booking service
     * @param bookingId ID of the booking
     * @param payment Payment
     */
    public void publishPaymentProcessedEvent(UUID bookingId, Payment payment) {
        log.info("Publish payment processed event for booking: {}", bookingId);

        BookingPaidEvent event = BookingPaidEvent.builder()
                .bookingId(bookingId)
                .paymentId(payment.getId())
                .paymentTime(payment.getProcessedAt())
                .amountPaid(payment.getAmount())
                .paymentMethod(payment.getMethod().getType().name())
                .paymentStatus(payment.getStatus().name())
                .transactionReference(payment.getReferenceNumber())
                .build();

        rabbitTemplate.convertAndSend(
                RabbitMQConfig.PAYMENT_EXCHANGE,
                RabbitMQConfig.PAYMENT_PROCESSED_KEY,
                event
        );
    }

    /**
     * Publish refund processed event to notify the booking service
     */
    public void publishRefundProcessedEvent(UUID bookingId, UUID paymentId, BigDecimal refundAmount) {
        log.info("Publishing refund processed event for booking: {}", bookingId);

        Map<String, Object> refundEvent = Map.of(
                "bookingId", bookingId,
                "paymentId", paymentId,
                "refundAmount", refundAmount,
                "refundTime", LocalDateTime.now(),
                "status", "COMPLETED"
        );

        rabbitTemplate.convertAndSend(
                RabbitMQConfig.PAYMENT_EXCHANGE,
                RabbitMQConfig.REFUND_PROCESSED_KEY,
                refundEvent
        );
    }

    /**
     * Process a payment for a booking
     * Would be called from payment service when a payment is completed
     * @param bookingId booking's ID
     * @param payment Payment
     */
    @Transactional
    public void processBookingPayment(UUID bookingId, Payment payment) {
        log.info("Process payment for booking: {}", bookingId);

        // Only process if payment is completed
        if (payment.getStatus() == PaymentStatus.COMPLETED) {
            // Notify te booking service
            this.publishPaymentProcessedEvent(bookingId, payment);

            log.info("Payment processed for booking: {}", bookingId);
        } else {
            log.warn("Cannot process payment for booking: {} - payment status is: {}",
                    bookingId, payment.getStatus());
        }
    }

}
