package org.hinna.payments.service;

import org.hinna.payments.model.Account;
import org.hinna.payments.model.PaymentMethod;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface PaymentMethodService {
    PaymentMethod createPaymentMethod(PaymentMethod paymentMethod);
    Optional<PaymentMethod> getPaymentMethodById(UUID id);
    List<PaymentMethod> getPaymentMethodsByOwner(Account owner);
    List<PaymentMethod> getActivePaymentMethodsByOwner(Account owner);
    PaymentMethod updatePaymentMethod(UUID id, PaymentMethod paymentMethodDetails);
    void deletePaymentMethod(UUID id);
    void setDefaultPaymentMethod(UUID id, Account owner);
    boolean validatePaymentMethod(PaymentMethod paymentMethod);
    List<PaymentMethod> getExpiredPaymentMethods();
    void updatePaymentMethodPriorities(Account owner, List<UUID> orderedIds);
    boolean processPaymentWithFallback(Account owner, long amountInCents, String currency);

    PaymentMethod verifyAchMicroDeposits(UUID id, int firstAmount, int secondAmount);
    PaymentMethod refreshAchDetails(UUID id);


}
