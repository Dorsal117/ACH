package org.hinna.payments.service.impl;

import jakarta.transaction.Transactional;
import org.hinna.payments.model.DirectCustomer;
import org.hinna.payments.model.Staff;
import org.hinna.payments.model.StaffGroup;
import org.hinna.payments.repository.StaffGroupRepository;
import org.hinna.payments.repository.StaffRepository;
import org.hinna.payments.service.AccountService;
import org.hinna.payments.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class StaffServiceImpl implements StaffService {

    private final StaffRepository staffRepository;
    private final StaffGroupRepository staffGroupRepository;
    private final AccountService accountService;

    @Autowired
    public StaffServiceImpl(StaffRepository staffRepository, StaffGroupRepository staffGroupRepository, AccountService accountService) {
        this.staffRepository = staffRepository;
        this.staffGroupRepository = staffGroupRepository;
        this.accountService = accountService;
    }

    @Override
    @Transactional
    public Staff createStaff(Staff staff) {
        return null;
    }

    @Override
    public Optional<Staff> getStaffById(UUID id) {
        return staffRepository.findById(id);
    }

    @Override
    public Page<Staff> getAllStaff(Pageable pageable) {
        return staffRepository.findAll(pageable);
    }

    @Override
    public List<Staff> getStaffByEmployer(DirectCustomer employer) {
        return staffRepository.findByEmployer(employer);
    }

    @Override
    public List<Staff> getStaffByStaffGroup(StaffGroup staffGroup) {
        return staffRepository.findByStaffGroup(staffGroup);
    }

    @Override
    public List<Staff> getStaffByDepartment(String department) {
        return staffRepository.findByDepartment(department);
    }

    @Override
    @Transactional
    public Staff updateStaff(UUID id, Staff staffDetails) {
        return staffRepository.findById(id)
                .map(existingStaff -> {
                    // Only update email if it changed and isn't taken
                    if (!existingStaff.getEmail().equals(staffDetails.getEmail()) &&
                            accountService.isEmailTaken(staffDetails.getEmail())) {
                        throw new IllegalArgumentException("Email already in use");
                    }

                    // Update account fields
                    existingStaff.setFirstName(staffDetails.getFirstName());
                    existingStaff.setLastName(staffDetails.getLastName());
                    existingStaff.setEmail(staffDetails.getEmail());
                    existingStaff.setAddress(staffDetails.getAddress());
                    existingStaff.setMobilePhone(staffDetails.getMobilePhone());
                    existingStaff.setHomePhone(staffDetails.getHomePhone());

                    // Update staff specific fields
                    existingStaff.setPosition(staffDetails.getPosition());
                    existingStaff.setDepartment(staffDetails.getDepartment());
                    existingStaff.setBiography(staffDetails.getBiography());
                    existingStaff.setUrlWebsite(staffDetails.getUrlWebsite());
                    existingStaff.setFacebook(staffDetails.getFacebook());
                    existingStaff.setInstagram(staffDetails.getInstagram());
                    existingStaff.setTiktok(staffDetails.getTiktok());
                    existingStaff.setIsAdmin(staffDetails.getIsAdmin());

                    // Don't update employer or group - use specific methods

                    return staffRepository.save(existingStaff);
                })
                .orElseThrow(() -> new IllegalArgumentException("Staff not found with id: " + id));
    }

    @Override
    @Transactional
    public void deleteStaff(UUID id) {
        staffRepository.deleteById(id);
    }

    @Override
    public Staff assignToGroup(UUID staffId, UUID groupId) {
        Staff staff = staffRepository.findById(staffId)
                .orElseThrow(() -> new IllegalArgumentException("Staff not found with id: " + staffId));

        StaffGroup group = staffGroupRepository.findById(groupId)
                .orElseThrow(() -> new IllegalArgumentException("Staff group not found with id: " + groupId));

        staff.setStaffGroup(group);
        return staffRepository.save(staff);
    }

    @Override
    public boolean hasPermission(UUID staffId, String permissionName) {
        Staff staff = staffRepository.findById(staffId)
                .orElseThrow(() -> new IllegalArgumentException("Staff not found with id: " + staffId));

        return staff.getStaffGroup().hasPermission(permissionName);
    }

    @Override
    public List<Staff> getAdminStaff() {
        return staffRepository.findByIsAdminTrue(); 
    }
}
