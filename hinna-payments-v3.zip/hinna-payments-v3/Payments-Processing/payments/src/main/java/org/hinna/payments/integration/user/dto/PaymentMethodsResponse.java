package org.hinna.payments.integration.user.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Response DTO for payment methods endpoint.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Response containing user's payment methods")
public class PaymentMethodsResponse {

    @Schema(description = "Whether the request was successful", example = "true")
    private boolean success;

    @Schema(description = "Message describing the result", example = "Payment methods retrieved successfully")
    private String message;

    @Schema(description = "List of payment methods")
    private List<PaymentMethodDTO> paymentMethods;
}
