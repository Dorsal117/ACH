package org.hinna.payments.repository;

import org.hinna.payments.model.Item;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface ItemRepository extends JpaRepository<Item, UUID> {
    Optional<Item> findBySku(String sku);
    List<Item> findByStockQuantityLessThan(Integer quantity);
    List<Item> findByManufacturer(String manufacturer);
}
