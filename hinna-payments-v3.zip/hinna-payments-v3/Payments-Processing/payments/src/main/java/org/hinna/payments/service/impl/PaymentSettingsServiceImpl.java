package org.hinna.payments.service.impl;

import jakarta.transaction.Transactional;
import org.hinna.payments.integration.pat.PATIntegrationService;
import org.hinna.payments.integration.user.dto.AutomaticPaymentSettingsDTO;
import org.hinna.payments.model.*;
import org.hinna.payments.model.enums.PaymentStatus;
import org.hinna.payments.model.enums.PaymentType;
import org.hinna.payments.model.enums.TransactionStatus;
import org.hinna.payments.repository.AccountRepository;
import org.hinna.payments.repository.PaymentRepository;
import org.hinna.payments.repository.PaymentSettingsRepository;
import org.hinna.payments.service.AccountService;
import org.hinna.payments.service.PaymentSettingsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;

@Service
public class PaymentSettingsServiceImpl implements PaymentSettingsService {

    private static final Logger log = LoggerFactory.getLogger(PaymentSettingsServiceImpl.class);
    private final PaymentSettingsRepository paymentSettingsRepository;
    private final AccountRepository accountRepository;
    private final PaymentRepository paymentRepository;
    private final PATIntegrationService patIntegrationService;
    private final AccountService accountService;

    @Autowired
    public PaymentSettingsServiceImpl(PaymentSettingsRepository paymentSettingsRepository,
                                      AccountRepository accountRepository,
                                      PaymentRepository paymentRepository,
                                      PATIntegrationService patIntegrationService,
                                      AccountService accountService) {
        this.paymentSettingsRepository = paymentSettingsRepository;
        this.accountRepository = accountRepository;
        this.paymentRepository = paymentRepository;
        this.patIntegrationService = patIntegrationService;
        this.accountService = accountService;
    }

    @Override
    @Transactional
    public PaymentSettings createPaymentSettings(PaymentSettings paymentSettings) {
        if (paymentSettingsRepository.findByAccount(paymentSettings.getAccount()).isPresent()) {
            throw new IllegalArgumentException("Payment settings already exist for this account");
        }
        return paymentSettingsRepository.save(paymentSettings);
    }

    @Override
    public Optional<PaymentSettings> getPaymentSettingsById(UUID id) {
        return paymentSettingsRepository.findById(id);
    }

    @Override
    public Optional<PaymentSettings> getPaymentSettingsByAccount(Account account) {
        return paymentSettingsRepository.findByAccount(account);
    }

    @Override
    public Page<PaymentSettings> getAllPaymentSettings(Pageable pageable) {
        return paymentSettingsRepository.findAll(pageable);
    }

    @Override
    @Transactional
    public PaymentSettings updatePaymentSettings(UUID id, PaymentSettings paymentSettingsDetails) {
        return paymentSettingsRepository.findById(id)
                .map(existingSettings -> {
                    existingSettings.setRetryAttempts(paymentSettingsDetails.getRetryAttempts());
                    existingSettings.setRetryIntervalMinutes(paymentSettingsDetails.getRetryIntervalMinutes());
                    existingSettings.setAutoInvoice(paymentSettingsDetails.isAutoInvoice());
                    existingSettings.setAllowedPaymentTypes(paymentSettingsDetails.getAllowedPaymentTypes());
                    existingSettings.setMinimumPaymentAmount(paymentSettingsDetails.getMinimumPaymentAmount());

                    return paymentSettingsRepository.save(existingSettings);
                })
                .orElseThrow(() -> new IllegalArgumentException("Payment settings not found with id: " + id));
    }

    @Override
    @Transactional
    public void deletePaymentSettings(UUID id) {
        paymentSettingsRepository.deleteById(id);
    }

    @Override
    @Transactional
    public PaymentSettings getOrCreatePaymentSettings(Account account) {
        return paymentSettingsRepository.findByAccount(account)
                .orElseGet(() -> {
                    PaymentSettings newSettings = new PaymentSettings(account);
                    return paymentSettingsRepository.save(newSettings);
                });
    }

    @Override
    public PaymentSettings addAllowedPaymentType(UUID id, PaymentType type) {
        PaymentSettings settings = paymentSettingsRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Payment settings not found with id: " + id));

        settings.addAllowedPaymentType(type);
        return paymentSettingsRepository.save(settings);
    }

    @Override
    @Transactional
    public PaymentSettings removeAllowedPaymentType(UUID id, PaymentType type) {
        PaymentSettings settings = paymentSettingsRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Payment settings not found with id: " + id));

        settings.removeAllowedPaymentType(type);
        return paymentSettingsRepository.save(settings);
    }

    @Override
    public boolean isPaymentTypeAllowed(UUID id, PaymentType type) {
        PaymentSettings settings = paymentSettingsRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Payment settings not found with id: " + id));

        return settings.isPaymentTypeAllowed(type);
    }

    @Override
    public AutomaticPaymentSettingsDTO getAutomaticPaymentSettings(UUID accountId) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new IllegalArgumentException("Account not found with ID: " + accountId));

        PaymentSettings settings = paymentSettingsRepository.findByAccount(account)
                .orElseGet(() -> this.createDefaultSettings(account));

        return this.mapToDTO(settings);
    }

    @Override
    public AutomaticPaymentSettingsDTO updateAutomaticPaymentSettings(UUID accountId, AutomaticPaymentSettingsDTO dto) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new IllegalArgumentException("Account not found with ID: " + accountId));

        PaymentSettings settings = paymentSettingsRepository.findByAccount(account)
                .orElseGet(() -> createDefaultSettings(account));

        // Update settings from DTO
        settings.setRetryFailedPayments(dto.isRetryFailedPayments());
        settings.setRetryAttempts(dto.getRetryAttempts());
        settings.setChargeForRetry(dto.isChargeForRetry());
        settings.setRetryChargeAmount(dto.getRetryChargeAmount());
        settings.setDoNotRetry(dto.isDoNotRetry());
        settings.setNonRetryReasons(dto.getNonRetryReasons());
        settings.setAutoChargeNegativeBalance(dto.isAutoChargeNegativeBalance());
        settings.setAutoChargeDay(dto.getAutoChargeDay());
        settings.setAutoChargeFrequency(dto.getAutoChargeFrequency());
        settings.setCombineClientPayments(dto.isCombineClientPayments());

        PaymentSettings savedSettings = paymentSettingsRepository.save(settings);

        // If settings change, update or create workflows in PAT if needed
        if (dto.isRetryFailedPayments() || dto.isAutoChargeNegativeBalance()) {
            patIntegrationService.createPaymentRetryWorkflow(accountId, savedSettings);
        }

        return this.mapToDTO(savedSettings);
    }

    /**
     * Scheduled job to process payment retries
     * Runs daily at 2 AM
     */
    @Scheduled(cron = "0 0 2 * * ?")
    public void schedulePaymentRetries() {
        int retryCount = this.processAutomaticPaymentRetries();
        log.info("Scheduled payment retry job completed. Process {} payment retries.", retryCount);
    }

    /**
     * Scheduled job to process negative balance charges
     * Runs daily at 3 AM
     */
    @Scheduled(cron = "0 0 3 * * ?")
    public void scheduledNegativeBalanceCharges() {
        String today = LocalDate.now().getDayOfWeek()
                .getDisplayName(TextStyle.FULL, Locale.CANADA);
        int chargeCount = this.processNegativeBalanceCharges(today);
        log.info("Scheduled negative balance charge job completed. Process {} accounts.", chargeCount);
    }

    @Override
    public int processAutomaticPaymentRetries() {
        // Find payments that need retry
        List<Payment> failedPayments = paymentRepository.findByStatus(PaymentStatus.FAILED);
        int retryCount = 0;

        for (Payment payment : failedPayments) {
            Account customer = payment.getCustomer();
            PaymentSettings settings = paymentSettingsRepository.findByAccount(customer)
                    .orElseGet(() -> this.createDefaultSettings(customer));

            // Check if retry is enabled and within retry attempts
            if (settings.isRetryFailedPayments()
                    && !settings.isDoNotRetry()
                    && this.getRetryCount(payment) < settings.getRetryAttempts()) {

                // Check if reason is in non-retry list
                if (!isNonRetryReason(payment, settings)) {
                    // Trigger workflow via PAT
                    patIntegrationService.triggerPaymentRetryWorkflow(payment.getId(), payment);
                    retryCount++;
                }
            }
        }

        return retryCount;
    }

    @Override
    public int processNegativeBalanceCharges(String dayOfWeek) {
        // Find accounts with negative balances
        List<Account> accountsWithNegativeBalance = accountService.findAccountsWithNegativeBalance();
        int chargeCount = 0;

        for (Account account : accountsWithNegativeBalance) {
            PaymentSettings settings = paymentSettingsRepository.findByAccount(account)
                    .orElseGet(() -> this.createDefaultSettings(account));

            // Check if auto-charge is enabled and scheduled for today
            if (settings.isAutoChargeNegativeBalance() &&
                    (settings.getAutoChargeDay().equalsIgnoreCase(dayOfWeek)
                    || settings.getAutoChargeFrequency().equalsIgnoreCase("every"))) {

                // Get balance amount (negative)
                BigDecimal balanceAmount = accountRepository.getAccountBalance(account.getId());

                // Trigger workflow via PAT
                patIntegrationService.triggerNegativeBalanceChargeWorkflow(account.getId(), balanceAmount);
                chargeCount++;
            }
        }

        return chargeCount;
    }

    private int getRetryCount(Payment payment) {
        // Logic to determine how many times a payment has been retried
        return payment.getTransactions().size() - 1; // Subtract initial transaction
    }

    private boolean isNonRetryReason(Payment payment, PaymentSettings settings) {
        if (settings.getNonRetryReasons() == null || settings.getNonRetryReasons().isEmpty()) {
            return false;
        }

        // Check if any transaction has a reason to non-retry list
        String nonRetryReasons = settings.getNonRetryReasons().toLowerCase();

        return payment.getTransactions().stream()
                .filter(t -> t.getStatus() == TransactionStatus.ERROR || t.getStatus() == TransactionStatus.DECLINED)
                .anyMatch(t -> {
                    if (t.getMessage() == null) return false;
                    String message = t.getMessage().toLowerCase();
                    return nonRetryReasons.contains(message) ||
                            message.contains("insufficient funds") && nonRetryReasons.contains("insufficient funds") ||
                            message.contains("expired") && nonRetryReasons.contains("expired") ||
                            message.contains("no such issuer") && nonRetryReasons.contains("no such issuer");
                });
    }

    private PaymentSettings createDefaultSettings(Account account) {
        PaymentSettings settings = new PaymentSettings(account);
        return paymentSettingsRepository.save(settings);
    }

    private AutomaticPaymentSettingsDTO mapToDTO(PaymentSettings settings) {
        AutomaticPaymentSettingsDTO dto = new AutomaticPaymentSettingsDTO();
        dto.setRetryFailedPayments(settings.isRetryFailedPayments());
        dto.setRetryAttempts(settings.getRetryAttempts());
        dto.setChargeForRetry(settings.isChargeForRetry());
        dto.setRetryChargeAmount(settings.getRetryChargeAmount());
        dto.setDoNotRetry(settings.isDoNotRetry());
        dto.setNonRetryReasons(settings.getNonRetryReasons());
        dto.setAutoChargeNegativeBalance(settings.isAutoChargeNegativeBalance());
        dto.setAutoChargeDay(settings.getAutoChargeDay());
        dto.setAutoChargeFrequency(settings.getAutoChargeFrequency());
        dto.setCombineClientPayments(settings.isCombineClientPayments());
        return dto;
    }
}
