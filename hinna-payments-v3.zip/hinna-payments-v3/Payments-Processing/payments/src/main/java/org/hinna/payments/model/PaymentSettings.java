package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;
import org.hinna.payments.model.enums.PaymentType;

import java.math.BigDecimal;
import java.util.UUID;

@Entity
@Table(name = "payment_settings")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = "account")
@EqualsAndHashCode(of = "id")
public class PaymentSettings {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @OneToOne
    @JoinColumn(name = "account_id")
    private Account account;

    @Column(name = "retry_attempts")
    private Integer retryAttempts = 3;

    @Column(name = "retry_interval_minutes")
    private Integer retryIntervalMinutes = 60;

    @Column(name = "auto_invoice")
    private boolean autoInvoice = false;

    @Column(name = "allowed_payment_types")
    private String allowedPaymentTypes = "CREDIT_CARD,BANK_TRANSFER";

    @Column(name = "minimum_payment_amount", precision = 19, scale = 4)
    private BigDecimal minimumPaymentAmount = new BigDecimal("5.00");

    // New fields for automatic payments
    @Column(name = "retry_failed_payments")
    private boolean retryFailedPayments = true;

    @Column(name = "charge_for_retry")
    private boolean chargeForRetry = false;

    @Column(name = "retry_charge_amount", precision = 19, scale = 4)
    private BigDecimal retryChargeAmount = new BigDecimal("0.00");

    @Column(name = "do_not_retry")
    private boolean doNotRetry = false;

    @Column(name = "non_retry_reasons", columnDefinition = "TEXT")
    private String nonRetryReasons = "Insufficient funds, Credit card is expired, No such issuer";

    @Column(name = "auto_charge_negative_balance")
    private boolean autoChargeNegativeBalance = false;

    @Column(name = "auto_charge_day")
    private String autoChargeDay = "Thursday";

    @Column(name = "auto_charge_frequency")
    private String autoChargeFrequency = "every";

    @Column(name = "combine_client_payments")
    private boolean combineClientPayments = false;

    public PaymentSettings(Account account) {
        this.account = account;
    }

    public boolean isPaymentTypeAllowed(PaymentType type) {
        if (allowedPaymentTypes == null) {
            return false;
        }
        return allowedPaymentTypes.contains(type.name());
    }

    public void addAllowedPaymentType(PaymentType type) {
        if (allowedPaymentTypes == null) {
            allowedPaymentTypes = type.name();
        } else if (!allowedPaymentTypes.contains(type.name())) {
            allowedPaymentTypes += "," + type.name();
        }
    }

    public void removeAllowedPaymentType(PaymentType type) {
        if (allowedPaymentTypes != null) {
            allowedPaymentTypes = allowedPaymentTypes
                    .replace(type.name() + ",", "")
                    .replace("," + type.name(), "")
                    .replace(type.name(), "");
        }
    }
}
