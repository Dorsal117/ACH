package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

@Entity
@Table(name = "database_table")
@Getter
@Setter
@NoArgsConstructor
@ToString
@EqualsAndHashCode(of = "id")
public class DatabaseTable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "table_name", nullable = false, unique = true)
    private String tableName;

    private String description;

    @Column(name = "schema_name")
    private String schemaName;

    public DatabaseTable(String tableName, String schemaName) {
        this.tableName = tableName;
        this.schemaName = schemaName;
    }
}
