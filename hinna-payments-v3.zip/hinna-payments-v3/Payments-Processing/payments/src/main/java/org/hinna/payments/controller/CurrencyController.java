package org.hinna.payments.controller;

import java.util.List;
import java.util.UUID;

import org.hinna.payments.model.Currency;
import org.hinna.payments.service.CurrencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/currency")
public class CurrencyController {

    private final CurrencyService currencyService;

    @Autowired
    public CurrencyController(CurrencyService currencyService) {
        this.currencyService = currencyService;
    }

    @PostMapping
    public ResponseEntity<Currency> createCurrency(@RequestBody Currency currency) {
        return ResponseEntity.status(HttpStatus.CREATED).body(currencyService.createCurrency(currency));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Currency> updateCurrency(@PathVariable UUID id,
                                                   @RequestBody Currency updatedCurrency) {
        return ResponseEntity.ok(currencyService.updateCurrency(id, updatedCurrency));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCurrency(@PathVariable UUID id) {
        currencyService.deleteCurrency(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Currency> getCurrency(@PathVariable UUID id) {
        return ResponseEntity.ok(currencyService.getCurrency(id));
    }

    @GetMapping
    public ResponseEntity<List<Currency>> getAllCurrencies() {
        return ResponseEntity.ok(currencyService.getAllCurrencies());
    }

    @GetMapping("/base")
    public ResponseEntity<Currency> getBaseCurrency() {
        return ResponseEntity.ok(currencyService.getBaseCurrency());
    }
}
