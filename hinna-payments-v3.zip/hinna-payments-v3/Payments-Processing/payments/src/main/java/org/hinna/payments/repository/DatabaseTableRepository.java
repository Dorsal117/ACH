package org.hinna.payments.repository;

import org.hinna.payments.model.DatabaseTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface DatabaseTableRepository extends JpaRepository<DatabaseTable, UUID> {
    Optional<DatabaseTable> findByTableName(String tableName);
    boolean existsByTableName(String tableName);
}
