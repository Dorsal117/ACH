package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "billing_history")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = {"account", "payment"})
@EqualsAndHashCode(of = "id")
public class BillingHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "account_id", nullable = false)
    private Account account;

    @Column(name = "transaction_date")
    private LocalDateTime transactionDate;

    @Column(precision = 19, scale = 4, nullable = false)
    private BigDecimal amount;

    private String description;

    @Column(name = "transaction_type", nullable = false)
    private String transactionType;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @ManyToOne
    @JoinColumn(name = "payment_id")
    private Payment payment;

    public BillingHistory(Account account, BigDecimal amount, String transactionType) {
        this.account = account;
        this.amount = amount;
        this.transactionType = transactionType;
        this.transactionDate = LocalDateTime.now();
    }

    @PrePersist
    public void onCreate() {
        this.createdAt = LocalDateTime.now();
        if (this.transactionDate == null) {
            this.transactionDate = LocalDateTime.now();
        }
    }
}
