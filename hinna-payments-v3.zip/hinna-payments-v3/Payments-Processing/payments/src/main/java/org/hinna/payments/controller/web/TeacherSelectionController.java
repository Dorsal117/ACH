package org.hinna.payments.controller.web;

import org.hinna.payments.model.Teacher;
import org.hinna.payments.model.TeacherSelectionForm;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class TeacherSelectionController {

    @GetMapping("/teacher-selection")
    public String showTeacherSelectionForm(Model model) {
        List<Teacher> teachers = List.of(
                new Teacher("1", "Alice Johnson", "Piano", List.of("10:00 AM", "11:00 AM", "12:00 PM")),
                new Teacher("2", "Bob Smith", "Guitar", List.of("1:00 PM", "2:00 PM", "3:00 PM")),
                new Teacher("3", "Carol Lee", "Violin", List.of("4:00 PM", "5:00 PM", "6:00 PM"))
        );
        model.addAttribute("teacherSelectionForm", new TeacherSelectionForm());
        model.addAttribute("teachers", teachers);
        return "TeacherSelection";
    }

    @PostMapping("/teacher-selection/submit")
    public String handleTeacherSelectionSubmit(@ModelAttribute TeacherSelectionForm teacherSelectionForm, RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("selectedTeacherId", teacherSelectionForm.getSelectedTeacherId());
        redirectAttributes.addFlashAttribute("selectedTime", teacherSelectionForm.getSelectedTime());
        return "redirect:/payment/form";
    }
}


