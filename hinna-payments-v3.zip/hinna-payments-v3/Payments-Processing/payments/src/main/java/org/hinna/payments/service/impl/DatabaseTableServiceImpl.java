package org.hinna.payments.service.impl;

import jakarta.transaction.Transactional;
import org.hinna.payments.model.DatabaseTable;
import org.hinna.payments.repository.DatabaseTableRepository;
import org.hinna.payments.service.DatabaseTableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
public class DatabaseTableServiceImpl implements DatabaseTableService {

    private final DatabaseTableRepository databaseTableRepository;

    @Autowired
    public DatabaseTableServiceImpl(DatabaseTableRepository databaseTableRepository) {
        this.databaseTableRepository = databaseTableRepository;
    }

    @Override
    @Transactional
    public DatabaseTable createDatabaseTable(DatabaseTable databaseTable) {
        if (this.existsByTableName(databaseTable.getTableName())) {
            throw new IllegalArgumentException("Database table with name " +
                    databaseTable.getTableName() + " already exists");
        }
        return databaseTableRepository.save(databaseTable);
    }

    @Override
    public Optional<DatabaseTable> getDatabaseTableById(UUID id) {
        return databaseTableRepository.findById(id);
    }

    @Override
    public Optional<DatabaseTable> getDatabaseTableByName(String tableName) {
        return databaseTableRepository.findByTableName(tableName);
    }

    @Override
    public Page<DatabaseTable> getAllDatabaseTables(Pageable pageable) {
        return databaseTableRepository.findAll(pageable);
    }

    @Override
    public DatabaseTable updateDatabaseTable(UUID id, DatabaseTable databaseTableDetails) {
        return databaseTableRepository.findById(id)
                .map(existingTable -> {
                    // Check if name is being changed and is not already in use
                    if (!existingTable.getTableName().equals(databaseTableDetails.getTableName()) &&
                        this.existsByTableName(databaseTableDetails.getTableName())) {
                        throw new IllegalArgumentException("Database table with name " +
                                databaseTableDetails.getTableName() + " already exists");
                    }

                    existingTable.setTableName(databaseTableDetails.getTableName());
                    existingTable.setDescription(databaseTableDetails.getDescription());
                    existingTable.setSchemaName(databaseTableDetails.getSchemaName());

                    return databaseTableRepository.save(existingTable);
                })
                .orElseThrow(() -> new IllegalArgumentException("Database table not found with id: " + id));
    }

    @Override
    public void deleteDatabaseTable(UUID id) {
        databaseTableRepository.deleteById(id);
    }

    @Override
    public boolean existsByTableName(String tableName) {
        return databaseTableRepository.existsByTableName(tableName);
    }
}
