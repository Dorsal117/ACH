package org.hinna.payments.repository;

import org.hinna.payments.model.Account;
import org.hinna.payments.model.Invoice;
import org.hinna.payments.model.enums.InvoiceStatus;
import org.hinna.payments.model.Payment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface InvoiceRepository extends JpaRepository<Invoice, UUID> {
    Optional<Invoice> findByInvoiceNumber(String invoiceNumber);
    List<Invoice> findByCustomer(Account customer);
    List<Invoice> findByStatus(InvoiceStatus status);
    List<Invoice> findByDueDateBefore(LocalDateTime date);
    List<Invoice> findByDueDateBeforeAndStatus(LocalDateTime date, InvoiceStatus status);
    List<Invoice> findByIssueDateBetween(LocalDateTime start, LocalDateTime end);
    Page<Invoice> findByCustomer(Account customer, Pageable pageable);
    List<Invoice> findByCustomerAndStatus(Account customer, InvoiceStatus status);
    Optional<Invoice> findByPayment(Payment payment);
}
