package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Represents a Stripe Payment Intent in our system.
 * This entity tracks Stripe Payment Intent information associated with a Payment.
 */
@Entity
@Table(name = "payment_intent")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString(exclude = "payment")
@EqualsAndHashCode(of = "id")
public class PaymentIntent {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * The Stripe Payment Intent ID (starts with pi_)
     */
    @Column(name = "stripe_intent_id", nullable = false, unique = true)
    private String stripeIntentId;

    /**
     * THe Stripe Payment Intent client secret
     * This is used by frontend to complete the payment
     */
    @Column(name = "client_secret", nullable = false)
    private String clientSecret;

    /**
     * The amount of the payment intent in the system's currency
     */
    @Column(name = "amount", precision = 19, scale = 4, nullable = false)
    private BigDecimal amount;

    /**
     * The currency code (e.g., "usd")
     */
    @Column(name = "currency", nullable = false)
    private String currency;

    /**
     * Current status of the payment intent from Stripe
     */
    @Column(name = "status")
    private String status;

    /**
     * Whether the payment intent has been captured
     */
    @Column(name = "captured")
    private Boolean captured = false;

    /**
     * Error message if payment failed
     */
    @Column(name = "error_message")
    private String errorMessage;

    /**
     * The payment method ID used for this payment intent
     */
    @Column(name = "payment_method_id")
    private String paymentMethodId;

    /**
     * The payment this intent is associated with
     */
    @OneToOne
    @JoinColumn(name = "payment_id")
    private Payment payment;

    /**
     * When this payment intent was created
     */
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    /**
     * When this payment intent was last updated
     */
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Check if the payment intent requires customer action
     * (like 3D Secure authentication)
     */
    @Transient
    public boolean requiresAction() {
        return "requires_action".equals(status) || "requires_source_action".equals(status);
    }

    /**
     * Check if the payment intent requires capture
     */
    @Transient
    public boolean requiresCapture() {
        return "requires_capture".equals(status);
    }

    /**
     * Check if the payment intent was successful
     */
    @Transient
    public boolean isSucceeded() {
        return "succeeded".equals(status);
    }

    /**
     * Check if the payment intent was canceled
     */
    @Transient
    public boolean isCanceled() {
        return "canceled".equals(status);
    }
}
