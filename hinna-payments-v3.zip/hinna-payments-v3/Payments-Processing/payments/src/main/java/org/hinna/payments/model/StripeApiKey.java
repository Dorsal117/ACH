package org.hinna.payments.model;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import java.util.UUID;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class StripeApiKey {
    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "encrypted_key", nullable = false)
    private String encryptedKey;

    @Column(name = "key_alias", nullable = false, unique = true)
    private String keyAlias;

    public StripeApiKey(String keyAlias, String encryptedKey) {
        this.keyAlias = keyAlias;
        this.encryptedKey = encryptedKey;
    }
}
