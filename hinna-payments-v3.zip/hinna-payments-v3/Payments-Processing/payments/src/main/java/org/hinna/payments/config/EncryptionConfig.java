package org.hinna.payments.config;

import org.hinna.payments.security.EncryptionUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration for encryption utilities
 */
@Configuration
public class EncryptionConfig {

    @Value("${encryption.key}")
    private String encryptionKey;

    /**
     * Creates and configures the EncryptionUtil bean
     *
     * @return The configured EncryptionUtil
     */
    @Bean
    public EncryptionUtil encryptionUtil() {
        return new EncryptionUtil(encryptionKey);
    }
}
