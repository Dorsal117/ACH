package org.hinna.payments.controller;

import org.hinna.payments.model.Account;
import org.hinna.payments.model.Payment;
import org.hinna.payments.repository.AccountRepository;
import org.hinna.payments.repository.StripeCustomerRepository;
import org.hinna.payments.service.PaymentService;
import org.hinna.payments.service.StripeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.UUID;

@RestController
@RequestMapping("/api/test/stripe")
public class StripeTestController {

    private final StripeService stripeService;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private StripeCustomerRepository stripeCustomerRepository;

    @Autowired
    public StripeTestController(StripeService stripeService) {
        this.stripeService = stripeService;
    }

    //    This original code created a mock account without saving to DB
    //     public StripeTestController(StripeService stripeService) {
    //        this.stripeService = stripeService;
    //    }

    @PostMapping("/intent")
    public ResponseEntity<String> createPaymentIntent(@RequestBody PaymentRequest request) {
        //  Create a mock account without saving in DB (else foreign key violations in StripeCustomer insert),
        //  then clean up later.
        Account tempAccount = new Account();
        tempAccount.setFirstName("Test");
        tempAccount.setLastName("User");
        String uniqueEmail = request.getEmail().split("@")[0] + "+" + UUID.randomUUID().toString().substring(0, 6) + "@example.com";
        tempAccount.setEmail(uniqueEmail);
        tempAccount.setMobilePhone("1234567890");

        try {
            // Save the temporary test account
            tempAccount = accountRepository.save(tempAccount);
            System.out.println("Account saved: " + tempAccount.getId());

            // Create and save the payment (so getId() works)
            Payment payment = new Payment(tempAccount, request.getAmount(), null);
            payment.setDescription("Test payment from browser or Postman");
            payment = paymentService.createPayment(payment); // save the payment before passing to Stripe

            // Create the PaymentIntent via Stripe
            String clientSecret = stripeService.createPaymentIntent(payment);
            System.out.println("Stripe client secret created");

            return ResponseEntity.ok(clientSecret);
        } catch (Exception e) {
            e.printStackTrace(); // Log the full stack trace
            return ResponseEntity.status(500).body("Stripe error: " + e.getMessage());
        }
    }

    public static class PaymentRequest {
        private BigDecimal amount;
        private String name;
        private String email;

        // Getters and setters
        public BigDecimal getAmount() { return amount; }
        public void setAmount(BigDecimal amount) { this.amount = amount; }

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }

        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
    }
}

