package org.hinna.payments.service.impl;

import jakarta.transaction.Transactional;
import org.hinna.payments.model.*;
import org.hinna.payments.model.enums.InvoiceStatus;
import org.hinna.payments.model.enums.PaymentStatus;
import org.hinna.payments.repository.InvoiceItemRepository;
import org.hinna.payments.repository.InvoiceRepository;
import org.hinna.payments.repository.PaymentRepository;
import org.hinna.payments.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class InvoiceServiceImpl implements InvoiceService {

    private final InvoiceRepository invoiceRepository;
    private final InvoiceItemRepository invoiceItemRepository;
    private final PaymentRepository paymentRepository;

    @Autowired
    public InvoiceServiceImpl(InvoiceRepository invoiceRepository, InvoiceItemRepository invoiceItemRepository, PaymentRepository paymentRepository) {
        this.invoiceRepository = invoiceRepository;
        this.invoiceItemRepository = invoiceItemRepository;
        this.paymentRepository = paymentRepository;
    }

    @Override
    @Transactional
    public Invoice createInvoice(Invoice invoice) {
        // Recalculate totals to ensure accuracy
        invoice.recalculateTotals();
        return invoiceRepository.save(invoice);
    }

    @Override
    public Optional<Invoice> getInvoiceById(UUID id) {
        return invoiceRepository.findById(id);
    }

    @Override
    public Optional<Invoice> getInvoiceByNumber(String invoiceNumber) {
        return invoiceRepository.findByInvoiceNumber(invoiceNumber);
    }

    @Override
    public Page<Invoice> getAllInvoices(Pageable pageable) {
        return invoiceRepository.findAll(pageable);
    }

    @Override
    @Transactional
    public Invoice updateInvoice(UUID id, Invoice invoiceDetails) {
        return invoiceRepository.findById(id)
                .map(existingInvoice -> {
                    // Only update fields that should be editable when invoice is in DRAFT state
                    if (existingInvoice.getStatus() != InvoiceStatus.DRAFT) {
                        throw new IllegalStateException("Can only update invoices in DRAFT state");
                    }

                    existingInvoice.setDueDate(invoiceDetails.getDueDate());
                    existingInvoice.setNotes(invoiceDetails.getNotes());

                    // Don't replace items directly, use addItem and removeItem methods
                    existingInvoice.recalculateTotals();
                    return invoiceRepository.save(existingInvoice);
                })
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found with id: " + id));
    }

    @Override
    @Transactional
    public void deleteInvoice(UUID id) {
        Invoice invoice = invoiceRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found with id: " + id));

        if (invoice.getStatus() != InvoiceStatus.DRAFT && invoice.getStatus() != InvoiceStatus.CANCELLED) {
            throw new IllegalStateException("Can only delete invoices in DRAFT or CANCELLED state");
        }

        invoiceRepository.deleteById(id);
    }

    @Override
    @Transactional
    public Invoice addItemToInvoice(UUID invoiceId, InvoiceItem itemId) {
        Invoice invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found with id: " + itemId));

        if (invoice.getStatus() != InvoiceStatus.DRAFT) {
            throw new IllegalStateException("Can only add items to invoices in DRAFT state");
        }

        invoice.addItem(itemId);
        return invoiceRepository.save(invoice);
    }

    @Override
    @Transactional
    public Invoice removeItemFromInvoice(UUID invoiceId, UUID itemId) {
        Invoice invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found with id: " + invoiceId));

        if (invoice.getStatus() != InvoiceStatus.DRAFT) {
            throw new IllegalStateException("Can only add items to invoices in DRAFT state");
        }

        InvoiceItem itemToRemove = invoice.getItems().stream()
                .filter(item -> item.getId().equals(itemId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Item with id " + itemId + " not found in invoice"));

        invoice.removeItem(itemToRemove);
        invoiceItemRepository.delete(itemToRemove);

        return invoiceRepository.save(invoice);
    }

    @Override
    @Transactional
    public Invoice issueInvoice(UUID id) {
        Invoice invoice = invoiceRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found with id: " + id));

        invoice.issue();
        return invoiceRepository.save(invoice);
    }

    @Override
    @Transactional
    public Invoice markAsPaid(UUID invoiceId, UUID paymentId) {
        Invoice invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found with id: " + invoiceId));

        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new IllegalArgumentException("Payment not found with id: " + paymentId));

        // Validate payment status
        if (payment.getStatus() != PaymentStatus.COMPLETED) {
            throw new IllegalStateException("Cannot mark invoice as paid with incomplete payment");
        }

        // Validate payment amount matches invoice total
        if (payment.getAmount().compareTo(invoice.getTotalAmount()) != 0) {
            throw new IllegalStateException("Payment amount doesn't match invoice total");
        }

        invoice.markAsPaid(payment);
        return invoiceRepository.save(invoice);
    }

    @Override
    @Transactional
    public Invoice cancelInvoice(UUID id) {
        Invoice invoice = invoiceRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found with id: " + id));

        invoice.cancel();
        return invoiceRepository.save(invoice);
    }

    @Override
    public List<Invoice> getInvoicesByCustomer(Account customer) {
        return invoiceRepository.findByCustomer(customer);
    }

    @Override
    public Page<Invoice> getInvoicesByCustomer(Account customer, Pageable pageable) {
        return invoiceRepository.findByCustomer(customer, pageable);
    }

    @Override
    public List<Invoice> getInvoiceByStatus(InvoiceStatus status) {
        return invoiceRepository.findByStatus(status);
    }

    @Override
    public List<Invoice> getOverdueInvoices() {
        return invoiceRepository.findByDueDateBeforeAndStatus(
                LocalDateTime.now(), InvoiceStatus.ISSUED
        );
    }

    @Override
    public List<Invoice> getInvoicesWithinDateRange(LocalDateTime start, LocalDateTime end) {
        return invoiceRepository.findByIssueDateBetween(start, end);
    }

    @Override
    public List<Invoice> getInvoicesByCustomerAndStatus(Account customer, InvoiceStatus status) {
        return invoiceRepository.findByCustomerAndStatus(customer, status);
    }

    @Override
    public List<Invoice> markOverdueInvoices() {
        List<Invoice> overdueInvoices = invoiceRepository.findByDueDateBeforeAndStatus(
                LocalDateTime.now(), InvoiceStatus.ISSUED);

        for (Invoice invoice : overdueInvoices) {
            invoice.markAsOverdue();
        }

        return invoiceRepository.saveAll(overdueInvoices);
    }

    @Override
    public BigDecimal getTotalOutstandingAmount(Account customer) {
        List<Invoice> outstandingInvoices = invoiceRepository.findByCustomerAndStatus(customer, InvoiceStatus.ISSUED);
        outstandingInvoices.addAll(invoiceRepository.findByCustomerAndStatus(customer, InvoiceStatus.OVERDUE));

        return outstandingInvoices.stream()
                .map(Invoice::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    @Override
    public BigDecimal getTotalPaidAmount(Account customer, LocalDateTime start, LocalDateTime end) {
        List<Invoice> paidInvoices = invoiceRepository.findByCustomerAndStatus(customer, InvoiceStatus.PAID);

        return paidInvoices.stream()
                .filter(invoice -> {
                    LocalDateTime paidAt = invoice.getPaidAt();
                    return paidAt != null && !paidAt.isBefore(start) && !paidAt.isAfter(end);
                })
                .map(Invoice::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
