package org.hinna.payments.service;

import org.hinna.payments.model.Account;
import org.hinna.payments.model.Admin;
import org.hinna.payments.model.AdminGroup;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface AdminService {
    Admin createAdmin(Admin admin);
    Optional<Admin> getAdminById(UUID id);
    Optional<Admin> getAdminByAccount(Account account);
    Page<Admin> getAllAdmins(Pageable pageable);
    List<Admin> getAdminsByType(String adminType);
    List<Admin> getAdminsByGroup(AdminGroup adminGroup);
    Admin updateAdmin(UUID id, Admin adminDetails);
    void deleteAdmin(UUID id);
    Admin assignToGroup(UUID adminId, UUID groupId);
    boolean hasPermission(UUID adminId, String permissionName);
    Admin addAccessToTable(UUID adminId, UUID tableId, String accessLevel);
    Admin removeAccessToTable(UUID adminId, UUID tableId);
    boolean canAccessTable(UUID adminId, String tableName);
}
