package org.hinna.payments.service.impl;

import com.stripe.exception.StripeException;
import com.stripe.param.PaymentIntentCancelParams;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.exception.PaymentProcessingException;
import org.hinna.payments.model.*;
import org.hinna.payments.model.enums.PaymentStatus;
import org.hinna.payments.model.enums.TransactionStatus;
import org.hinna.payments.repository.PaymentIntentRepository;
import org.hinna.payments.repository.PaymentRepository;
import org.hinna.payments.repository.PaymentTransactionRepository;
import org.hinna.payments.service.PaymentIntentService;
import org.hinna.payments.service.StripeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class PaymentIntentServiceImpl implements PaymentIntentService {

    private final PaymentIntentRepository paymentIntentRepository;
    private final StripeService stripeService;
    private final PaymentRepository paymentRepository;
    private final PaymentTransactionRepository paymentTransactionRepository;

    @Value("${stripe.currency:cad}")
    private String defaultCurrency;

    @Autowired
    public PaymentIntentServiceImpl(PaymentIntentRepository paymentIntentRepository,
                                    StripeService stripeService,
                                    PaymentRepository paymentRepository,
                                    PaymentTransactionRepository paymentTransactionRepository) {
        this.paymentIntentRepository = paymentIntentRepository;
        this.stripeService = stripeService;
        this.paymentRepository = paymentRepository;
        this.paymentTransactionRepository = paymentTransactionRepository;
    }

    @Override
    @Transactional
    public PaymentIntent createPaymentIntent(Payment payment) {
        log.info("Creating payment intent for payment: {}", payment.getId());

        // Check if payment already has an intent
        Optional<PaymentIntent> existingIntent = paymentIntentRepository.findByPayment(payment);
        if (existingIntent.isPresent()) {
            log.info("Payment already has an intent: {}", existingIntent.get().getStripeIntentId());
            return existingIntent.get();
        }

        try {
            // Create a payment intent in Stripe
            String clientSecret = stripeService.createPaymentIntent(payment);

            // Create a payment intent in our system
            PaymentIntent paymentIntent = PaymentIntent.builder()
                    .stripeIntentId(payment.getReferenceNumber()) // Set from payment's reference which was updated in Stripe service
                    .clientSecret(clientSecret)
                    .amount(payment.getAmount())
                    .currency(defaultCurrency)
                    .status("requires_payment_method") // Initial status
                    .build();

            return paymentIntentRepository.save(paymentIntent);
        } catch (Exception e) {
            log.error("Failed to create payment intent for payment {}: {}", payment.getId(), e.getMessage());
            throw new PaymentProcessingException("Failed to create payment intent: " + e.getMessage());
        }
    }

    @Override
    public Optional<PaymentIntent> getPaymentIntentById(UUID id) {
        return paymentIntentRepository.findById(id);
    }

    @Override
    public Optional<PaymentIntent> getPaymentIntentByStripeId(String stripeIntentId) {
        return paymentIntentRepository.findByStripeIntentId(stripeIntentId);
    }

    @Override
    @Transactional
    public PaymentIntent updatePaymentIntentStatus(String stripeIntentId, String status, String errorMessage) {
        log.info("Updating payment intent status: {} -> {}", stripeIntentId, status);

        PaymentIntent paymentIntent = paymentIntentRepository.findByStripeIntentId(stripeIntentId)
                .orElseThrow(() -> new IllegalArgumentException("Payment intent not found: " + stripeIntentId));

        paymentIntent.setStatus(status);

        if (errorMessage != null) {
            paymentIntent.setErrorMessage(errorMessage);
        }

        if ("succeeded".equals(status)) {
            paymentIntent.setCaptured(true);
        }

        return paymentIntentRepository.save(paymentIntent);
    }

    @Override
    @Transactional
    public boolean confirmPaymentIntent(String stripeIntentId) {
        log.info("Confirming payment intent: {}", stripeIntentId);

        try {
            // Retrieve the current intent from Stripe
            com.stripe.model.PaymentIntent stripeIntent = com.stripe.model.PaymentIntent.retrieve(stripeIntentId);
            String initialStatus = stripeIntent.getStatus();

            log.info("Initial Stripe payment intent status: {}", initialStatus);

            // Confirm the payment intent with Stripe if it's in confirmable state
            if ("requires_confirmation".equals(initialStatus)) {
                stripeIntent = stripeIntent.confirm();
            } else if ("requires_payment_method".equals(initialStatus)) {
                log.warn("Payment intent requires a payment method before confirmation: {}", stripeIntentId);
                updatePaymentIntentStatus(stripeIntentId, initialStatus, "Payment method required before confirmation");
                return false;
            } else if ("requires_action".equals(initialStatus) || "requires_source_action".equals(initialStatus)) {
                log.warn("Payment intent requires customer action: {}", stripeIntentId);
                updatePaymentIntentStatus(stripeIntentId, initialStatus, "Customer action required to complete authentication");
                return false;
            }

            // Get the updated status after confirmation
            String finalStatus = stripeIntent.getStatus();
            log.info("Payment intent status after confirmation attempt: {}", finalStatus);

            // Update our database with the exact current status from Stripe
            this.updatePaymentIntentStatus(
                    stripeIntentId,
                    finalStatus,
                    this.getMessageForStatus(finalStatus, stripeIntent)
            );

            // Check if confirmation was successful
            boolean requiresCapture = "requires_capture".equals(finalStatus);
            boolean succeeded = "succeeded".equals(finalStatus);
            boolean processing = "processing".equals(finalStatus);

            // Return true if payment is complete or just needs capture
            return succeeded || requiresCapture || processing;

        } catch (StripeException e) {
            log.error("Error confirming payment intent {}: {}", stripeIntentId, e.getMessage());
            // Update status with error message
            updatePaymentIntentStatus(stripeIntentId, "failed", "Confirmation failed: " + e.getMessage());
            throw new PaymentProcessingException("Failed to confirm payment intent: " + e.getMessage(), e);
        }
    }

    @Override
    @Transactional
    public boolean capturePaymentIntent(String stripeIntentId) {
        log.info("Capturing payment intent: {}", stripeIntentId);

        try {
            // Retrieve the current intent from database
            PaymentIntent localIntent = this.getPaymentIntentByStripeId(stripeIntentId)
                    .orElseThrow(() -> new IllegalArgumentException("Payment intent not found: " + stripeIntentId));

            // Retrieve the current intent from Stripe
            com.stripe.model.PaymentIntent stripeIntent = com.stripe.model.PaymentIntent.retrieve(stripeIntentId);

            // Check the intent's state
            if (!"requires_capture".equals(stripeIntent.getStatus())) {
                log.warn("Payment intent is not in a capturable state. Current status: {}", stripeIntent.getStatus());
                updatePaymentIntentStatus(stripeIntentId, stripeIntent.getStatus(),
                        "Cannot capture payment in " + stripeIntent.getStatus() + " state");
                return false;
            }

            // Attempt to capture the payment intent
            stripeIntent = stripeIntent.capture();

            // Update our database with the current status
            String finalStatus = stripeIntent.getStatus();
            boolean success = "succeeded".equals(finalStatus);

            localIntent.setStatus(finalStatus);
            localIntent.setCaptured(success);
            localIntent.setUpdatedAt(LocalDateTime.now());
            paymentIntentRepository.save(localIntent);

            // Also update the payment
            Payment payment = localIntent.getPayment();
            if (success) {
                payment.setStatus(PaymentStatus.COMPLETED);
                payment.setProcessedAt(LocalDateTime.now());
            } else {
                payment.setStatus(PaymentStatus.FAILED);
            }
            paymentRepository.save(payment);

            // Create transaction record
            PaymentTransaction transaction = new PaymentTransaction(
                    payment,
                    success ? TransactionStatus.SUCCESS : TransactionStatus.ERROR,
                    payment.getAmount()
            );
            transaction.setMessage(success ? "Payment captured successfully" : "Payment capture failed");
            transaction.setProviderReference(stripeIntentId);
            paymentTransactionRepository.save(transaction);

            return success;
        } catch (StripeException e) {
            log.error("Error capturing payment intent {}: {}", stripeIntentId, e.getMessage());
            // Update status with error
            updatePaymentIntentStatus(stripeIntentId, "failed", "Capture failed: " + e.getMessage());
            throw new PaymentProcessingException("Failed to capture payment intent: " + e.getMessage(), e);
        }
    }

    @Override
    @Transactional
    public boolean cancelPaymentIntent(String stripeIntentId, String reason) {
        log.info("Cancelling payment intent: {} with reason: {}", stripeIntentId, reason);

        try {
            // Retrieve the payment intent from Stripe
            com.stripe.model.PaymentIntent stripeIntent = com.stripe.model.PaymentIntent.retrieve(stripeIntentId);

            // Check if payment intent can be cancelled
            if ("succeeded".equals(stripeIntent.getStatus()) ||
                    "canceled".equals(stripeIntent.getStatus())) {
                log.warn("Payment intent cannot be canceled. Current status: {}", stripeIntent.getStatus());
                return false;
            }

            // Cancel the payment intent
            PaymentIntentCancelParams.CancellationReason cancellationReason = null;
            if (reason != null && reason.isEmpty()) {
                try {
                    cancellationReason = PaymentIntentCancelParams.CancellationReason.valueOf(reason.toUpperCase());
                } catch (IllegalArgumentException e)  {
                    // If invalid reason, use default
                    cancellationReason = PaymentIntentCancelParams.CancellationReason.REQUESTED_BY_CUSTOMER;
                }
            }

            // Create the parameters for cancellation
            PaymentIntentCancelParams params = cancellationReason != null ? PaymentIntentCancelParams.builder()
                    .setCancellationReason(cancellationReason)
                    .build() : null;

            // Cancel the payment intent
            stripeIntent = params != null ?
                    stripeIntent.cancel(params) :
                    stripeIntent.cancel();

            // Update our database
            String finalStatus = stripeIntent.getStatus();
            boolean success = "cancelled".equals(finalStatus);

            if (success) {
                // Update payment intent in our database
                this.updatePaymentIntentStatus(stripeIntentId, finalStatus, "Payment cancelled:" +
                        (reason != null ? reason : "No reason provided"));

                // Update the payment
                PaymentIntent localIntent = this.getPaymentIntentByStripeId(stripeIntentId)
                        .orElseThrow(() -> new IllegalArgumentException("Payment intent not found: " + stripeIntentId));

                Payment payment = localIntent.getPayment();
                payment.setStatus(PaymentStatus.CANCELLED);
                paymentRepository.save(payment);

                // Create transaction record
                PaymentTransaction transaction = new PaymentTransaction(
                        payment,
                        TransactionStatus.DECLINED,
                        payment.getAmount());
                transaction.setMessage("Payment canceled: " + (reason != null ? reason : "No reason provided"));
                transaction.setProviderReference(stripeIntentId);
                paymentTransactionRepository.save(transaction);
            }

            return success;
        } catch (StripeException e) {
            log.error("Error canceling payment intent {}: {}", stripeIntentId, e.getMessage());
            throw new PaymentProcessingException("Failed to cancel payment intent: " + e.getMessage(), e);
        }
    }

    @Override
    public List<PaymentIntent> getPaymentIntentsByCustomer(Account customer) {
        return List.of();
    }

    /**
     * Helper method to generate appropriate messages for different payment intent statuses
     */
    private String getMessageForStatus(String status, com.stripe.model.PaymentIntent stripeIntent) {
        return switch (status) {
            case "requires_payment_method" -> "Payment requires a payment method";
            case "requires_confirmation" -> "Payment requires confirmation";
            case "requires_action", "requires_source_action" -> "Payment requires customer authentication";
            case "processing" -> "Payment is being processed";
            case "requires_capture" -> "Payment has been authorized and requires capture";
            case "canceled" -> {
                String reason = stripeIntent.getCancellationReason();
                yield "Payment was canceled" + (reason != null ? ": " + reason : "");
            }
            case "succeeded" -> "Payment completed successfully";
            default -> "Payment status: " + status;
        };
    }
}
