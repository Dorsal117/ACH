package org.hinna.payments.service;

import org.hinna.payments.model.AdminGroup;
import org.hinna.payments.model.Permission;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public interface AdminGroupService {
    AdminGroup createAdminGroup(AdminGroup adminGroup);
    Optional<AdminGroup> getAdminGroupById(UUID id);
    Optional<AdminGroup> getAdminGroupByName(String name);
    Page<AdminGroup> getAllAdminGroups(Pageable pageable);
    List<AdminGroup> getActiveAdminGroups();
    List<AdminGroup> getAdminGroupsByType(String groupType);
    AdminGroup updateAdminGroup(UUID id, AdminGroup adminGroupDetails);
    void deleteAdminGroup(UUID id);
    AdminGroup addPermission(UUID groupId, UUID permissionId);
    AdminGroup removePermission(UUID groupId, UUID permissionId);
    Set<Permission> getGroupPermissions(UUID groupId);
    boolean hasPermission(UUID groupId, String permissionName);
}
