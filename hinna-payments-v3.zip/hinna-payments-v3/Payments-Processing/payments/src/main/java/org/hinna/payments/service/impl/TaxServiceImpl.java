package org.hinna.payments.service.impl;

import org.hinna.payments.model.Tax;
import org.hinna.payments.model.LocationTaxRule;
import org.hinna.payments.repository.LocationTaxRuleRepository;
import org.hinna.payments.repository.TaxRepository;
import org.hinna.payments.service.TaxService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;
import java.util.List;

@Service
public class TaxServiceImpl implements TaxService {
    private final TaxRepository taxRepository;
    private final LocationTaxRuleRepository ruleRepository;

    @Autowired
    public TaxServiceImpl(TaxRepository taxRepository, LocationTaxRuleRepository ruleRepository) {
        this.taxRepository = taxRepository;
        this.ruleRepository = ruleRepository;
    }

    @Override
    public Tax createTax(Tax tax) {
        if (tax.getPercentage().compareTo(BigDecimal.ZERO) < 0 ||
            tax.getPercentage().compareTo(BigDecimal.valueOf(100)) > 0) {
            throw new IllegalArgumentException("Tax percentage must be between 0 and 100.");
        }
        return taxRepository.save(tax);
    }

    @Override
    public List<Tax> getApplicableTaxes(UUID locationId, LocalDate date) {
        return ruleRepository.findActiveTaxesByLocationAndDate(locationId, date);
    }

    @Override
    public BigDecimal applyTaxes(BigDecimal amount, UUID locationId, LocalDate date) {
        List<LocationTaxRule> rules = ruleRepository.findActiveRulesByLocationAndDate(locationId, date);
        BigDecimal total = amount;
        
        for (LocationTaxRule rule : rules) {
            BigDecimal taxAmount;

            // Compound tax: apply on cumulative total so far
            if (rule.getTax().isCompound()) {
                taxAmount = total.multiply(rule.getTax().getPercentage()).divide(BigDecimal.valueOf(100));
            } else {
                // Non-compound tax: apply only on base amount
                taxAmount = amount.multiply(rule.getTax().getPercentage()).divide(BigDecimal.valueOf(100));
            }

            total = total.add(taxAmount);
        }
        return total;
    }
}
