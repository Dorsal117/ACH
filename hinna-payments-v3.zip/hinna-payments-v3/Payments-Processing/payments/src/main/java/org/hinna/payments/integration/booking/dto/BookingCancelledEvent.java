package org.hinna.payments.integration.booking.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Event sent when a booking is cancelled and requires refund
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BookingCancelledEvent {
    private UUID bookingId;
    private UUID paymentId;
    private LocalDateTime cancellationTime;
    private String cancellationReason;
    private Boolean refundRequested;
    private Boolean isWithinWithdrawWindow;
}
