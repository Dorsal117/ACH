package org.hinna.payments.service;

import org.hinna.payments.dto.TransactionDTO;
import org.hinna.payments.dto.TransactionGroupDTO;

import java.util.List;
import java.util.UUID;

/**
 * Service interface for transaction-related operations
 */
public interface TransactionService {

    /**
     * Get transactions grouped by month for a specific year
     * @param year The year to get transactions for
     * @param searchTerm Optional search term to filter transactions
     * @return List of transaction groups by month
     */
    List<TransactionGroupDTO> getTransactionsGroupedByMonth(int year, String searchTerm);

    /**
     * Get a specific transaction by ID
     * @param id The transaction ID
     * @return The transaction details
     */
    TransactionDTO getTransactionById(UUID id);
}
