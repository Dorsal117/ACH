package org.hinna.payments.model.enums;

import lombok.Getter;

@Getter
public enum PaymentType {
    CREDIT_CARD("Credit Card"),
    BANK_TRANSFER("Bank Transfer"),
    PAYPAL("PayPal"),
    APPLE_PAY("Apple Pay"),
    GOOGLE_PAY("Google Pay"),
    ACCOUNT_CREDIT("Account Credit");

    private final String displayName;

    PaymentType(String displayName) {
        this.displayName = displayName;
    }

}
