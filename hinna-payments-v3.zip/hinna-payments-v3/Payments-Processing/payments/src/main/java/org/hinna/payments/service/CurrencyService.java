package org.hinna.payments.service;

import org.hinna.payments.model.Currency;
import java.util.UUID;
import java.util.List;

public interface CurrencyService {
    Currency createCurrency(Currency currency);
    Currency updateCurrency(UUID id, Currency updatedCurrency);
    void deleteCurrency(UUID id);
    Currency getCurrency(UUID id);
    List<Currency> getAllCurrencies();
    Currency getBaseCurrency();
}
