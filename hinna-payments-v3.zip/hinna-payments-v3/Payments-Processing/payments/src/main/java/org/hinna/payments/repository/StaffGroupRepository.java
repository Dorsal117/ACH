package org.hinna.payments.repository;

import org.hinna.payments.model.StaffGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface StaffGroupRepository extends JpaRepository<StaffGroup, UUID> {
    Optional<StaffGroup> findByGroupName(String name);
    List<StaffGroup> findByAdminId(UUID adminId);
    List<StaffGroup> findByIsActiveTrue();
}