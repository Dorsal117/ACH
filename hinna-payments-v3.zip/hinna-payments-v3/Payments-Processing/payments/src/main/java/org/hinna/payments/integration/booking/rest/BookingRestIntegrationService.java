package org.hinna.payments.integration.booking.rest;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.integration.booking.dto.CreateServiceRequest;
import org.hinna.payments.integration.booking.dto.PriceRequest;
import org.hinna.payments.model.Account;
import org.hinna.payments.model.Invoice;
import org.hinna.payments.model.InvoiceItem;
import org.hinna.payments.model.Payment;
import org.hinna.payments.service.AccountService;
import org.hinna.payments.service.InvoiceService;
import org.hinna.payments.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Service for integrating with the booking service using REST API
 */
@Service
@Slf4j
public class BookingRestIntegrationService {

    private final RestTemplate restTemplate;
    private final AccountService accountService;
    private final InvoiceService invoiceService;
    private final PaymentService paymentService;

    @Value("${hinna.integration.booking.base-url:http://localhost:8080}")
    private String bookingServiceBaseUrl;

    @Value("${hinna.integration.booking.api-key:}")
    private String bookingServiceApiKey;

    // Mapping for BookingId to InvoiceId
    private final Map<String, UUID> bookingInvoiceMap = new HashMap<>();

    @Autowired
    public BookingRestIntegrationService(RestTemplate restTemplate,
                                         AccountService accountService,
                                         InvoiceService invoiceService,
                                         PaymentService paymentService) {
        this.restTemplate = restTemplate;
        this.accountService = accountService;
        this.invoiceService = invoiceService;
        this.paymentService = paymentService;
    }

    /**
     * Fetch all pending bookings that need payment processing
     */
    @Transactional
    public void fetchAndProcessPendingBookings() {
        log.info("Fetching pending bookings for payment processing");

        try {
            // Create request with headers
            HttpHeaders headers = this.createHeaders();
            HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

            // Make the API call to fetch pending bookings
            // Based on the controllers in the booking service, need to call the appropriate endpoints
            ResponseEntity<CommonResponse<List<CreateServiceRequest>>> response = restTemplate.exchange(
                    bookingServiceBaseUrl + "/booking/service/pending",
                    HttpMethod.GET,
                    requestEntity,
                    new ParameterizedTypeReference<CommonResponse<List<CreateServiceRequest>>>() {}
            );

            // Check if the response is successful and contains data
            if (response.getBody() != null && response.getBody().isSuccess() && response.getBody().getData() != null) {
                List<CreateServiceRequest> pendingBookings = response.getBody().getData();
                for (CreateServiceRequest booking : pendingBookings) {
                    this.processBookingCreated(booking);
                }
            }
        } catch (Exception e) {
            log.error("Error fetching pending bookings", e);
        }
    }

    /**
     * Process a booking creation event
     * @param booking CreateServiceRequest
     */
    @Transactional
    public void processBookingCreated(CreateServiceRequest booking) {
        log.info("Process booking creation for service type: {}", booking.getService_type());

        try {
            // Find the business account
            Optional<Account> accountOpt = accountService.getAccountById(booking.getBusinessId());
            if (accountOpt.isEmpty()) {
                log.error("Cannot find account for business: {}", booking.getBusinessId());
                return;
            }

            Account account = accountOpt.get();

            // Create invoice
            Invoice invoice = this.createInvoiceFromBooking(booking, account);

            // Store the mapping between booking and invoice
            // Note: have to identify what field from the booking service to use as a KEY
            // For now, I concatenate businessId and service_type as a temp solution
            String bookingKey = this.generateBookingKey(booking);
            bookingInvoiceMap.put(bookingKey, invoice.getId());

            // Updating booking status in booking service
            this.updateBookingStatus(bookingKey, "INVOICED", invoice.getId());

            log.info("Created invoice {} for booking with key {}", invoice.getId(), bookingKey);
        } catch (Exception e) {
            log.error("Error processing booking creation", e);
        }
    }

    /**
     * Create an invoice from a booking request
     * @param booking CreateServiceRequest
     * @param account Account
     * @return Invoice
     */
    private Invoice createInvoiceFromBooking(CreateServiceRequest booking, Account account) {
        // Create invoice with appropriate due date
        // For withdrawal start date, if available, use it as the due date
        LocalDateTime dueDate = booking.getWithdrawWindowStartDate() != null
                ? booking.getWithdrawWindowStartDate().toLocalDate().atStartOfDay()
                : LocalDateTime.now().plusDays(7);

        Invoice invoice = new Invoice(account, LocalDateTime.now(), dueDate);

        // Add invoice items based on the pricing information
        if (booking.getPrices() != null && !booking.getPrices().isEmpty()) {
            for (PriceRequest price : booking.getPrices()) {
                // Create invoice item
                String itemDescription = this.generateItemDescription(booking, price);

                // Convert to BigDecimal for invoice item
                BigDecimal priceAmount = BigDecimal.valueOf(price.getAmount());

                // Default tax rate (would be configurable in future implementation)
                BigDecimal taxRate = new BigDecimal("13.00");

                InvoiceItem item = new InvoiceItem(
                        itemDescription,
                        1, // Quantity
                        priceAmount,
                        taxRate
                );

                // Add reference information
                item.setItemType(booking.getService_type());

                // Add to invoice
                invoice.addItem(item);
            }
        } else {
            // If no prices provided, create a generic line item
            InvoiceItem item = new InvoiceItem(
                    "Booking: " + booking.getBusinessId(),
                    1, // Quantity
                    BigDecimal.ZERO, // No price specified
                    new BigDecimal("13.00") // Default tax rate
            );

            item.setItemType(booking.getService_type());

            // Add to invoice
            invoice.addItem(item);
        }

        // Add notes with booking information
        StringBuilder notes = new StringBuilder("Booking Details:\n");
        notes.append("Service Type: ").append(booking.getService_type()).append("\n");
        if (booking.getCategory() != null) {
            notes.append("Category: ").append(booking.getCategory()).append("\n");
        }
        if (booking.getDescription() != null) {
            notes.append("Description: ").append(booking.getDescription()).append("\n");
        }
        if (booking.getLocation() != null) {
            notes.append("Location: ").append(booking.getLocation()).append("\n");
        }
        invoice.setNotes(notes.toString());

        // Save the invoice
        return invoiceService.createInvoice(invoice);
    }

    /**
     * Generate a description for the invoice item
     */
    private String generateItemDescription(CreateServiceRequest booking, PriceRequest price) {
        StringBuilder description = new StringBuilder();

        if (booking.getService_type() != null) {
            description.append(booking.getService_type());
        } else {
            description.append("Service");
        }

        // Add category if available
        if (booking.getCategory() != null) {
            description.append(" - ").append(booking.getCategory());
        }

        // Add class duration if available
        if (price.getClassDuration() != null) {
            description.append(" (").append(price.getClassDuration()).append(" minutes)");
        }

        // Add billing frequency if available
        if (price.getBillingFrequency() != null) {
            description.append(" - ").append(price.getBillingFrequency());
        }

        return description.toString();
    }

    /**
     * Generate a temp key for booking identification
     */
    private String generateBookingKey(CreateServiceRequest booking) {
        // In final implementation, should use the booking's service ID
        return booking.getBusinessId() + "_" +
                booking.getService_type() + "_" +
                (booking.getCategory() != null ? booking.getCategory() : "nocat");
    }

    /**
     * Process a payment for a booking
     */
    @Transactional
    public void processPaymentForBooking(String bookingKey, Payment payment) {
        log.info("Process payment for booking with key: {}", bookingKey);

        try {
            // Update the booking status in booking service
            this.updateBookingStatus(
                    bookingKey,
                    "PAID",
                    payment.getId(),
                    payment.getAmount().doubleValue()
            );

            log.info("Updated booking {} with payment status", bookingKey);
        } catch (Exception e) {
            log.error("Error processing payment for booking", e);
        }
    }

    /**
     * Process a booking cancellation
     */
    @Transactional
    public void processBookingCancelled(String bookingKey, String reason, boolean refundRequested) {
        log.info("Process booking cancellation for key: {}", bookingKey);

        try {
            // Find the invoice for this booking
            UUID invoiceId = bookingInvoiceMap.get(bookingKey);
            if (invoiceId == null) {
                log.error("Cannot find invoice for booking with key: {}", bookingKey);
                return;
            }

            Optional<Invoice> invoiceOpt = invoiceService.getInvoiceById(invoiceId);
            if (invoiceOpt.isEmpty()) {
                log.error("Invoice not found: {}", invoiceId);
                return;
            }

            Invoice invoice = invoiceOpt.get();

            // Find associated payment if any
            if (invoice.getPayment() != null) {
                Payment payment = invoice.getPayment();

                // Process refund if requested
                if (refundRequested) {
                    // Process refund
                    this.processRefundForBooking(bookingKey, payment, reason);
                }
            }

            // Update booking status
            this.updateBookingStatus(bookingKey, "CANCELLED", null);

            log.info("Processed cancellation for booking: {}", bookingKey);
        } catch (Exception e) {
            log.error("Error processing booking cancellation", e);
        }
    }

    /**
     * Process a refund for a booking
     */
    private void processRefundForBooking(String bookingKey, Payment payment, String reason) {
        log.info("Process refund for booking: {}", bookingKey);

        try {
            // Process refund through payment service
            paymentService.refundPayment(
                    payment.getId(),
                    payment.getAmount(),
                    "Booking cancelled: " + reason
            );

            // Update booking status
            this.updateBookingStatus(bookingKey, "REFUNDED", payment.getId());

            log.info("Process refund for booking: {}", bookingKey);
        } catch (Exception e) {
            log.error("Error processing refund", e);
        }
    }

    /**
     * Update booking status in the booking service
     */
    private void updateBookingStatus(String bookingKey, String status, UUID paymentId) {
        this.updateBookingStatus(bookingKey, status, paymentId, null);
    }

    /**
     * Update booking status with amount information
     */
    private void updateBookingStatus(String bookingKey, String status, UUID paymentId, Double amount) {
        log.info("Update booking status: {} -> {}", bookingKey, status);

        try {
            // Create request body
            Map<String, Object> statusUpdate = new HashMap<>();
            statusUpdate.put("status", status);

            if (paymentId != null) {
                statusUpdate.put("paymentId", paymentId.toString());
            }

            if (amount != null) {
                statusUpdate.put("amount", amount);
            }

            // Create request with headers
            HttpHeaders headers = this.createHeaders();
            HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(statusUpdate, headers);

            // Make the API call based on the booking service's controllers
            restTemplate.exchange(
                    bookingServiceBaseUrl + "/booking/service/status/" + bookingKey,
                    HttpMethod.PATCH,
                    requestEntity,
                    CommonResponse.class
            );

            log.info("Successfully updated booking status");
        } catch (Exception e) {
            log.error("Error updating booking status", e);
        }
    }

    /**
     * Create HTTP headers for API requests
     * @return HttpHeaders
     */
    private HttpHeaders createHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");

        if (bookingServiceApiKey != null && !bookingServiceApiKey.isEmpty()) {
            headers.set("X-API-Key", bookingServiceApiKey);
        }

        return headers;
    }

    /**
     * Get the invoice ID for a booking
     */
    public Optional<UUID> getInvoiceIdForBooking(String bookingKey) {
        return Optional.ofNullable(bookingInvoiceMap.get(bookingKey));
    }
}
