package org.hinna.payments.model.enums;

public enum TransactionStatus {
    PENDING,
    INITIATED,
    SUCCESS,
    DECLINED,
    ERROR,
    PROCESSING_ACH,
    RETURNED_ACH

}
