package org.hinna.payments.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.NonNull;
import org.hinna.payments.client.UserServiceClient;
import org.hinna.payments.integration.user.service.AccountSynchronizationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Filter responsible for JWT authentication with the User Service.
 */
@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(JwtAuthFilter.class);
    private static final String TOKEN_COOKIE_NAME = "hinna_auth_token";
    private static final String TOKEN_HEADER = "Authorization";

    private final UserServiceClient userServiceClient;
    private final JwtDecoder jwtDecoder;
    private final AccountSynchronizationService accountSyncService;

    // Local JWT validator - no network calls
    private final LocalJwtValidator localJwtValidator;

    // Toggle between local and remote validation
    @Value("${app.auth.use-local-validation:true}")
    private boolean useLocalValidation;

    @Value("${spring.profiles.active:dev}")
    private String activeProfile;

    @Value("${app.auth.dev-mode-enabled:true}")
    private boolean devModeEnabled;

    @Autowired
    public JwtAuthFilter(
            UserServiceClient userServiceClient,
            JwtDecoder jwtDecoder,
            AccountSynchronizationService accountSyncService,
            LocalJwtValidator localJwtValidator) {
        this.userServiceClient = userServiceClient;
        this.jwtDecoder = jwtDecoder;
        this.accountSyncService = accountSyncService;
        this.localJwtValidator = localJwtValidator;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain filterChain)
            throws ServletException, IOException {

        // Skip authentication for certain paths
        String requestURI = request.getRequestURI();
        if (requestURI.startsWith("/api/public/") ||
                requestURI.startsWith("/api/payments/webhook/") ||
                requestURI.startsWith("/api/health/") ||
                requestURI.startsWith("/api/docs/")) {
            filterChain.doFilter(request, response);
            return;
        }

        // For development mode - bypass authentication and use dummy admin user
        if (isDevMode()) {
            logger.info("DEV MODE: Using dummy admin authentication for request to {}", requestURI);
            setupDevModeAuthentication();
            filterChain.doFilter(request, response);
            return;
        }

        try {
            // Get token from header or cookie
            String token = this.extractTokenFromRequest(request);

            if (token != null) {

                // Choose validation method
                boolean isValid;
                Long userId = 0L;
                String userRole = null;

                if (useLocalValidation) {
                    // Validate locally (no network calls)
                    logger.debug("Using LOCAL JWT validation");
                    isValid = localJwtValidator.validateToken(token);

                    if (isValid) {
                        userId = localJwtValidator.getUserIdFromToken(token);
                        userRole = localJwtValidator.getRoleFromToken(token);
                    } else {
                        userId = null;
                    }
                } else {
                    // Old way: validate with user service (network call)
                    logger.debug("Using REMOTE JWT validation");
                    isValid = userServiceClient.validateToken(token);

                    if (isValid) {
                        // Decode token to get user details
                        userId = jwtDecoder.getUserIdFromToken(token);
                        userRole = jwtDecoder.getRoleFromToken(token);
                    }
                }

                if (isValid && userId != null) {
//                    // Ensure user has a corresponding account in our system
//                    accountSyncService.getOrCreateAccount(userId);

                    // Set authentication in Spring Security context
                    setAuthentication(userId, userRole);

                    logger.debug("Successfully authenticated user: {}", userId);
                }
            }
        } catch (Exception e) {
            logger.error("Authentication error", e);
            // Continue with the filter chain regardless of authentication error
        }

        filterChain.doFilter(request, response);
    }

    private String extractTokenFromRequest(HttpServletRequest request) {
        // First try to get from Authorization header
        String bearerToken = request.getHeader(TOKEN_HEADER);
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }

        // Then try to get from cookie
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            return Arrays.stream(cookies)
                    .filter(cookie -> TOKEN_COOKIE_NAME.equals(cookie.getName()))
                    .map(Cookie::getValue)
                    .findFirst()
                    .orElse(null);
        }

        return null;
    }

    private void setAuthentication(Long userId, String role) {
        List<SimpleGrantedAuthority> authorities = Collections.singletonList(
                new SimpleGrantedAuthority("ROLE_" + role));

        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken(userId, null, authorities);

        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    /**
     * Set up a development mode authentication with admin privileges
     */
    private void setupDevModeAuthentication() {
        Long dummyUserId = 999999L;
        List<SimpleGrantedAuthority> authorities = List.of(
                new SimpleGrantedAuthority("ROLE_ADMIN"),
                new SimpleGrantedAuthority("ROLE_USER")
        );

        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken(dummyUserId, null, authorities);

        SecurityContextHolder.getContext().setAuthentication(authentication);
        logger.debug("DEV MODE: Set dummy admin authentication");
    }

    /**
     * Check if development mode is active
     */
    private boolean isDevMode() {
        return devModeEnabled &&
                ("dev".equals(activeProfile) || "development".equals(activeProfile) || "local".equals(activeProfile));
    }
}