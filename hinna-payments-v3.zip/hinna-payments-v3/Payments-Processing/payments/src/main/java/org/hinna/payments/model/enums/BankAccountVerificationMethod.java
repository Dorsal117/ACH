package org.hinna.payments.model.enums;

public enum BankAccountVerificationMethod {
    MICRO_DEPOSIT,
    FINANCIAL_CONNECTIONS
}