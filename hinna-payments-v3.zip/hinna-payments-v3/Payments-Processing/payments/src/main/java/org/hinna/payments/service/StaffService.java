package org.hinna.payments.service;

import org.hinna.payments.model.DirectCustomer;
import org.hinna.payments.model.Staff;
import org.hinna.payments.model.StaffGroup;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface StaffService {
    Staff createStaff(Staff staff);
    Optional<Staff> getStaffById(UUID id);
    Page<Staff> getAllStaff(Pageable pageable);
    List<Staff> getStaffByEmployer(DirectCustomer employer);
    List<Staff> getStaffByStaffGroup(StaffGroup staffGroup);
    List<Staff> getStaffByDepartment(String department);
    Staff updateStaff(UUID id, Staff staffDetails);
    void deleteStaff(UUID id);
    Staff assignToGroup(UUID staffId, UUID groupId);
    boolean hasPermission(UUID staffId, String permissionName);
    List<Staff> getAdminStaff();
}
