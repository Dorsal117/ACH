package org.hinna.payments.model.enums;

import lombok.Getter;

@Getter
public enum PayrollFrequency {
    WEEKLY("Every week"),
    BI_WEEKLY("Every two weeks"),
    SEMI_MONTHLY("Twice a month"),
    MONTHLY("Once a month");

    private final String displayName;

    PayrollFrequency(String displayName) {
        this.displayName = displayName;
    }

}
