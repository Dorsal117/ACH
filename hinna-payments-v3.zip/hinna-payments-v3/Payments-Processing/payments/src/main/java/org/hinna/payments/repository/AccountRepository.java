package org.hinna.payments.repository;

import org.hinna.payments.model.Account;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface AccountRepository extends JpaRepository<Account, UUID> {

    /**
     * Find an account by its email address
     * @param email Email address to search
     * @return Optional containing the account if found
     */
    Optional<Account> findByEmail(String email);

    /**
     * Find an account by its external user ID from the User Service
     * @param externalUserId The ID of the user in the User Service
     * @return Optional containing the account if found
     */
    Optional<Account> findByExternalUserId(Long externalUserId);

    /**
     * Check if an email is already in use
     * @param email Email to check
     * @return True if the email is already used by an account
     */
    boolean existsByEmail(String email);

    /**
     * Find accounts by active status
     * @return List of active accounts
     */
    List<Account> findByIsActiveTrue();

    /**
     * Search accounts by name or email
     * @param searchTerm Term to search for in first name, last name, or email
     * @return List of matching accounts
     */
    @Query("SELECT a FROM Account a WHERE " +
            "LOWER(a.firstName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
            "LOWER(a.lastName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
            "LOWER(a.email) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
    List<Account> searchByNameOrEmail(@Param("searchTerm") String searchTerm);

    /**
     * Check if an external user ID is already linked to an account
     * @param externalUserId External user ID to check
     * @return True if the external user ID is already linked to an account
     */
    boolean existsByExternalUserId(Long externalUserId);

    List<Account> findByCreatedAtAfter(LocalDateTime date);

    /**
     * Find all accounts by SaaS account
     * @param saasAccountId ID of the SaaS account
     * @param pageable Pagination information
     * @return Page of accounts
     */
    @Query("SELECT a FROM Account a WHERE a.id IN " +
            "(SELECT r.saasAccount.id FROM ResellerAccount r WHERE r.saasAccount.id = :saasAccountId)")
    Page<Account> findAllBySaasAccount(@Param("saasAccountId") UUID saasAccountId, Pageable pageable);

    /**
     * Find all accounts by reseller
     * @param resellerId ID of the reseller
     * @param pageable Pagination information
     * @return Page of accounts
     */
    @Query("SELECT a FROM Account a WHERE a.id IN " +
            "(SELECT c.reseller.id FROM DirectCustomer c WHERE c.reseller.id = :resellerId)")
    Page<Account> findAllByReseller(@Param("resellerId") UUID resellerId, Pageable pageable);

    /**
     * Get the current balance for an account
     * @param accountId The account ID
     * @return The account balance (can be positive or negative)
     */
    @Query("SELECT COALESCE(SUM(b.amount), 0) FROM BillingHistory b WHERE b.account.id = :accountId")
    BigDecimal getAccountBalance(@Param("accountId") UUID accountId);
}
