package org.hinna.payments.controller;

public class PayrollControllerIntegrationTest {
}
