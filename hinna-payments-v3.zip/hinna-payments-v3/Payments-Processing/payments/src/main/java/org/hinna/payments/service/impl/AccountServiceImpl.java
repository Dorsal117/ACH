package org.hinna.payments.service.impl;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.client.UserServiceClient;
import org.hinna.payments.integration.user.dto.AccountCreationRequest;
import org.hinna.payments.integration.user.dto.UserDTO;
import org.hinna.payments.model.*;
import org.hinna.payments.repository.AccountRepository;
import org.hinna.payments.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Implementation of the AccountService interface.
 * Modified to work with the User Service integration.
 */
@Slf4j
@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final UserServiceClient userServiceClient;

    @Autowired
    public AccountServiceImpl(AccountRepository accountRepository, UserServiceClient userServiceClient) {
        this.accountRepository = accountRepository;
        this.userServiceClient = userServiceClient;
    }

    @Override
    @Transactional
    public Account createAccountForExternalUser(AccountCreationRequest request) {
        // Check if account already exists to avoid duplicates
        Optional<Account> existingAccount = accountRepository.findByExternalUserId(request.getUserId());

        if (existingAccount.isPresent()) {
            throw new IllegalArgumentException("Account already exists for user ID: " + request.getUserId());
        }

        // Also check if email is already used
        Optional<Account> accountWithEmail = accountRepository.findByEmail(request.getEmail());
        if (accountWithEmail.isPresent()) {
            throw new IllegalArgumentException("Email already in use: " + request.getEmail());
        }

        // Create appropriate account type based on user role
        Account account;

        switch (request.getRole()) {
            case "BUSINESS" -> {
                DirectCustomer customer = new DirectCustomer();
                customer.setBusinessName(request.getBusinessName());
                customer.setBusinessType("Standard"); // Default type
                customer.setTaxId(request.getTaxId());
                customer.setCredit(BigDecimal.ZERO);
                account = customer;
            }
            case "STAFF" -> {
                Staff staff = new Staff();
                staff.setPosition("Staff");
                staff.setDepartment("General");
                staff.setIsAdmin(false);
                account = staff;
            }
            case "RESELLER" -> {
                ResellerAccount reseller = new ResellerAccount();
                reseller.setCompanyName(request.getCompanyName());
                reseller.setResellerCode(this.generateResellerCode(request.getLastName()));
                reseller.setCommissionRate(new BigDecimal("10.00")); // Default commission rate
                account = reseller;
            }
            case "SAAS" -> {
                SaaSAccount saas = new SaaSAccount();
                saas.setCompanyName(request.getCompanyName());
                saas.setPlanType("Standard"); // Default plan type
                account = saas;
            }
            default -> {
                account = new Account();
            }
        }

        // Set common fields for all account types
        account.setFirstName(request.getFirstName());
        account.setLastName(request.getLastName());
        account.setEmail(request.getEmail());
        account.setAddress(request.getAddress());
        account.setProfilePicturePath(request.getProfilePicturePath());
        account.setExternalUserId(request.getUserId());
        account.setActive(true);

        // Save and return the account
        return accountRepository.save(account);
    }

    @Override
    public Optional<Account> getAccountById(UUID accountId) {
        return accountRepository.findById(accountId);
    }

    @Override
    public Optional<Account> getAccountByEmail(String email) {
        return accountRepository.findByEmail(email);
    }

    @Override
    public Optional<Account> getAccountByExternalUserId(Long externalUserId) {
        return accountRepository.findByExternalUserId(externalUserId);
    }

    @Override
    public Page<Account> getAllAccounts(Pageable pageable) {
        return accountRepository.findAll(pageable);
    }

    @Override
    @Transactional
    public Account updateAccount(UUID id, Account accountDetails) {
        return accountRepository.findById(id)
                .map(existingAccount -> {
                    // Update fields that can be modified in the payment system
                    existingAccount.setAddress(accountDetails.getAddress());
                    existingAccount.setMobilePhone(accountDetails.getMobilePhone());
                    existingAccount.setHomePhone(accountDetails.getHomePhone());
                    existingAccount.setDob(accountDetails.getDob());
                    existingAccount.setGender(accountDetails.getGender());
                    existingAccount.setProfilePicturePath(accountDetails.getProfilePicturePath());
                    existingAccount.setActive(accountDetails.isActive());

                    // Note: Name and email updates should come from User Service via events

                    return accountRepository.save(existingAccount);
                })
                .orElseThrow(() -> new IllegalArgumentException("Account not found with ID: " + id));
    }

    @Override
    public boolean isEmailTaken(String email) {
        return accountRepository.existsByEmail(email);
    }

    @Override
    public List<Account> searchAccounts(String searchTerm) {
        return accountRepository.searchByNameOrEmail(searchTerm);
    }

    @Override
    public List<Account> getActiveAccounts() {
        return accountRepository.findByIsActiveTrue();
    }

    @Override
    public Account linkExternalUser(UUID accountId, Long externalUserId) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new IllegalArgumentException("Account not found with ID: " + accountId));

        // Verify the user exists in the Login-Register service
        UserDTO userDTO = userServiceClient.getUserById(externalUserId);
        if (userDTO == null) {
            throw new IllegalArgumentException("User not found in User Service with ID: " + externalUserId);
        }

        // Check if another account is already linked to this user
        Optional<Account> existingLinkedAccount = accountRepository.findByExternalUserId(externalUserId);
        if (existingLinkedAccount.isPresent() && !existingLinkedAccount.get().getId().equals(accountId)) {
            throw new IllegalArgumentException("User is already linked to another account");
        }

        // Update the account with external user ID
        account.setEmail(userDTO.getEmail());
        account.setFirstName(userDTO.getFirstName());
        account.setLastName(userDTO.getLastName());

        log.info("Linked account {} to external user {}", accountId, externalUserId);

        return accountRepository.save(account);
    }

    /**
     * Find all accounts with a negative balance
     * @return List of accounts with negative balance
     */
    @Override
    public List<Account> findAccountsWithNegativeBalance() {
        List<Account> allAccounts = accountRepository.findAll();
        List<Account> accountsWithNegativeBalance = new ArrayList<>();

        for (Account account : allAccounts) {
            BigDecimal balance = accountRepository.getAccountBalance(account.getId());
            if (balance != null && balance.compareTo(BigDecimal.ZERO) < 0) {
                accountsWithNegativeBalance.add(account);
            }
        }

        return accountsWithNegativeBalance;
    }

    /**
     * Generate a reseller code based on last name
     */
    private String generateResellerCode(String lastName) {
        // Simple algorithm to generate a unique reseller code
        String baseCode = lastName.substring(0, Math.min(3, lastName.length())).toUpperCase();
        return baseCode + "-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
    }
}
