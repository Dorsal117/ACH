package org.hinna.payments.model;

public class TeacherSelectionForm {
    private String selectedTeacherId;
    private String selectedTime;

    public TeacherSelectionForm() {}

    public TeacherSelectionForm(String selectedTeacherId, String selectedTime) {
        this.selectedTeacherId = selectedTeacherId;
        this.selectedTime = selectedTime;
    }

    public String getSelectedTeacherId() {
        return selectedTeacherId;
    }

    public void setSelectedTeacherId(String selectedTeacherId) {
        this.selectedTeacherId = selectedTeacherId;
    }

    public String getSelectedTime() {
        return selectedTime;
    }

    public void setSelectedTime(String selectedTime) {
        this.selectedTime = selectedTime;
    }
}
