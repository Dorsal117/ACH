package org.hinna.payments;

import org.hinna.payments.model.*;
import org.hinna.payments.model.enums.PaymentStatus;
import org.hinna.payments.model.enums.PaymentType;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

public class HierarchyBillingUnitTest {

    @Test
    void testAdminAndGroupLinking() {
        AdminGroup group = new AdminGroup();
        group.setGroupName("Managers");

        Admin admin = new Admin();
        admin.setAdminType("Business");
        admin.setAdminGroup(group);

        assertEquals("Business", admin.getAdminType());
        assertEquals(group, admin.getAdminGroup());
    }

    @Test
    void testStaffAndGroupPermissionLogic() {
        Permission permission = new Permission("ACCESS_BILLING", "billing", "read");
        StaffGroup group = new StaffGroup("Finance");
        group.addPermission(permission);

        assertTrue(group.hasPermission("billing:read"));
        assertTrue(group.hasPermissionByKey("billing", "read"));
        group.removePermission(permission);
        assertFalse(group.hasPermission("billing:read"));
    }

    @Test
    void testAccountLifecycleAndBillingHistory() {
        Account account = new Account("Jane", "Doe", "jane@example.com");
        account.onCreate();

        BillingHistory history = new BillingHistory(account, new BigDecimal("99.99"), "CHARGE");
        history.onCreate();

        assertEquals("CHARGE", history.getTransactionType());
        assertEquals(account, history.getAccount());
        assertNotNull(history.getTransactionDate());
        assertNotNull(history.getCreatedAt());
    }

    @Test
    void testCouponValidationAndApplication() {
        Coupon coupon = new Coupon("NEWYEAR", Sale.DiscountType.FIXED_AMOUNT, new BigDecimal("10"));
        coupon.setActive(true);
        coupon.setExpiryDate(LocalDate.now().plusDays(1));
        coupon.setUsageLimit(1);

        BigDecimal applied = coupon.applyCoupon(new BigDecimal("50"));
        assertEquals(0, applied.compareTo(new BigDecimal("40.00")));

        assertTrue(coupon.incrementUsage());
        assertFalse(coupon.validateCoupon());
    }

    @Test
    void testPaymentLifecycleAndTransaction() {
        Account customer = new Account("Bob", "Smith", "bob@example.com");
        PaymentMethod method = new PaymentMethod(customer, PaymentType.CREDIT_CARD);

        Payment payment = new Payment(customer, new BigDecimal("200.00"), method);
        payment.onCreate();

        assertEquals(PaymentStatus.PENDING, payment.getStatus());
        PaymentStatus processed = payment.processPayment();
        assertEquals(PaymentStatus.COMPLETED, processed);
        assertEquals(1, payment.getTransactions().size());
    }

    @Test
    void testPaymentSettingsAllowedTypeControl() {
        Account acc = new Account("Max", "Pay", "max@example.com");
        PaymentSettings settings = new PaymentSettings(acc);

        assertTrue(settings.isPaymentTypeAllowed(PaymentType.CREDIT_CARD));
        settings.removeAllowedPaymentType(PaymentType.CREDIT_CARD);
        assertFalse(settings.isPaymentTypeAllowed(PaymentType.CREDIT_CARD));
    }

    @Test
    void testRefundReferenceAndDefaults() {
        Payment payment = new Payment();
        Refund refund = new Refund(payment, new BigDecimal("30.00"));
        refund.onCreate();

        assertEquals(PaymentStatus.PENDING, refund.getStatus());
        assertTrue(refund.getRefundReference().startsWith("REF-"));
    }

    @Test
    void testSaleDiscountCalculation() {
        Sale sale = new Sale("Spring Sale", Sale.DiscountType.PERCENTAGE, new BigDecimal("20"));
        sale.setEndDate(LocalDate.now().plusDays(5));

        assertTrue(sale.validateSale());
        BigDecimal discount = sale.calculateDiscount(new BigDecimal("100"));
        assertEquals(0, discount.compareTo(new BigDecimal("20.00")));
    }

    @Test
    void testPaymentMethodDisplayNameAndExpiry() {
        PaymentMethod method = new PaymentMethod();
        method.setType(PaymentType.BANK_TRANSFER);
        method.setLastFourDigits("9876");
        method.setExpiryDate(LocalDateTime.now().plusMonths(1));

        String name = method.getDisplayName();
        assertTrue(name.contains("9876"));
        assertFalse(method.isExpired());
    }

    @Test
    void testPaymentTransactionTimestamp() {
        PaymentTransaction txn = new PaymentTransaction();
        txn.setAmount(new BigDecimal("150.00"));
        txn.onCreate();

        assertNotNull(txn.getTimestamp());
        assertEquals(new BigDecimal("150.00"), txn.getAmount());
    }
}
