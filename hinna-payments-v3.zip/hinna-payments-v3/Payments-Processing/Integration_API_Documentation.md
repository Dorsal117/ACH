# HINNA Payment System - Integration API Documentation

Version: 1.0.0  
Last Updated: April 24, 2025

## Overview

This document describes the Integration APIs provided by the HINNA Payment System for use by the User Service. These APIs enable seamless integration between the two systems, allowing the User Service to verify accounts, access payment history, retrieve payment methods, and check account balances.

## Base URLs

| Environment | Base URL                                      |
|-------------|-----------------------------------------------|
| Development | `http://payment-service-dev.hinna.local/api/v1/integration` |
| Staging     | `http://payment-service-staging.hinna.app/api/v1/integration` |
| Production  | `https://payment-service.hinna.app/api/v1/integration` |

## Authentication

All Integration APIs require service-to-service authentication. The User Service must include a valid JWT token in the request headers.

### Obtaining Service Tokens

To obtain a service token, contact the HINNA Payment System team to register your service and receive credentials. Then make a request to:

```
POST /api/v1/auth/service-token
```

With the following request body:

```json
{
  "serviceId": "your-service-id",
  "serviceKey": "your-service-key"
}
```

The response will contain a JWT token that is valid for 24 hours.

### Using Tokens

Include the token in the `Authorization` header of all requests:

```
Authorization: Bearer your-jwt-token
```

## Rate Limits

The Integration APIs have the following rate limits:

- 100 requests per minute per service
- 5,000 requests per hour per service

Exceeding these limits will result in HTTP 429 Too Many Requests responses.

## Common Response Codes

| Status Code | Description                              |
|-------------|------------------------------------------|
| 200         | Success                                  |
| 400         | Bad Request - invalid parameters         |
| 401         | Unauthorized - invalid or missing token  |
| 403         | Forbidden - insufficient permissions     |
| 404         | Not Found - resource doesn't exist       |
| 429         | Too Many Requests - rate limit exceeded  |
| 500         | Internal Server Error                    |
| 503         | Service Unavailable                      |

## Error Response Format

All errors follow this format:

```json
{
  "status": 400,
  "message": "Bad Request",
  "details": "Detailed error description",
  "timestamp": "2025-04-24T14:32:25.123"
}
```

## API Endpoints

### 1. Verify Account

Checks if a user from the User Service has an account in the Payment System.

```
GET /account/verify/{userId}
```

#### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| userId    | Long | User ID from the User Service |

#### Response

```json
{
  "exists": true,
  "active": true,
  "accountType": "BUSINESS"
}
```

#### Response Fields

| Field       | Type    | Description |
|-------------|---------|-------------|
| exists      | boolean | Whether an account exists for the user |
| active      | boolean | Whether the account is active (null if no account) |
| accountType | string  | Type of account (CLIENT, BUSINESS, STAFF, RESELLER, SAAS) |

#### Example Request

```bash
curl -X GET "https://payment-service.hinna.app/api/v1/integration/account/verify/12345" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

### 2. Link Account

Links a user from the User Service to an account in the Payment System.

```
POST /account/link
```

#### Request Body

```json
{
  "accountId": "123e4567-e89b-12d3-a456-426614174000",
  "userId": 12345,
  "email": "user@example.com"
}
```

#### Request Fields

| Field     | Type   | Required | Description |
|-----------|--------|----------|-------------|
| accountId | UUID   | Yes      | ID of the account in the Payment System |
| userId    | Long   | Yes      | ID of the user in the User Service |
| email     | string | No       | Optional email address for verification |

#### Response

```json
{
  "success": true,
  "accountId": "123e4567-e89b-12d3-a456-426614174000",
  "userId": 12345,
  "message": "Account successfully linked"
}
```

#### Response Fields

| Field     | Type    | Description |
|-----------|---------|-------------|
| success   | boolean | Whether the linking was successful |
| accountId | UUID    | ID of the account in the Payment System |
| userId    | Long    | ID of the user in the User Service |
| message   | string  | Message describing the result |

#### Example Request

```bash
curl -X POST "https://payment-service.hinna.app/api/v1/integration/account/link" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." \
  -H "Content-Type: application/json" \
  -d '{"accountId":"123e4567-e89b-12d3-a456-426614174000","userId":12345,"email":"user@example.com"}'
```

### 3. Get Payment History

Retrieves payment history for a specific user from the User Service.

```
GET /user/{userId}/payments?page={page}&size={size}
```

#### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| userId    | Long | User ID from the User Service |

#### Query Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| page      | int  | 0       | Page number (zero-based) |
| size      | int  | 20      | Page size |

#### Response

```json
{
  "success": true,
  "message": "Payment history retrieved successfully",
  "payments": [
    {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "amount": 99.99,
      "status": "COMPLETED",
      "createdAt": "2025-04-20T10:30:45",
      "processedAt": "2025-04-20T10:31:15",
      "referenceNumber": "PAY-123456789",
      "description": "Monthly subscription",
      "paymentMethod": "Credit Card"
    }
  ],
  "page": 0,
  "pageSize": 20,
  "totalElements": 42
}
```

#### Response Fields

| Field         | Type                | Description |
|---------------|---------------------|-------------|
| success       | boolean             | Whether the request was successful |
| message       | string              | Message describing the result |
| payments      | array of objects    | List of payment summaries |
| page          | int                 | Current page number (zero-based) |
| pageSize      | int                 | Size of each page |
| totalElements | long                | Total number of payments |

#### Payment Object Fields

| Field           | Type      | Description |
|-----------------|-----------|-------------|
| id              | UUID      | Payment ID |
| amount          | decimal   | Payment amount |
| status          | string    | Payment status (PENDING, PROCESSING, COMPLETED, FAILED, etc.) |
| createdAt       | datetime  | Time the payment was created |
| processedAt     | datetime  | Time the payment was processed (may be null) |
| referenceNumber | string    | Payment reference number |
| description     | string    | Payment description |
| paymentMethod   | string    | Payment method used |

#### Example Request

```bash
curl -X GET "https://payment-service.hinna.app/api/v1/integration/user/12345/payments?page=0&size=20" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

### 4. Get Payment Methods

Retrieves available payment methods for a specific user.

```
GET /user/{userId}/payment-methods
```

#### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| userId    | Long | User ID from the User Service |

#### Response

```json
{
  "success": true,
  "message": "Payment methods retrieved successfully",
  "paymentMethods": [
    {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "type": "CREDIT_CARD",
      "lastFourDigits": "1234",
      "expiryDate": "2026-12-31T23:59:59",
      "isDefault": true,
      "displayName": "Visa ending in 1234"
    },
    {
      "id": "223e4567-e89b-12d3-a456-426614174001",
      "type": "PAYPAL",
      "lastFourDigits": null,
      "expiryDate": null,
      "isDefault": false,
      "displayName": "PayPal account"
    }
  ]
}
```

#### Response Fields

| Field          | Type             | Description |
|----------------|------------------|-------------|
| success        | boolean          | Whether the request was successful |
| message        | string           | Message describing the result |
| paymentMethods | array of objects | List of payment methods |

#### Payment Method Object Fields

| Field          | Type      | Description |
|----------------|-----------|-------------|
| id             | UUID      | Payment method ID |
| type           | string    | Payment method type (CREDIT_CARD, BANK_TRANSFER, PAYPAL, etc.) |
| lastFourDigits | string    | Last four digits of the card (if applicable) |
| expiryDate     | datetime  | Expiry date (if applicable) |
| isDefault      | boolean   | Whether this is the default payment method |
| displayName    | string    | Display name for the payment method |

#### Example Request

```bash
curl -X GET "https://payment-service.hinna.app/api/v1/integration/user/12345/payment-methods" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

### 5. Get Balance

Retrieves current account balance or credit for a specific user.

```
GET /user/{userId}/balance
```

#### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| userId    | Long | User ID from the User Service |

#### Response

```json
{
  "success": true,
  "message": "Balance information retrieved successfully",
  "balance": 500.00,
  "availableCredit": 1000.00,
  "pendingTransactions": 50.00
}
```

#### Response Fields

| Field              | Type    | Description |
|--------------------|---------|-------------|
| success            | boolean | Whether the request was successful |
| message            | string  | Message describing the result |
| balance            | decimal | Current balance |
| availableCredit    | decimal | Available credit (may be null if not applicable) |
| pendingTransactions| decimal | Amount in pending transactions |

#### Example Request

```bash
curl -X GET "https://payment-service.hinna.app/api/v1/integration/user/12345/balance" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

### 6. Health Check

Checks if the Payment System integration API is available.

```
GET /health
```

#### Response

```json
{
  "status": "UP",
  "service": "Payment Service",
  "version": "1.0.0",
  "timestamp": 1714055545123
}
```

#### Response Fields

| Field     | Type    | Description |
|-----------|---------|-------------|
| status    | string  | Service status (UP or DOWN) |
| service   | string  | Service name |
| version   | string  | API version |
| timestamp | long    | Current server timestamp |

#### Example Request

```bash
curl -X GET "https://payment-service.hinna.app/api/v1/integration/health"
```

## Implementation Notes

1. All date/time fields are in ISO 8601 format (e.g., "2025-04-24T14:32:25.123").
2. All monetary amounts are in decimal format with up to 2 decimal places.
3. All UUIDs are in standard format (e.g., "123e4567-e89b-12d3-a456-426614174000").

## Change Log

| Date        | Version | Changes |
|-------------|---------|---------|
| 2025-04-24  | 1.0.0   | Initial release |