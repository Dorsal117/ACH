/**
 * PayrollPage.js - JavaScript for payroll functionality
 */

// Tab switching functionality
function switchTab(element, tabType) {
    // Update tab appearance
    document.querySelectorAll('.tabs .tab').forEach(tab => {
        tab.classList.remove('active');
        tab.classList.add('inactive');
    });
    element.classList.remove('inactive');
    element.classList.add('active');

    // Update URL without reload
    const url = new URL(window.location);
    url.searchParams.set('tab', tabType);
    window.history.pushState({}, '', url);
}

// Toggle automatic payments
function toggleAutomaticPayments(element) {
    const switchEl = element.querySelector('.toggle-switch');
    const isActive = switchEl.classList.contains('active');
    const newState = !isActive;

    // Update UI immediately
    switchEl.classList.toggle('active');
    element.classList.toggle('active');

    // Get employer ID from the page
    const employerIdInput = document.querySelector('input[name="employerId"]');
    const employerId = employerIdInput ? employerIdInput.value : '';

    if (!employerId) {
        showToast('Employer ID not found', 'error');
        // Revert UI changes
        switchEl.classList.toggle('active');
        element.classList.toggle('active');
        return;
    }

    // Send request to backend
    fetch('/settings/payroll/toggle-automatic-payments', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `employerId=${employerId}&enabled=${newState}`
    })
        .then(response => response.text())
        .then(result => {
            if (result === 'success') {
                showToast(`Automatic payments ${newState ? 'enabled' : 'disabled'}`);
            } else {
                // Revert UI changes on error
                switchEl.classList.toggle('active');
                element.classList.toggle('active');
                showToast('Error updating automatic payments', 'error');
            }
        })
        .catch(error => {
            // Revert UI changes on error
            switchEl.classList.toggle('active');
            element.classList.toggle('active');
            showToast('Error updating automatic payments', 'error');
            console.error('Error:', error);
        });
}

// Filter dropdown functionality
function initializeFilterDropdown() {
    const filterBtn = document.getElementById("toggleFilterBtn");
    const dropdown = document.getElementById("filterDropdown");

    if (filterBtn && dropdown) {
        dropdown.classList.add("hidden");

        filterBtn.addEventListener("click", function (event) {
            event.preventDefault();
            dropdown.classList.toggle("hidden");
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            if (!filterBtn.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.add("hidden");
            }
        });
    }
}

// Modal functions
function showModal(modalId) {
    if (modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('hidden');
        }
    } else {
        // For HTMX-loaded modals
        const modalContainer = document.getElementById('modal-container');
        if (modalContainer && modalContainer.innerHTML.trim()) {
            modalContainer.style.display = 'block';
        }
    }
}

function hideModal(modalId) {
    if (modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('hidden');
        }
    } else {
        const modalContainer = document.getElementById('modal-container');
        if (modalContainer) {
            modalContainer.style.display = 'none';
            modalContainer.innerHTML = '';
        }
    }
}

// Toast notification function
function showToast(message, type = 'success') {
    const toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        console.warn('Toast container not found');
        return;
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;

    toastContainer.appendChild(toast);

    // Animate in
    setTimeout(() => toast.classList.add('show'), 100);

    // Remove after 3 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            if (toast.parentNode) {
                toast.remove();
            }
        }, 300);
    }, 3000);
}

// More options dropdown
function showMoreOptions(element, payrollId) {
    // Remove any existing dropdowns
    document.querySelectorAll('.more-options-dropdown').forEach(d => d.remove());

    const dropdown = document.createElement('div');
    dropdown.className = 'more-options-dropdown';
    dropdown.innerHTML = `
        <div class="dropdown-item" onclick="editPayroll('${payrollId}')">Edit</div>
        <div class="dropdown-item" onclick="deletePayroll('${payrollId}')">Delete</div>
        <div class="dropdown-item" onclick="duplicatePayroll('${payrollId}')">Duplicate</div>
        <div class="dropdown-item" onclick="viewHistory('${payrollId}')">View History</div>
    `;

    element.style.position = 'relative';
    element.appendChild(dropdown);

    // Close dropdown when clicking outside
    setTimeout(() => {
        document.addEventListener('click', function closeDropdown(event) {
            if (!element.contains(event.target)) {
                dropdown.remove();
                document.removeEventListener('click', closeDropdown);
            }
        });
    }, 100);
}

// Payroll action functions
function editPayroll(payrollId) {
    console.log('Edit payroll:', payrollId);
    showToast('Edit functionality coming soon');
}

function deletePayroll(payrollId) {
    if (confirm('Are you sure you want to delete this payroll?')) {
        fetch(`/settings/payroll/${payrollId}`, {
            method: 'DELETE'
        })
            .then(response => {
                if (response.ok) {
                    showToast('Payroll deleted successfully');
                    // Refresh the current page
                    window.location.reload();
                } else {
                    showToast('Error deleting payroll', 'error');
                }
            })
            .catch(error => {
                showToast('Error deleting payroll', 'error');
                console.error('Error:', error);
            });
    }
}

function duplicatePayroll(payrollId) {
    fetch(`/settings/payroll/${payrollId}/duplicate`, {
        method: 'POST'
    })
        .then(response => {
            if (response.ok) {
                showToast('Payroll duplicated successfully');
                // Refresh the current page
                window.location.reload();
            } else {
                showToast('Error duplicating payroll', 'error');
            }
        })
        .catch(error => {
            showToast('Error duplicating payroll', 'error');
            console.error('Error:', error);
        });
}

function viewHistory(payrollId) {
    if (typeof htmx !== 'undefined') {
        htmx.ajax('GET', `/settings/payroll/${payrollId}/history`, {
            target: '#modal-container'
        }).then(() => showModal());
    } else {
        console.error('HTMX not loaded');
        showToast('Unable to load history', 'error');
    }
}

// HTMX event listeners
function initializeHTMXEventListeners() {
    document.addEventListener('htmx:afterRequest', function(event) {
        if (event.detail.xhr.status >= 400) {
            showToast('An error occurred', 'error');
        }
    });

    document.addEventListener('htmx:responseError', function(event) {
        showToast('Network error occurred', 'error');
    });

    document.addEventListener('htmx:sendError', function(event) {
        showToast('Request failed', 'error');
    });
}

// Initialize when DOM is loaded
document.addEventListener("DOMContentLoaded", function () {
    initializeFilterDropdown();
    initializeHTMXEventListeners();

    console.log('PayrollPage.js initialized');
});

// Auto-refresh functionality (optional)
function enableAutoRefresh(intervalMs = 30000) {
    setInterval(() => {
        const activeTab = document.querySelector('.tab.active');
        if (activeTab && typeof htmx !== 'undefined') {
            htmx.trigger(activeTab, 'click');
        }
    }, intervalMs);
}

// Utility function to get current employer ID
function getCurrentEmployerId() {
    const employerIdInput = document.querySelector('input[name="employerId"]');
    return employerIdInput ? employerIdInput.value : null;
}

// Export functions for global access (if needed)
window.PayrollPage = {
    switchTab,
    toggleAutomaticPayments,
    showModal,
    hideModal,
    showToast,
    showMoreOptions,
    editPayroll,
    deletePayroll,
    duplicatePayroll,
    viewHistory,
    enableAutoRefresh,
    getCurrentEmployerId
};