(function () {
    const state = {
        accountId: null,
        stripeReady: false,
        loadingMethods: false,
        selectedMethodId: null,
        methods: []
    };

    const selectors = {
        form: '#payment-form',
        toggleButtons: '.payment-method-toggle .toggle-button',
        panes: '.payment-pane',
        achPane: '#ach-pane',
        achError: '#ach-error',
        achMessage: '#ach-link-message',
        achLinkButton: '#ach-link-button',
        achHolder: '#ach-account-holder',
        achEmail: '#ach-account-email',
        achList: '#ach-methods-list',
        achEmpty: '#ach-methods-empty',
        achTemplate: '#ach-method-template',
        refreshAll: '#ach-refresh-all'
    };

    function qs(selector, scope = document) {
        return scope.querySelector(selector);
    }

    function qsa(selector, scope = document) {
        return Array.from(scope.querySelectorAll(selector));
    }

    function resolveAccountId() {
        const form = qs(selectors.form);
        if (!form) {
            return null;
        }
        const value = (form.getAttribute('data-account-id') || '').trim();
        return value && value.toLowerCase() !== 'null' ? value : null;
    }

    async function getStripe() {
        if (typeof window.getStripeInstance !== 'function') {
            throw new Error('Stripe.js is not initialised yet.');
        }
        const stripe = await window.getStripeInstance();
        if (!stripe) {
            throw new Error('Stripe initialisation failed.');
        }
        state.stripeReady = true;
        return stripe;
    }

    function showError(message) {
        const node = qs(selectors.achError);
        if (node) {
            node.textContent = message || '';
        }
    }

    function showMessage(message) {
        const node = qs(selectors.achMessage);
        if (node) {
            node.textContent = message || '';
        }
    }

    function setButtonLoading(button, isLoading, loadingText) {
        if (!button) {
            return;
        }
        if (isLoading) {
            if (!button.dataset.originalText) {
                button.dataset.originalText = button.textContent;
            }
            button.disabled = true;
            if (loadingText) {
                button.textContent = loadingText;
            }
        } else {
            button.disabled = false;
            if (button.dataset.originalText) {
                button.textContent = button.dataset.originalText;
                delete button.dataset.originalText;
            }
        }
    }

    function parseMicroDeposit(value) {
        if (!value) {
            return null;
        }
        const normalised = value.replace(/[^0-9.]/g, '');
        if (!normalised) {
            return null;
        }
        const parsed = Number(normalised);
        if (Number.isNaN(parsed)) {
            return null;
        }
        return Math.round(parsed * 100);
    }

    function statusClass(status) {
        if (!status) {
            return 'status-unverified';
        }
        const key = status.toLowerCase();
        switch (key) {
            case 'verified':
                return 'status-verified';
            case 'pending':
                return 'status-pending';
            case 'failed':
                return 'status-failed';
            default:
                return 'status-unverified';
        }
    }

    function buildDetails(method) {
        const parts = [];
        if (method.lastFourDigits) {
            parts.push(`•••• ${method.lastFourDigits}`);
        }
        if (method.bankMandateReference) {
            parts.push(`Mandate ${method.bankMandateReference}`);
        }
        if (!parts.length && method.brand) {
            parts.push(method.brand.replaceAll('_', ' '));
        }
        return parts.join(' · ');
    }

    function shouldShowVerification(status) {
        if (!status) {
            return true;
        }
        const key = status.toUpperCase();
        return key === 'UNVERIFIED' || key === 'PENDING';
    }

    async function fetchSetupIntent(name, email) {
        const url = `/api/payment-methods/owner/${state.accountId}/ach/setup-intent`;
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ accountHolderName: name, email })
        });
        if (!response.ok) {
            const text = await response.text();
            throw new Error(text || 'Unable to create ACH setup intent.');
        }
        const data = await response.json();
        if (!data.clientSecret) {
            throw new Error('Setup intent missing client secret.');
        }
        return data.clientSecret;
    }

    async function savePaymentMethod(paymentMethodId, accountHolderName) {
        const payload = {
            ownerId: state.accountId,
            type: 'BANK_TRANSFER',
            providerToken: paymentMethodId,
            isDefault: false,
            isActive: false,
            brand: 'us_bank_account',
            achAccountHolderName: accountHolderName
        };
        const response = await fetch('/api/payment-methods', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        if (!response.ok) {
            const text = await response.text();
            throw new Error(text || 'Failed to save bank account.');
        }
        return response.json();
    }

    async function refreshAchMethod(methodId) {
        const response = await fetch(`/api/payment-methods/${methodId}/ach/refresh`, {
            method: 'POST'
        });
        if (!response.ok) {
            const text = await response.text();
            throw new Error(text || 'Unable to refresh bank account.');
        }
        return response.json();
    }

    async function deleteAchMethod(methodId) {
        const response = await fetch(`/api/payment-methods/${methodId}`, {
            method: 'DELETE'
        });
        if (!response.ok) {
            const text = await response.text();
            throw new Error(text || 'Unable to delete bank account.');
        }
    }


    async function verifyMicroDeposits(methodId, amounts, errorNode) {
        const payload = {
            firstAmount: amounts[0],
            secondAmount: amounts[1]
        };
        const response = await fetch(`/api/payment-methods/${methodId}/ach/verify`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        if (!response.ok) {
            const text = await response.text();
            throw new Error(text || 'Verification failed.');
        }
        if (errorNode) {
            errorNode.classList.remove('form-error');
            errorNode.classList.add('form-hint');
            errorNode.textContent = 'Micro-deposits confirmed successfully.';
        }
        return response.json();
    }

    function renderAchMethods(methods) {
        const listNode = qs(selectors.achList);
        const emptyNode = qs(selectors.achEmpty);
        const template = qs(selectors.achTemplate);
        if (!listNode || !template) {
            return;
        }
        listNode.innerHTML = '';

        if (!methods.length) {
            if (emptyNode) {
                emptyNode.style.display = 'block';
                emptyNode.textContent = 'No bank accounts linked yet.';
            }
            return;
        }

        if (emptyNode) {
            emptyNode.style.display = 'none';
        }

        methods.forEach((method) => {
            const fragment = template.content.cloneNode(true);
            const card = fragment.querySelector('.ach-method-card');
            if (!card) {
                return;
            }
            card.dataset.methodId = method.id;

            const isVerified = method.bankAccountVerified === true ||
                (method.bankVerificationStatus && method.bankVerificationStatus.toUpperCase() === 'VERIFIED');

            if (!state.selectedMethodId && isVerified) {
                state.selectedMethodId = method.id;
            }

            const radio = card.querySelector('.ach-select-radio');
            if (radio) {
                radio.value = method.id;
                radio.disabled = !isVerified;
                radio.checked = state.selectedMethodId === method.id;
                radio.addEventListener('change', () => {
                    if (radio.disabled) {
                        return;
                    }
                    state.selectedMethodId = method.id;
                    document.dispatchEvent(new CustomEvent('ach-method-selected', {
                        detail: { methodId: method.id, method }
                    }));
                    renderAchMethods(state.methods);
                });
            }

            card.classList.toggle('selected', state.selectedMethodId === method.id);

            const titleNode = card.querySelector('.ach-method-name');
            if (titleNode) {
                titleNode.textContent = method.displayName || 'Bank account';
            }

            const detailNode = card.querySelector('.ach-method-details');
            if (detailNode) {
                detailNode.textContent = buildDetails(method) || 'Awaiting verification';
            }

            const badge = card.querySelector('.ach-status-badge');
            if (badge) {
                const status = method.bankVerificationStatus || 'UNVERIFIED';
                badge.textContent = status.toLowerCase().replace(/_/g, ' ');
                badge.classList.add(statusClass(status));
            }

            const mandateBlock = card.querySelector('.ach-mandate');
            if (mandateBlock) {
                if (method.bankMandateUrl) {
                    mandateBlock.hidden = false;
                    const link = mandateBlock.querySelector('.ach-mandate-link');
                    if (link) {
                        link.href = method.bankMandateUrl;
                        link.textContent = method.bankMandateUrl;
                    }
                } else {
                    mandateBlock.hidden = true;
                }
            }

            const refreshBtn = card.querySelector('.ach-refresh-btn');
            if (refreshBtn) {
                refreshBtn.addEventListener('click', async () => {
                    try {
                        setButtonLoading(refreshBtn, true, 'Refreshing...');
                        await refreshAchMethod(method.id);
                        await loadAchMethods();
                    } catch (err) {
                        showError(err.message);
                    } finally {
                        setButtonLoading(refreshBtn, false);
                    }
                });
            }

            const deleteBtn = card.querySelector('.ach-delete-btn');
            if (deleteBtn) {
                deleteBtn.addEventListener('click', async () => {
                    if (!window.confirm('Remove this bank account?')) {
                        return;
                    }
                    try {
                        setButtonLoading(deleteBtn, true, 'Removing...');
                        await deleteAchMethod(method.id);

                        if (state.selectedMethodId === method.id) {
                            state.selectedMethodId = null;
                        }
                        showMessage('Bank account removed.');
                        await loadAchMethods();
                    } catch (err) {
                        showError(err.message);
                    } finally {
                        setButtonLoading(deleteBtn, false);
                    }
                });
            }


            const verifyBlock = card.querySelector('.ach-verify-block');
            if (verifyBlock) {
                if (shouldShowVerification(method.bankVerificationStatus)) {
                    verifyBlock.hidden = false;
                    const inputs = verifyBlock.querySelectorAll('.ach-verify-amount');
                    const submitBtn = verifyBlock.querySelector('.ach-verify-submit');
                    const feedback = verifyBlock.querySelector('.ach-verify-error');
                    if (submitBtn) {
                        submitBtn.addEventListener('click', async () => {
                            if (feedback) {
                                feedback.classList.add('form-error');
                                feedback.classList.remove('form-hint');
                                feedback.textContent = '';
                            }
                            const values = Array.from(inputs).map((input) => parseMicroDeposit(input.value));
                            if (values.some((val) => val === null || val <= 0)) {
                                if (feedback) {
                                    feedback.textContent = 'Enter both amounts as they appear on your statement (e.g. 0.32).';
                                }
                                return;
                            }
                            try {
                                setButtonLoading(submitBtn, true, 'Submitting...');
                                await verifyMicroDeposits(method.id, values, feedback);
                                await loadAchMethods();
                            } catch (err) {
                                if (feedback) {
                                    feedback.classList.add('form-error');
                                    feedback.classList.remove('form-hint');
                                    feedback.textContent = err.message;
                                }
                            } finally {
                                setButtonLoading(submitBtn, false);
                            }
                        });
                    }
                } else {
                    verifyBlock.hidden = true;
                }
            }

            listNode.appendChild(card);
        });
    }

    async function loadAchMethods() {
        if (!state.accountId) {
            return;
        }
        if (state.loadingMethods) {
            return;
        }
        state.loadingMethods = true;
        const emptyNode = qs(selectors.achEmpty);
        if (emptyNode) {
            emptyNode.style.display = 'block';
            emptyNode.textContent = 'Loading linked bank accounts...';
        }
        try {
            const response = await fetch(`/api/payment-methods/owner/${state.accountId}`);
            if (!response.ok) {
                const text = await response.text();
                throw new Error(text || 'Unable to load payment methods.');
            }
            const methods = await response.json();
            const achMethods = Array.isArray(methods)
                ? methods.filter((item) => item.type === 'BANK_TRANSFER'
                    && (item.bankVerificationStatus || '').toUpperCase() !== 'FAILED')
                : [];

            state.methods = achMethods;

            if (emptyNode) {
                if (achMethods.length === 0) {
                    emptyNode.style.display = 'block';
                    emptyNode.textContent = 'No bank accounts linked yet.';
                } else {
                    emptyNode.style.display = 'none';
                }
            }

            if (!achMethods.some((item) => item.id === state.selectedMethodId && item.bankAccountVerified)) {
                state.selectedMethodId = null;
            }
            renderAchMethods(achMethods);
            document.dispatchEvent(new CustomEvent('ach-methods-updated', { detail: { methods: achMethods } }));
        } catch (err) {
            showError(err.message);
            if (emptyNode) {
                emptyNode.style.display = 'block';
                emptyNode.textContent = 'Failed to load bank accounts. Try refreshing.';
            }
        } finally {
            state.loadingMethods = false;
        }
    }

    async function handleLinkBank() {
        const linkButton = qs(selectors.achLinkButton);
        const nameInput = qs(selectors.achHolder);
        const emailInput = qs(selectors.achEmail);

        if (!linkButton || !nameInput || !emailInput) {
            return;
        }

        showError('');
        showMessage('');

        const name = nameInput.value.trim();
        const email = emailInput.value.trim();
        if (!name) {
            showError('Enter the name on the bank account.');
            return;
        }
        if (!email) {
            showError('Enter an email address for Stripe updates.');
            return;
        }

        try {
            setButtonLoading(linkButton, true, 'Connecting...');
            showMessage('Opening secure bank connection...');
            const stripe = await getStripe();
            const clientSecret = await fetchSetupIntent(name, email);
            const collectResult = await stripe.collectBankAccountForSetup({
                clientSecret,
                params: {
                    payment_method_type: 'us_bank_account',
                    payment_method_data: {
                        billing_details: {
                            name,
                            email
                        }
                    }
                }
            });
            if (collectResult.error) {
                throw new Error(collectResult.error.message || 'Bank account collection cancelled.');
            }
            const confirmResult = await stripe.confirmUsBankAccountSetup(clientSecret);
            if (confirmResult.error) {
                throw new Error(confirmResult.error.message || 'Bank account confirmation failed.');
            }
            const paymentMethodId = confirmResult.setupIntent?.payment_method;
            if (!paymentMethodId) {
                throw new Error('Stripe did not return a payment method ID.');
            }
            await savePaymentMethod(paymentMethodId, name);
            await loadAchMethods();
            showMessage('Bank account linked. Awaiting verification.');
            nameInput.value = '';
            emailInput.value = '';
        } catch (err) {
            showError(err.message);
        } finally {
            setButtonLoading(linkButton, false);
        }
    }

    function setupToggle() {
        const buttons = qsa(selectors.toggleButtons);
        const panes = qsa(selectors.panes);
        if (!buttons.length || !panes.length) {
            return;
        }
        buttons.forEach((button) => {
            button.addEventListener('click', () => {
                const targetId = button.dataset.target;
                buttons.forEach((btn) => {
                    btn.classList.toggle('active', btn === button);
                    btn.setAttribute('aria-selected', btn === button ? 'true' : 'false');
                });
                panes.forEach((pane) => {
                    if (pane.id === targetId) {
                        pane.hidden = false;
                        pane.classList.add('active');
                    } else {
                        pane.hidden = true;
                        pane.classList.remove('active');
                    }
                });
            });
        });
    }

    function setupRefreshAll() {
        const trigger = qs(selectors.refreshAll);
        if (!trigger) {
            return;
        }
        trigger.addEventListener('click', async () => {
            try {
                setButtonLoading(trigger, true, 'Refreshing...');
                await loadAchMethods();
            } catch (err) {
                showError(err.message);
            } finally {
                setButtonLoading(trigger, false);
            }
        });
    }

    document.addEventListener('DOMContentLoaded', async () => {
        state.accountId = resolveAccountId();
        setupToggle();
        setupRefreshAll();

        const linkButton = qs(selectors.achLinkButton);
        if (linkButton) {
            if (!state.accountId) {
                linkButton.disabled = true;
                showError('Log in to link a bank account.');
            } else {
                linkButton.addEventListener('click', handleLinkBank);
            }
        }

        if (state.accountId) {
            loadAchMethods();
        }
    });

    window.AchPayment = {
        getSelectedMethodId: () => state.selectedMethodId,
        getMethodById: (id) => state.methods.find((item) => item.id === id) || null,
        getMethods: () => state.methods.slice(),
        refresh: () => loadAchMethods(),
        setSelectedMethodId: (id) => {
            state.selectedMethodId = id;
            renderAchMethods(state.methods);
        }
    };
})();
