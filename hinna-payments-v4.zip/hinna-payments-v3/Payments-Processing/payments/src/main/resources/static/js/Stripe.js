const StripeCardState = {
    initPromise: null,
    stripe: null,
    elements: null,
    cardNumber: null,
    cardExpiry: null,
    cardCvc: null,
    clientSecret: null,
    listenersBound: false
};

function resolvePublishableKey() {
    const body = document.body;
    if (!body) {
        return null;
    }
    const provided = (body.getAttribute('data-stripe-publishable-key') || '').trim();
    if (provided) {
        return provided;
    }
    const fallback = (body.getAttribute('data-default-stripe-key') || '').trim();
    return fallback || null;
}

async function getStripeInstance() {
    if (StripeCardState.initPromise) {
        await StripeCardState.initPromise;
        return StripeCardState.stripe;
    }
    StripeCardState.initPromise = (async () => {
        const key = resolvePublishableKey();
        if (!key) {
            console.error('Stripe publishable key missing.');
            return null;
        }
        StripeCardState.stripe = Stripe(key);
        StripeCardState.elements = StripeCardState.stripe.elements();
        window.__stripe = StripeCardState.stripe;
        return StripeCardState.stripe;
    })();
    await StripeCardState.initPromise;
    return StripeCardState.stripe;
}

function ensureCardElements() {
    if (!StripeCardState.elements) {
        return;
    }
    const style = {
        base: {
            fontSize: '14px',
            color: '#32325d',
            '::placeholder': { color: '#aab7c4' }
        }
    };
    if (!StripeCardState.cardNumber) {
        StripeCardState.cardNumber = StripeCardState.elements.create('cardNumber', { style });
    }
    if (!StripeCardState.cardExpiry) {
        StripeCardState.cardExpiry = StripeCardState.elements.create('cardExpiry', { style });
    }
    if (!StripeCardState.cardCvc) {
        StripeCardState.cardCvc = StripeCardState.elements.create('cardCvc', { style });
    }

    mountElementOnce('#card-number', StripeCardState.cardNumber);
    mountElementOnce('#exp-date', StripeCardState.cardExpiry);
    mountElementOnce('#cvv', StripeCardState.cardCvc);

    if (!StripeCardState.listenersBound) {
        bindCardListeners();
        StripeCardState.listenersBound = true;
    }
}

function mountElementOnce(selector, element) {
    const container = document.querySelector(selector);
    if (container && !container.querySelector('iframe')) {
        element.mount(selector);
    }
}

function bindCardListeners() {
    const formError = document.getElementById('form-error');
    const expError = document.getElementById('exp-error');

    const setFormError = (message) => {
        if (formError) {
            formError.textContent = message || '';
        }
    };
    const setExpError = (message) => {
        if (expError) {
            expError.textContent = message || '';
        }
    };

    if (StripeCardState.cardNumber) {
        StripeCardState.cardNumber.on('change', (event) => {
            setFormError(event.error ? event.error.message : '');
        });
    }
    if (StripeCardState.cardExpiry) {
        StripeCardState.cardExpiry.on('change', (event) => {
            setExpError(event.error ? event.error.message : '');
        });
    }
    if (StripeCardState.cardCvc) {
        StripeCardState.cardCvc.on('change', (event) => {
            setFormError(event.error ? event.error.message : '');
        });
    }
}

async function fetchTestIntent() {
    try {
        const response = await fetch('/api/test/stripe/intent', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                amount: 120.0,
                name: 'Test User',
                email: 'test@example.com'
            })
        });
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(errorText || 'Failed to fetch payment intent.');
        }
        StripeCardState.clientSecret = await response.text();
    } catch (err) {
        console.error('Error fetching client secret:', err);
        const formError = document.getElementById('form-error');
        if (formError) {
            formError.textContent = err.message || 'Network error while preparing payment.';
        }
    }
}

async function handleCompletePurchase() {
    if (document.body && document.body.dataset.checkoutMethod && document.body.dataset.checkoutMethod !== 'card') {
        return;
    }

    const stripe = StripeCardState.stripe;
    if (!stripe || !StripeCardState.clientSecret) {
        console.error('Stripe is not ready or client secret missing.');
        return;
    }

    const formError = document.getElementById('form-error');
    const expError = document.getElementById('exp-error');
    if (formError) {
        formError.textContent = '';
    }
    if (expError) {
        expError.textContent = '';
    }

    const nameInput = document.getElementById('card-name');
    const cardName = nameInput ? nameInput.value.trim() : '';
    if (!cardName) {
        if (formError) {
            formError.textContent = 'Please enter the name on the card.';
        }
        return;
    }

    const result = await stripe.confirmCardPayment(StripeCardState.clientSecret, {
        payment_method: {
            card: StripeCardState.cardNumber,
            billing_details: { name: cardName }
        }
    });

    if (result.error) {
        const target = (result.error.code === 'card_expired' || result.error.code === 'incomplete_expiry')
            ? expError
            : formError;
        if (target) {
            target.textContent = result.error.message || 'Card could not be confirmed.';
        }
        return;
    }

    if (result.paymentIntent && result.paymentIntent.status === 'succeeded') {
        sessionStorage.setItem('cardName', cardName);
        window.location.href = '/payment/confirmation';
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    const stripe = await getStripeInstance();
    if (!stripe) {
        const formError = document.getElementById('form-error');
        if (formError) {
            formError.textContent = 'Stripe configuration is missing. Please contact support.';
        }
        return;
    }

    ensureCardElements();
    await fetchTestIntent();

    const completeButton = document.getElementById('complete-btn');
    if (completeButton) {
        completeButton.addEventListener('click', handleCompletePurchase);
    }
});

window.getStripeInstance = getStripeInstance;
window.StripeCardState = StripeCardState;
