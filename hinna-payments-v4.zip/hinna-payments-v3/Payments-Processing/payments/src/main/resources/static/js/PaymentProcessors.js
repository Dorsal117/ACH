    // ----------------------------
    // Add Payment Method Logic
    // ----------------------------
    document.addEventListener("DOMContentLoaded", function () {
        const addBtn = document.getElementById("add-payment-method-btn");
        const wrapper = document.getElementById("stripe-payment-element-wrapper");
        const errorBox = document.getElementById("form-error");
        const saveBtn = document.getElementById("save-stripe-method");

        let stripe = null;
        let elements = null;

        addBtn.addEventListener("click", async function (e) {
            e.preventDefault();
            wrapper.classList.remove("hidden");

            const response = await fetch("/payment-processors/create-setup-intent", {
                method: "POST"
            });

            const { clientSecret } = await response.json();

            stripe = Stripe("pk_test_51RGDAfQZ6gIfOOSEX9q270G1cOMZhyqpYtG5fxgabxEufdxFA29SQlXQqNMoTYXm1FLlISR9ZETeFASUiDpHE0te004es5CQXN");
            elements = stripe.elements({ clientSecret });

            const paymentElement = elements.create("payment");
            paymentElement.mount("#payment-element");

            saveBtn.onclick = async () => {
                const { setupIntent, error } = await stripe.confirmSetup({
                    elements,
                    confirmParams: {
                        return_url: window.location.href
                    },
                    redirect: "if_required"
                });

                if (error) {
                    errorBox.textContent = error.message;
                } else {
                    errorBox.textContent = "";
                    alert("Payment method saved successfully: " + setupIntent.payment_method);
                    wrapper.classList.add("hidden");
                }
            };
        });
    // ----------------------------
    // Payment Processor Logic
    // ----------------------------
    const connectionForm = document.getElementById('connection-form');
    const connectBtn = document.getElementById("connect-btn");
    const errorMsg = document.getElementById("stripe-error-msg");

    const providerSelect = document.getElementById('provider');
    const apiKeyRow = document.getElementById('api-key-row');
    const secretKeyRow = document.getElementById('secret-key-row');
    const submitRow = document.getElementById('submit-row');

    const addConnectionBtn = document.getElementById('add-connection-btn');
    if (addConnectionBtn) {
        addConnectionBtn.addEventListener('click', function (e) {
            e.preventDefault();
            connectionForm.classList.remove('hidden');
            providerSelect.selectedIndex = 0;
            apiKeyRow.classList.remove('hidden');
            secretKeyRow.classList.remove('hidden');
            submitRow.classList.remove('hidden');
            connectionForm.querySelectorAll("input").forEach(input => input.value = "");
            errorMsg.classList.add("hidden");
        });
    }

    const cancelBtn = document.getElementById('cancel-btn');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function () {
            connectionForm.classList.add('hidden');
            providerSelect.selectedIndex = 0;
            apiKeyRow.classList.add('hidden');
            secretKeyRow.classList.add('hidden');
            submitRow.classList.add('hidden');
            errorMsg.classList.add("hidden");
        });
    }

    connectionForm.addEventListener("keypress", function (e) {
        if (e.key === "Enter") {
            e.preventDefault();
            if (!connectBtn.disabled) {
                connectBtn.click();
            }
        }
    });

    connectBtn.addEventListener("click", function () {
        const provider = providerSelect.value;
        const apiKey = document.getElementById("apiKey").value;
        const secretKey = document.getElementById("secretKey").value;
        errorMsg.classList.add("hidden");

        if (!provider || !apiKey || !secretKey) {
            errorMsg.textContent = "Please complete all fields.";
            errorMsg.classList.remove("hidden");
            return;
        }

        connectBtn.disabled = true;
        connectBtn.textContent = "Connect";

        fetch('/payment-processors/save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ provider, apiKey, secretKey })
        })
            .then(response => {
                connectBtn.disabled = false;
                connectBtn.textContent = "Connect";

                if (response.ok) {
                    connectionForm.classList.add('hidden');

                    const newConnection = document.createElement("div");
                    newConnection.classList.add("connection");
                    newConnection.innerHTML = `
                    <div class="connection-info">
                        <img src="/images/Stripelogo.png" class="connection-logo" alt="Stripe" />
                        <div class="connection-details">
                            <div class="connection-title">Your Business Name</div>
                            <div class="connection-processor">Stripe</div>
                        </div>
                    </div>
                    <button class="remove-btn" data-provider="${provider.toLowerCase()}_primary" onclick="deleteIntegration(this)">×</button>
                `;
                    const section = document.querySelector(".connection-form").parentElement;
                    section.insertBefore(newConnection, document.getElementById("add-connection-btn"));
                } else {
                    return response.text().then(msg => {
                        errorMsg.textContent = msg || "Failed to save credentials.";
                        errorMsg.classList.remove("hidden");
                    });
                }
            })
            .catch(() => {
                connectBtn.disabled = false;
                connectBtn.textContent = "Connect";
                errorMsg.textContent = "Something went wrong. Please try again.";
                errorMsg.classList.remove("hidden");
            });
    });

    window.deleteIntegration = function(button) {
        const provider = button.getAttribute("data-provider");
        if (!provider) return;

        fetch(`/payment-processors/delete/${provider}`, {
            method: 'DELETE'
        })
            .then(response => {
                if (response.ok) {
                    const card = button.closest(".connection");
                    if (card) card.remove();
                } else {
                    alert("Failed to delete integration.");
                }
            })
            .catch(() => alert("Error deleting integration."));
    };

    // Load Stripe connection if it exists
    fetch("/payment-processors/integrations")
        .then(res => res.ok ? res.json() : null)
        .then(data => {
            if (data && data.provider === "Stripe") {
                const existingCard = document.createElement("div");
                existingCard.classList.add("connection");
                existingCard.innerHTML = `
                    <div class="connection-info">
                        <img src="/images/Stripelogo.png" class="connection-logo" alt="Stripe" />
                        <div class="connection-details">
                            <div class="connection-title">Your Business Name</div>
                            <div class="connection-processor">Stripe</div>
                        </div>
                    </div>
                    <button class="remove-btn" data-provider="${data.alias}" onclick="deleteIntegration(this)">×</button>
                `;
                const section = document.querySelector(".connection-form").parentElement;
                section.insertBefore(existingCard, document.getElementById("add-connection-btn"));
            }
        });
});