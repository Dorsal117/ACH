CREATE TABLE stripe_api_key (
    id UUID PRIMARY KEY,
    encrypted_key TEXT NOT NULL,
    key_alias VARCHAR(50) NOT NULL UNIQUE
);