-- CREATE TABLE IF NOT EXISTS payment_intent (
  --  id UUID PRIMARY KEY,
   -- stripe_intent_id VARCHAR(100) NOT NULL UNIQUE,
   -- client_secret VARCHAR(255) NOT NULL,
   -- amount DECIMAL(19,4) NOT NULL,
    -- currency VARCHAR(3) NOT NULL,
   -- status VARCHAR(50),
-- captured BOOLEAN DEFAULT FALSE,
   -- error_message TEXT,
  --  payment_method_id VARCHAR(100),
  --  payment_id UUID,
  --  created_at TIMESTAMP NOT NULL,
   -- updated_at TIMESTAMP NOT NULL,
   -- CONSTRAINT fk_payment_intent_payment FOREIGN KEY (payment_id) REFERENCES payment(id)
--);


CREATE TABLE IF NOT EXISTS payment_intent (
    id BIGSERIAL PRIMARY KEY,
    amount_cents BIGINT NOT NULL,
    currency VARCHAR(3) NOT NULL, 
    status VARCHAR(50) NOT NULL,
    client_secret TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_payment_intent_status ON payment_intent(status);
CREATE INDEX IF NOT EXISTS idx_payment_intent_created_at ON payment_intent(created_at);