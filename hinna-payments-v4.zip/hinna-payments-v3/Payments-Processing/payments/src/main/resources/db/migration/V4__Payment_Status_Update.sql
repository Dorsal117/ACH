-- This would typically be a comment as PostgreSQL doesn't enforce enum values through constraints
-- Here we're creating a CHECK constraint to somewhat mimic enum validation

ALTER TABLE payment
DROP CONSTRAINT IF EXISTS check_payment_status;

ALTER TABLE payment
ADD CONSTRAINT check_payment_status
CHECK (status IN ('PENDING', 'PROCESSING', 'COMPLETED', 'FAILED', 'REFUNDED',
                 'PARTIAL_REFUNDED', 'CANCELLED', 'PENDING_APPROVAL', 'REJECTED'));

ALTER TABLE refund
DROP CONSTRAINT IF EXISTS check_refund_status;

ALTER TABLE refund
ADD CONSTRAINT check_refund_status
CHECK (status IN ('PENDING', 'PROCESSING', 'COMPLETED', 'FAILED', 'REFUNDED',
                 'PARTIAL_REFUNDED', 'CANCELLED', 'PENDING_APPROVAL', 'REJECTED'));