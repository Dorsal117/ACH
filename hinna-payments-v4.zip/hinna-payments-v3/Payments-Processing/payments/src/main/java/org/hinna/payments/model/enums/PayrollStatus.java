package org.hinna.payments.model.enums;

public enum PayrollStatus {
    SCHEDULED,    // Payment is scheduled but not yet processed
    PROCESSING,   // Payment is being processed
    COMPLETED,    // Payment has been successfully processed
    FAILED,       // Payment processing failed
    CANCELLED     // Payment was cancelled before processing
}
