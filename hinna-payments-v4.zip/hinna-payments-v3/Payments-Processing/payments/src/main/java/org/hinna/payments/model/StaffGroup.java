package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.*;

@Entity
@Table(name = "staff_group")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = {"permissions", "members"})
@EqualsAndHashCode(of = "id")
public class StaffGroup {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "group_name", nullable = false)
    private String groupName;

    private String description;

    @Column(name = "is_active")
    private boolean isActive = true;

    @Column(name = "admin_id")
    private UUID adminId;

    @ManyToMany
    @JoinTable(
            name = "staff_group_permission",
            joinColumns = @JoinColumn(name = "staff_group_id"),
            inverseJoinColumns = @JoinColumn(name = "permission_id")
    )
    private Set<Permission> permissions = new HashSet<>();

    @OneToMany(mappedBy = "staffGroup")
    private List<Staff> members = new ArrayList<>();

    public StaffGroup(String groupName) {
        this.groupName = groupName;
    }

    // Permission management methods
    public void addPermission(Permission permission) {
        permissions.add(permission);
    }

    public void removePermission(Permission permission) {
        permissions.remove(permission);
    }

    public boolean hasPermission(String permissionName) {
        return permissions.stream()
                .anyMatch(p -> p.getPermissionKey().equals(permissionName));
    }

    public boolean hasPermissionByKey(String resourceType, String action) {
        String key = resourceType + ":" + action;
        return permissions.stream()
                .anyMatch(p -> p.getPermissionKey().equals(key));
    }
}
