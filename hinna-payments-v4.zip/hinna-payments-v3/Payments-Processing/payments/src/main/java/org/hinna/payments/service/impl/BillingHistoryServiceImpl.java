package org.hinna.payments.service.impl;

import org.hinna.payments.model.Account;
import org.hinna.payments.model.BillingHistory;
import org.hinna.payments.model.Payment;
import org.hinna.payments.repository.BillingHistoryRepository;
import org.hinna.payments.service.BillingHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class BillingHistoryServiceImpl implements BillingHistoryService {

    private final BillingHistoryRepository billingHistoryRepository;

    @Autowired
    public BillingHistoryServiceImpl(BillingHistoryRepository billingHistoryRepository) {
        this.billingHistoryRepository = billingHistoryRepository;
    }

    @Override
    public BillingHistory createBillingRecord(BillingHistory billingHistory) {
        return billingHistoryRepository.save(billingHistory);
    }

    @Override
    public Optional<BillingHistory> getBillingRecordById(UUID id) {
        return billingHistoryRepository.findById(id);
    }

    @Override
    public Page<BillingHistory> getAllBillingRecords(Pageable pageable) {
        return billingHistoryRepository.findAll(pageable);
    }

    @Override
    public List<BillingHistory> getBillingRecordsByAccount(Account account) {
        return billingHistoryRepository.findByAccount(account);
    }

    @Override
    public List<BillingHistory> getBillingRecordsByPayment(Payment payment) {
        return billingHistoryRepository.findByPayment(payment);
    }

    @Override
    public List<BillingHistory> getBillingRecordsByDateRange(LocalDateTime start, LocalDateTime end) {
        return billingHistoryRepository.findByTransactionDateBetween(start, end);
    }

    @Override
    public List<BillingHistory> getBillingRecordsByType(String transactionType) {
        return billingHistoryRepository.findByTransactionType(transactionType);
    }

    @Override
    public List<BillingHistory> getRecentBillingRecords(Account account, int limit) {
        return billingHistoryRepository.findByAccountOrderByTransactionDateDesc(account)
                .stream()
                .limit(limit)
                .collect(Collectors.toList());
    }
}
