package org.hinna.payments.integration.booking.rest;

import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.integration.booking.dto.CreateServiceRequest;
import org.hinna.payments.model.Payment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
import java.util.UUID;

/**
 * REST controller for booking service integration.
 */
@RestController
@RequestMapping("/api/integration/booking")
@Slf4j
public class BookingRestController {

    private final BookingRestIntegrationService bookingRestIntegrationService;

    @Autowired
    public BookingRestController(BookingRestIntegrationService bookingRestIntegrationService) {
        this.bookingRestIntegrationService = bookingRestIntegrationService;
    }

    /**
     * Endpoint for booking service to notify of new bookings
     */
    @PostMapping("/webhooks/booking-created")
    public ResponseEntity<CommonResponse<Void>> bookingCreatedWebhook(@RequestBody CreateServiceRequest booking) {
        log.info("Received booking creation webhook for booking: {}", booking.getBusinessId());
        bookingRestIntegrationService.processBookingCreated(booking);

        CommonResponse<Void> response = new CommonResponse<>();
        response.setSuccess(true);
        response.setMessage("Booking processed successfully");
        response.setCode(200);

        return ResponseEntity.ok(response);
    }

    /**
     * Endpoint for booking service to notify of cancelled bookings
     */
    @PostMapping("/webhooks/booking-cancelled")
    public ResponseEntity<CommonResponse<Void>> bookingCancelledWebhook(
            @RequestParam String bookingKey,
            @RequestParam(required = false) String reason,
            @RequestParam(defaultValue = "false") boolean refundRequested) {

        log.info("Received booking cancellation webhook for booking key: {}", bookingKey);
        bookingRestIntegrationService.processBookingCancelled(bookingKey, reason, refundRequested);

        CommonResponse<Void> response = new CommonResponse<>();
        response.setSuccess(true);
        response.setMessage("Cancelled processed successfully");
        response.setCode(200);

        return ResponseEntity.ok(response);
    }

    /**
     * Manually trigger fetching and processing pending bookings
     */
    @PostMapping("/process-pending")
    public ResponseEntity<CommonResponse<Void>> processPendingBookings() {
        bookingRestIntegrationService.fetchAndProcessPendingBookings();

        CommonResponse<Void> response = new CommonResponse<>();
        response.setSuccess(true);
        response.setMessage("Pending bookings processed");
        response.setCode(200);

        return ResponseEntity.ok(response);
    }

    /**
     * Get the invoice ID for a booking
     */
    @GetMapping("/{bookingKey}/invoice")
    public ResponseEntity<?> getInvoiceForBooking(@PathVariable String bookingKey) {
        Optional<UUID> invoiceId = bookingRestIntegrationService.getInvoiceIdForBooking(bookingKey);

        if (invoiceId.isPresent()) {
            CommonResponse<UUID> response = new CommonResponse<>();
            response.setSuccess(true);
            response.setData(invoiceId.get());
            response.setCode(200);
            return ResponseEntity.ok(response);
        } else {
            CommonResponse<Void> response = new CommonResponse<>();
            response.setSuccess(false);
            response.setMessage("Invoice not found for booking key: " + bookingKey);
            response.setCode(404);
            return ResponseEntity.status(404).body(response);
        }
    }

    /**
     * Process payment for a booking
     */
    @PostMapping("/{bookingKey}/payment")
    public ResponseEntity<CommonResponse<Void>> processPayment(
            @PathVariable String bookingKey,
            @RequestBody Payment payment) {

        bookingRestIntegrationService.processPaymentForBooking(bookingKey, payment);

        CommonResponse<Void> response = new CommonResponse<>();
        response.setSuccess(true);
        response.setMessage("Payment processed successfully");
        response.setCode(200);

        return ResponseEntity.ok(response);
    }
}
