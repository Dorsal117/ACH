package org.hinna.payments.service;

import org.hinna.payments.model.DirectCustomer;
import org.hinna.payments.model.ResellerAccount;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface DirectCustomerService {
    DirectCustomer createDirectCustomer(DirectCustomer directCustomer);
    Optional<DirectCustomer> getDirectCustomerById(UUID id);
    Page<DirectCustomer> getAllDirectCustomers(Pageable pageable);
    List<DirectCustomer> getDirectCustomersByReseller(ResellerAccount reseller);
    List<DirectCustomer> getDirectCustomersByFamilyId(UUID familyId);
    DirectCustomer updateDirectCustomer(UUID id, DirectCustomer directCustomerDetails);
    void deleteDirectCustomer(UUID id);
    DirectCustomer addCredit(UUID customerId, BigDecimal amount);
    DirectCustomer useCredit(UUID customerId, BigDecimal amount);
    List<DirectCustomer> searchDirectCustomers(String searchTerm);
}
