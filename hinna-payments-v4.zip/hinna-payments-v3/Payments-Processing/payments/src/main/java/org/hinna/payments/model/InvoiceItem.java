package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.UUID;

@Entity
@Table(name = "invoice_item")
@Getter
@Setter
@NoArgsConstructor
public class InvoiceItem {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "invoice_id", nullable = false)
    private Invoice invoice;

    @Column(nullable = false)
    private String description;

    @Column(nullable = false)
    private int quantity;

    @Column(nullable = false)
    private BigDecimal price;

    @Column(nullable = false)
    private BigDecimal taxRate;

    @Column
    private String itemType;

    @Column
    private UUID itemId;

    @Column
    private UUID serviceId;

    public InvoiceItem(String description, int quantity, BigDecimal price, BigDecimal taxRate) {
        this.description = description;
        this.quantity = quantity;
        this.price = price;
        this.taxRate = taxRate;
    }

    /**
     * Get the total price for item (price * quantity)
     * @return The total price
     */
    @Transient
    public BigDecimal getTotal() {
        return price.multiply(new BigDecimal(quantity));
    }

    /**
     * Get the tax amount for item
     * @return The tax amount
     */
    @Transient
    public BigDecimal getTaxAmount() {
        return getTotal().multiply(taxRate).divide(new BigDecimal(100));
    }

    /**
     * Get the total including tax
     * @return The total including tax
     */
    @Transient
    public BigDecimal getTotalWithTax() {
        return getTotal().add(this.getTaxAmount());
    }

    /**
     * Create an invoice item for a service
     * @param description Service description
     * @param quantity Quantity
     * @param price Price per unit
     * @param taxRate Tax rate percentage
     * @param serviceId ID of the service
     * @return The invoice item
     */
    public static InvoiceItem createServiceItem(String description, int quantity, BigDecimal price, BigDecimal taxRate,
                                                UUID serviceId) {
        InvoiceItem item = new InvoiceItem(description, quantity, price, taxRate);
        item.setItemType("SERVICE");
        item.setServiceId(serviceId);
        return item;
    }

    /**
     * Create an invoice item for a product
     * @param description Product description
     * @param quantity Quantity
     * @param price Price per unit
     * @param taxRate Tax rate percentage
     * @param productId ID of the product
     * @return The invoice item
     */
    public static InvoiceItem createProductItem(String description, int quantity, BigDecimal price, BigDecimal taxRate, UUID productId) {
        InvoiceItem item = new InvoiceItem(description, quantity, price, taxRate);
        item.setItemType("PRODUCT");
        item.setItemId(productId);
        return item;
    }

}
