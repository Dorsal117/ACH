package org.hinna.payments.service.impl;

import com.stripe.exception.StripeException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.exception.PaymentProcessingException;
import org.hinna.payments.model.Account;
import org.hinna.payments.model.PaymentMethod;
import org.hinna.payments.repository.PaymentMethodRepository;
import org.hinna.payments.service.PaymentMethodService;
import org.hinna.payments.service.StripeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import org.springframework.dao.DataIntegrityViolationException;
import org.hinna.payments.model.enums.BankAccountVerificationMethod;
import org.hinna.payments.model.enums.BankAccountVerificationStatus;

import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class PaymentMethodServiceImpl implements PaymentMethodService {

    private final PaymentMethodRepository paymentMethodRepository;
    private final StripeService stripeService;

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    public PaymentMethodServiceImpl(PaymentMethodRepository paymentMethodRepository, StripeService stripeService) {
        this.paymentMethodRepository = paymentMethodRepository;
        this.stripeService = stripeService;
    }

    @Override
    @Transactional
    public PaymentMethod createPaymentMethod(PaymentMethod paymentMethod) {
        // If provider token found, enrich with Stripe data
        if (paymentMethod.getProviderToken() != null &&
                !paymentMethod.getProviderToken().trim().isEmpty() &&
                paymentMethod.getBrand() == null) {

            try {
                this.enrichWithStripeData(paymentMethod);
            } catch (Exception e) {
                log.warn("Could not enrich payment method with Stripe data: {}", e.getMessage());
                // Continue with enrichment - DON'T fail the entire operation
            }
        }

        // Basic validation
        if (!this.validatePaymentMethod(paymentMethod)) {
            throw new IllegalArgumentException("Invalid payment method");
        }

        // Set as default if first payment method
        List<PaymentMethod> existingMethods = paymentMethodRepository.findByOwner(paymentMethod.getOwner());
        if (existingMethods.isEmpty()) {
            paymentMethod.setIsDefault(true);
        }

        // If ACH, set verification status and active status
        if (paymentMethod.isAchBankAccount()) {
            paymentMethod.setBankVerificationStatus(
                    paymentMethod.isBankAccountVerified()
                            ? BankAccountVerificationStatus.VERIFIED
                            : BankAccountVerificationStatus.UNVERIFIED);
            paymentMethod.setIsActive(paymentMethod.isBankAccountVerified());
        }

        // Save with all enriched data
        return paymentMethodRepository.save(paymentMethod);
    }

    /**
     * Enrich payment method with data from Stripe
     */
    @Transactional
    public void enrichWithStripeData(PaymentMethod paymentMethod) throws StripeException {
        log.info("Enriching payment method with Stripe data for token: {}", paymentMethod.getProviderToken());

        // Retrieve payment method from Stripe
        com.stripe.model.PaymentMethod stripePaymentMethod = com.stripe.model.PaymentMethod
                .retrieve(paymentMethod.getProviderToken());

        // Extract brand info using StripeService
        stripeService.extractAndSetBrandStripe(paymentMethod, stripePaymentMethod);

        log.info("Successfully enriched payment method with brand: {}, walletType: {}",
                paymentMethod.getBrand(),
                paymentMethod.getWalletType());
    }

    @Override
    public Optional<PaymentMethod> getPaymentMethodById(UUID id) {
        return paymentMethodRepository.findById(id);
    }

    @Override
    public List<PaymentMethod> getPaymentMethodsByOwner(Account owner) {
        return paymentMethodRepository.findByOwner(owner);
    }

    @Override
    public List<PaymentMethod> getActivePaymentMethodsByOwner(Account owner) {
        return paymentMethodRepository.findByOwnerAndIsActiveTrue(owner);
    }

    @Override
    @Transactional
    public PaymentMethod updatePaymentMethod(UUID id, PaymentMethod paymentMethodDetails) {
        return paymentMethodRepository.findById(id)
                .map(existingMethod -> {
                    // Only update fields that should be updatable
                    existingMethod.setIsActive(paymentMethodDetails.getIsActive());
                    if (paymentMethodDetails.getIsDefault() && !existingMethod.getIsDefault()) {
                        // If this method is set to default, unset all others
                        setDefaultPaymentMethod(id, existingMethod.getOwner());
                    }
                    return paymentMethodRepository.save(existingMethod);
                })
                .orElseThrow(() -> new IllegalArgumentException("Payment method not found"));
    }

    /**
     * Delete a payment method for the whole system.
     * Finds the specific payment method record by ID.
     * Potentially communicates with the payment processor to delete the token.
     * If this is the default payment method, set another one as default (if
     * possible).
     * 
     * @param id payment method ID
     */
    @Override
@Transactional
public void deletePaymentMethod(UUID id) {
    Optional<PaymentMethod> methodOpt = paymentMethodRepository.findById(id);
    if (methodOpt.isEmpty()) {
        return; // already gone
    }

    PaymentMethod method = methodOpt.get();
    Account owner = method.getOwner();
    UUID methodId = method.getId();
    boolean wasDefault = Boolean.TRUE.equals(method.getIsDefault());

    // Try to detach in Stripe, but never fail because of it
    try {
        stripeService.deletePaymentMethod(method);
    } catch (Exception ex) {
        log.warn("Stripe delete failed for method {}: {}", methodId, ex.getMessage());
    }

    // Soft delete locally
    method.setIsActive(false);
    method.setIsDefault(false);
    method.setProviderToken(null);
    method.setBankVerificationStatus(BankAccountVerificationStatus.FAILED);
    paymentMethodRepository.saveAndFlush(method);

    if (wasDefault) {
        assignFallbackDefault(owner, methodId);
    }

    // Optionally, if you need to physically remove orphaned rows,
    // add a scheduled cleanup that runs only when no payments reference them.
}


    private void assignFallbackDefault(Account owner, UUID removedMethodId) {
        List<PaymentMethod> activeMethods = paymentMethodRepository.findByOwnerAndIsActiveTrue(owner);
        for (PaymentMethod candidate : activeMethods) {
            if (!candidate.getId().equals(removedMethodId)) {
                candidate.setIsDefault(true);
                paymentMethodRepository.save(candidate);
                return;
            }
        }
    }

    @Override
    @Transactional
    public void setDefaultPaymentMethod(UUID id, Account owner) {
        // Find the method to set as default
        PaymentMethod newDefault = paymentMethodRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Payment method not found"));

        if (!newDefault.getOwner().getId().equals(owner.getId())) {
            throw new IllegalArgumentException("Payment method does not belong to the specified owner");
        }

        // Unset all other default methods
        List<PaymentMethod> defaultMethods = paymentMethodRepository.findByOwnerAndIsDefaultTrue(owner);
        for (PaymentMethod method : defaultMethods) {
            method.setIsDefault(false);
            paymentMethodRepository.save(method);
        }

        // Set the new default method
        newDefault.setIsDefault(true);
        paymentMethodRepository.save(newDefault);
    }

    // @Override
    // public boolean validatePaymentMethod(PaymentMethod paymentMethod) {
    // Involves validating the token with Stripe
    // return stripeService.validatePaymentMethod(paymentMethod);
    /// }

    // FOR UNVERIFIED BANK ACCOUNTS CAN BE REJECTED
    @Override
    public boolean validatePaymentMethod(PaymentMethod paymentMethod) {
        if (paymentMethod == null || paymentMethod.getOwner() == null || paymentMethod.getType() == null) {
            return false;
        }
        if (paymentMethod.isAchBankAccount()) {
            return true; // allow ACH records to persist until verification completes
        }
        return stripeService.validatePaymentMethod(paymentMethod);
    }

    @Override
    public List<PaymentMethod> getExpiredPaymentMethods() {
        return paymentMethodRepository.findByExpiryDateBefore(LocalDate.now());
    }

    @Override
    @Transactional
    public void updatePaymentMethodPriorities(Account owner, List<UUID> orderedIds) {
        List<PaymentMethod> methods = paymentMethodRepository.findByOwner(owner);
        for (int i = 0; i < orderedIds.size(); i++) {
            UUID id = orderedIds.get(i);
            for (PaymentMethod method : methods) {
                if (method.getId().equals(id)) {
                    method.setPriority(i); // lower index = higher priority
                    paymentMethodRepository.save(method);
                    break;
                }
            }
        }
    }

    @Override
    @Transactional
    public boolean processPaymentWithFallback(Account owner, long amountInCents, String currency) {
        List<PaymentMethod> activeMethods = paymentMethodRepository.findByOwnerAndIsActiveTrue(owner);

        // Sort by priority (ascending: 0 is highest priority)
        activeMethods.sort(Comparator.comparingInt(a -> a.getPriority() != null ? a.getPriority() : Integer.MAX_VALUE));

        for (PaymentMethod method : activeMethods) {
            if (method.isExpired()) {
                continue; // Skip expired methods
            }

            try {
                // Try charging via Stripe
                boolean success = stripeService.charge(method, amountInCents, currency);
                if (success) {
                    // Record success (optional: save billing record)
                    return true;
                }
            } catch (Exception e) {
                // Log error, do not rethrow to allow fallback
                System.err.println("Payment failed for method: " + method.getId() + " Reason: " + e.getMessage());
            }
        }

        // All methods failed
        return false;
    }

    @Override
    @Transactional
    public PaymentMethod verifyAchMicroDeposits(UUID id, int firstAmount, int secondAmount) {
        PaymentMethod method = paymentMethodRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Payment method not found"));

        if (!method.isAchBankAccount()) {
            throw new IllegalArgumentException("Verification is only supported for ACH payment methods");
        }

        try {
            stripeService.verifyBankAccountMicroDeposits(
                    method.getProviderToken(),
                    firstAmount,
                    secondAmount);
        } catch (PaymentProcessingException ex) {
            throw new ResponseStatusException(org.springframework.http.HttpStatus.BAD_REQUEST, ex.getMessage(), ex);
        }

        stripeService.refreshBankAccountDetails(method);
        method.setBankVerificationStatus(BankAccountVerificationStatus.VERIFIED);
        method.setIsActive(true);
        method.setBankVerificationMethod(BankAccountVerificationMethod.MICRO_DEPOSIT);
        method.setBankLinkedAt(LocalDateTime.now());
        if (method.getBankVerifiedAt() == null) {
            method.setBankVerifiedAt(LocalDateTime.now());
        }

        return paymentMethodRepository.save(method);
    }

    @Override
    @Transactional
    public PaymentMethod refreshAchDetails(UUID id) {
        PaymentMethod method = paymentMethodRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Payment method not found"));

        if (!method.isAchBankAccount()) {
            return method;
        }

        stripeService.refreshBankAccountDetails(method);
        method.setIsActive(method.isBankAccountVerified());
        return paymentMethodRepository.save(method);
    }

}
