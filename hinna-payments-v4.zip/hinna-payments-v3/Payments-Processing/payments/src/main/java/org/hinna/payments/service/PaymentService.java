package org.hinna.payments.service;

import org.hinna.payments.model.*;
import org.hinna.payments.model.enums.PaymentStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface PaymentService {
    Payment createPayment(Payment payment);
    Optional<Payment> getPaymentById(UUID paymentId);
    Optional<Payment> getPaymentByReferenceNumber(String referenceNumber);
    Page<Payment> getAllPayments(Pageable pageable);
    List<Payment> getPaymentsByCustomer(Account customer);
    List<Payment> getPaymentsByStatus(PaymentStatus status);
    List<Payment> getPaymentsByMethod(PaymentMethod method);
    List<Payment> getPaymentsByDateRange(LocalDateTime start, LocalDateTime end);
    Payment processPayment(UUID id);
    Payment capturePayment(UUID id);
    Refund refundPayment(UUID id, BigDecimal amount, String reason);
    Payment cancelPayment(UUID id);
    List<Payment> searchPayments(String searchTerm);

    /**
     * Get paginated payments by customer
     */
    Page<Payment> getPaymentsByCustomer(Account customer, Pageable pageable);
}
