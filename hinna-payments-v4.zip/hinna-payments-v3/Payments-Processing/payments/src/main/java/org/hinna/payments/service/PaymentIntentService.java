package org.hinna.payments.service;

import org.hinna.payments.model.Account;
import org.hinna.payments.model.Payment;
import org.hinna.payments.model.PaymentIntent;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface PaymentIntentService {

    /**
     * Create a payment intent for a payment
     *
     * @param payment the payment to create an intent for
     * @return the created payment intent
     */
    PaymentIntent createPaymentIntent(Payment payment);

    /**
     * Get a payment intent by its ID
     *
     * @param id the payment intent ID
     * @return an Optional containing the payment intent if found
     */
    Optional<PaymentIntent> getPaymentIntentById(UUID id);

    /**
     * Get a payment intent by its Stripe ID
     *
     * @param stripeIntentId the Stripe payment intent ID
     * @return an Optional containing the payment intent if found
     */
    Optional<PaymentIntent> getPaymentIntentByStripeId(String stripeIntentId);

    /**
     * Update a payment intent's status
     *
     * @param stripeIntentId the Stripe payment intent ID
     * @param status the new status
     * @param errorMessage optional error message if the status change was due to an error
     * @return the updated payment intent
     */
    PaymentIntent updatePaymentIntentStatus(String stripeIntentId, String status, String errorMessage);

    /**
     * Confirm a payment intent
     *
     * @param stripeIntentId the Stripe payment intent ID
     * @return true if the confirmation was successful
     */
    boolean confirmPaymentIntent(String stripeIntentId);

    /**
     * Capture a payment intent
     *
     * @param stripeIntentId the Stripe payment intent ID
     * @return true if the capture was successful
     */
    boolean capturePaymentIntent(String stripeIntentId);

    /**
     * Cancel a payment intent
     *
     * @param stripeIntentId the Stripe payment intent ID
     * @param reason the reason for cancellation
     * @return true if the cancellation was successful
     */
    boolean cancelPaymentIntent(String stripeIntentId, String reason);

    /**
     * Get all payment intents for a customer
     *
     * @param customer the customer account
     * @return a list of payment intents
     */
    List<PaymentIntent> getPaymentIntentsByCustomer(Account customer);
}
