//package org.hinna.payments.service.impl;
//
//import lombok.extern.slf4j.Slf4j;
//import org.hinna.payments.dto.LessonPayrollDTO;
//import org.hinna.payments.integration.booking.service.BookingIntegrationService;
//import org.hinna.payments.integration.calendar.service.CalendarIntegrationService;
//import org.hinna.payments.integration.user.service.AccountSynchronizationService;
//import org.hinna.payments.model.enums.LessonCancellationReason;
//import org.hinna.payments.service.AccountService;
//import org.hinna.payments.service.LessonPayrollService;
//import org.hinna.payments.service.PayrollService;
//import org.springframework.amqp.rabbit.core.RabbitTemplate;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpMethod;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Service;
//import org.springframework.web.client.RestTemplate;
//
//import java.util.Map;
//import java.util.Optional;
//import java.util.UUID;
//
///**
// * Service for handling lesson-based payroll processing with microservice integration
// * Integrates with Booking, Calendar, User, and Service Builder microservices
// */
//@Service
//@Slf4j
//public class LessonPayrollServiceImpl implements LessonPayrollService {
//
//    private final PayrollService payrollService;
//    private final AccountService accountService;
//    private final BookingIntegrationService bookingIntegrationService;
//    private final CalendarIntegrationService calendarIntegrationService;
//    private final AccountSynchronizationService accountSynchronizationService;
//    private final RabbitTemplate rabbitTemplate;
//    private final RestTemplate restTemplate;
//
//    // Configuration for external service URLs
//    @Value("${hinna.integration.service-builder.base-url:http://localhost:8083}")
//    private String serviceBuilderBaseUrl;
//
//    @Value("${hinna.integration.booking.base-url:http://localhost:8082}")
//    private String bookingServiceBaseUrl;
//
//    @Value("${hinna.integration.calendar.base-url:http://localhost:8084}")
//    private String calendarServiceBaseUrl;
//
//    // RabbitMQ configuration
//    @Value("${hinna.rabbitmq.exchange:hinna.payments.exchange}")
//    private String paymentExchange;
//
//    @Value("${hinna.rabbitmq.payroll.routing-key:payroll.processed}")
//    private String payrollProcessedKey;
//
//
//    @Autowired
//    public LessonPayrollServiceImpl(PayrollService payrollService, AccountService accountService, BookingIntegrationService bookingIntegrationService, CalendarIntegrationService calendarIntegrationService, AccountSynchronizationService accountSynchronizationService, RabbitTemplate rabbitTemplate, RestTemplate restTemplate) {
//        this.payrollService = payrollService;
//        this.accountService = accountService;
//        this.bookingIntegrationService = bookingIntegrationService;
//        this.calendarIntegrationService = calendarIntegrationService;
//        this.accountSynchronizationService = accountSynchronizationService;
//        this.rabbitTemplate = rabbitTemplate;
//        this.restTemplate = restTemplate;
//    }
//
//    @Override
//    public void processLessonCancellationPayroll(UUID lessonId, LessonCancellationReason reason) {
//        log.info("Processing payroll for cancelled lesson: {} with reason: {}", lessonId, reason);
//
//        try {
//            // Get lesson information from integrated service
//            LessonPayrollDTO lessonInfo = this.get
//        }
//    }
//
//
//    private LessonPayrollDTO getLessonInformation(UUID lessonId) {
//        log.debug("Fetching lesson information for lessonId: {}", lessonId);
//
//        try {
//            // Create HTTP headers
//            HttpHeaders headers = new HttpHeaders();
//            headers.set("Content-Type", "application/json");
//            HttpEntity<Void> requestEntity = new HttpEntity<>(headers);
//
//            // First, try to get lesson details from Booking Service
//            ResponseEntity<Map> bookingResponse = restTemplate.exchange(
//                    bookingServiceBaseUrl + "/api/booking/lesson/" + lessonId,
//                    HttpMethod.GET,
//                    requestEntity,
//                    Map.class
//            );
//
//            Map<String, Object> bookingData = bookingResponse.getBody();
//            if (bookingData == null) {
//                throw new IllegalArgumentException("Lesson not found in booking service: " + lessonId);
//            }
//
//            // Get calendar information for scheduling details
//            Optional<String> eventId = calendarIntegrationService.getPaymentIdForEvent(lessonId.toString());
//
//            // Build lesson payroll DTO from multiple sources
//            LessonPayrollDTO lessonInfo = new LessonPayrollDTO();
//            lessonInfo.setLessonId(lessonId);
//            lessonInfo.setLessonTitle((String) bookingData.get("serviceType"));
//            lessonInfo.setStudentName((String) bookingData.get("customerName"));
//
//        }
//    }
//}
