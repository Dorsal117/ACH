package org.hinna.payments.repository;

import org.hinna.payments.model.PaymentIntegration;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PaymentIntegrationRepository extends JpaRepository<PaymentIntegration, Long> {
    Optional<PaymentIntegration> findByProvider(String provider);
}
