package org.hinna.payments.integration.calendar.config;

import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CalendarRabbitConfig {
    // Queue names
    public static final String CALENDAR_EVENT_QUEUE = "hinna.payment.calendar-event";
    public static final String PAYMENT_STATUS_QUEUE = "hinna.calendar.payment-status";

    // Exchange names
    public static final String CALENDAR_EXCHANGE = "hinna.calendar.exchange";
    public static final String PAYMENT_EXCHANGE = "hinna.payment.exchange";

    // Routing keys
    public static final String CALENDAR_EVENT_KEY = "calendar.event";
    public static final String PAYMENT_STATUS_KEY = "payment.status";

    // Queue definitions
    @Bean
    public Queue calendarEventQueue() {
        return QueueBuilder.durable(CALENDAR_EVENT_QUEUE).build();
    }

    @Bean
    public Queue paymentStatusQueue() {
        return QueueBuilder.durable(PAYMENT_STATUS_QUEUE).build();
    }

    // Exchange definitions
    @Bean
    public TopicExchange calendarExchange() {
        return ExchangeBuilder.topicExchange(CALENDAR_EXCHANGE).durable(true).build();
    }

    // Bindings
    @Bean
    public Binding calendarEventBinding() {
        return BindingBuilder.bind(calendarEventQueue())
                .to(calendarExchange())
                .with(CALENDAR_EVENT_KEY);
    }

    @Bean
    public Binding paymentStatusBinding() {
        return BindingBuilder.bind(paymentStatusQueue())
                .to(calendarExchange())
                .with(PAYMENT_STATUS_KEY);
    }
}
