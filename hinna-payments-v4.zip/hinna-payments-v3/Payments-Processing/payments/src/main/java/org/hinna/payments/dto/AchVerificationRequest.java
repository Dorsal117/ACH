package org.hinna.payments.dto;

import lombok.Data;

@Data
public class AchVerificationRequest {
    private int firstAmount;
    private int secondAmount;
}
