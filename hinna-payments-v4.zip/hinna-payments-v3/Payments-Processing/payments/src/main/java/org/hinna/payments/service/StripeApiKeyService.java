package org.hinna.payments.service;

import org.springframework.stereotype.Service;

@Service
public interface StripeApiKeyService {

    /**
     * Stores an encrypted version of the Stripe API key with a given alias.
     *
     * @param keyAlias Alias to reference the key
     * @param apiKey   The raw API key to store
     */
    void storeApiKey(String keyAlias, String apiKey);

    /**
     * Retrieves and decrypts the Stripe API key by its alias.
     *
     * @param keyAlias Alias of the key
     * @return Decrypted (plaintext) API key
     */
    String getDecryptedKey(String keyAlias);

    /**
     * Checks whether an API key alias already exists in the database.
     *
     * @param keyAlias Alias to check
     * @return true if the alias exists, false otherwise
     */
    boolean hasApiKeyAlias(String keyAlias);

    /**
     * Deletes an API key using its alias.
     *
     * @param keyAlias Alias to delete
     * @return true if deleted successfully
     */
    boolean deleteApiKey(String keyAlias);
}