package org.hinna.payments.dto;

import lombok.Data;
import org.hinna.payments.model.Account;

import java.util.UUID;

/**
 * Data Transfer Object for Account creation/update request
 */
@Data
public class AccountRequestDTO {
    private String firstName;
    private String lastName;
    private String email;
    private String address;
    private String mobilePhone;
    private String homePhone;
    private String dob;
    private String gender;
}
