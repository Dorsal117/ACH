package org.hinna.payments.security;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.ByteBuffer;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Utility class for encrypting and decrypting sensitive data using AES encryption.
 * Hai: Improved implementation with secure initialization vector (IV) handling.
 */
public class EncryptionUtil {
    private static final String ENCRYPTION_ALGO = "AES/GCM/NoPadding";
    private static final int TAG_LENGTH_BIT = 128;
    private static final int IV_LENGTH_BYTE = 12; // GCM recommended IV length

    private final SecretKeySpec keySpec;
    private final SecureRandom secureRandom;

    /**
     * Initializes the encryption utility with the provided encryption key.
     * Hai: The key should be a 32-character (256-bit) hexadecimal string.
     *
     * @param secretKeyHex A 32-character hexadecimal string (256-bit key) for AES encryption
     */
    public EncryptionUtil(String secretKeyHex) {
        try {
            byte[] keyBytes;

            // If the key is in hexadecimal format (recommended)
            if (secretKeyHex.matches("^[0-9a-fA-F]{32}$")) {
                keyBytes = this.hexStringToByteArray(secretKeyHex);
            }
            // If it's a 16-character string, use it directly (less secure, for backward compatibility)
            else if (secretKeyHex.length() == 16) {
                keyBytes = secretKeyHex.getBytes();
            }
            // Otherwise, derive a key using secure hashing
            else {
                KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
                keyGenerator.init(256); // Use AES-256
                SecretKey secretKey = keyGenerator.generateKey();
                keyBytes = secretKey.getEncoded();
            }

            this.keySpec = new SecretKeySpec(keyBytes, "AES");
            this.secureRandom = new SecureRandom();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Failed to initialize encryption utility", e);
        }
    }

    /**
     * Encrypts the given plaintext string using AES-GCM and encodes it as Base64.
     * A new random IV is generated for each encryption.
     *
     * @param plaintext The string to encrypt
     * @return Base64-encoded encrypted string with IV prefixed
     */
    public String encrypt(String plaintext) throws Exception {
        // Generate a new random IV for each encryption
        byte[] iv = new byte[IV_LENGTH_BYTE];
        secureRandom.nextBytes(iv);

        Cipher cipher = Cipher.getInstance(ENCRYPTION_ALGO);
        GCMParameterSpec parameterSpec = new GCMParameterSpec(TAG_LENGTH_BIT, iv);

        cipher.init(Cipher.ENCRYPT_MODE, keySpec, parameterSpec);
        byte[] encrypted = cipher.doFinal(plaintext.getBytes());

        // Combine IV and encrypted part
        ByteBuffer byteBuffer = ByteBuffer.allocate(iv.length + encrypted.length);
        byteBuffer.put(iv);
        byteBuffer.put(encrypted);

        return Base64.getEncoder().encodeToString(byteBuffer.array());
    }

    /**
     * Decrypts the given Base64-encoded string back to plaintext.
     * The IV is extracted from the beginning of the decoded ciphertext.
     *
     * @param ciphertext Base64-encoded encrypted string with IV prefixed
     * @return The decrypted plaintext
     */
    public String decrypt(String ciphertext) throws Exception {
        byte[] decoded = Base64.getDecoder().decode(ciphertext);

        // Extract IV
        ByteBuffer byteBuffer = ByteBuffer.wrap(decoded);
        byte[] iv = new byte[IV_LENGTH_BYTE];
        byteBuffer.get(iv);

        // Extract encrypted part
        byte[] encryptedBytes = new byte[byteBuffer.remaining()];
        byteBuffer.get(encryptedBytes);

        // Decrypt
        Cipher cipher = Cipher.getInstance(ENCRYPTION_ALGO);
        GCMParameterSpec parameterSpec = new GCMParameterSpec(TAG_LENGTH_BIT, iv);

        cipher.init(Cipher.DECRYPT_MODE, keySpec, parameterSpec);
        byte[] decrypted = cipher.doFinal(encryptedBytes);

        return new String(decrypted);
    }

    /**
     * Converts a hexadecimal string to a byte array.
     *
     * @param hex The hexadecimal string
     * @return The byte array
     */
    private byte[] hexStringToByteArray(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                    + Character.digit(hex.charAt(i+1), 16));
        }
        return data;
    }
}
