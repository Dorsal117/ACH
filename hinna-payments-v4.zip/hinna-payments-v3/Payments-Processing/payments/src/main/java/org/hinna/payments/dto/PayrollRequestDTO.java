package org.hinna.payments.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hinna.payments.model.enums.LessonCancellationReason;
import org.hinna.payments.model.enums.PayrollTriggerType;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * DTO for creating a new payroll
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PayrollRequestDTO {
    private UUID employeeId;
    private UUID processingAccountId;
    private UUID paymentMethodId;
    private BigDecimal grossAmount;
    private BigDecimal taxWithheld;
    private BigDecimal deductions;
    private String description;
    private LocalDateTime payPeriodStart;
    private LocalDateTime payPeriodEnd;
    private LocalDateTime scheduledDate;
    private boolean isAutomatic;
    private boolean isAchEnabled;

    // Lesson-related fields
    private UUID lessonId;
    private UUID bookingId;
    private PayrollTriggerType triggerType;
    private LessonCancellationReason cancellationReason;
    private boolean isSubstitutePayment;
    private UUID originalTeacherId;
    private UUID substituteTeacherId;
    private BigDecimal originalRate;
    private BigDecimal adjustedRate;
    private String rateAdjustmentReason;

    // Static factory methods for different scenarios
    public static PayrollRequestDTO forLessonCancellation(UUID lessonId, UUID teacherId,
                                                          LessonCancellationReason reason) {
        PayrollRequestDTO dto = new PayrollRequestDTO();
        dto.setLessonId(lessonId);
        dto.setEmployeeId(teacherId);
        dto.setTriggerType(PayrollTriggerType.LESSON_CANCELLATION);
        dto.setCancellationReason(reason);
        return dto;
    }

    public static PayrollRequestDTO forSubstitutePayment(UUID lessonId, UUID originalTeacherId,
                                                         UUID substituteId, BigDecimal substituteRate) {
        PayrollRequestDTO dto = new PayrollRequestDTO();
        dto.setLessonId(lessonId);
        dto.setOriginalTeacherId(originalTeacherId);
        dto.setEmployeeId(substituteId);
        dto.setTriggerType(PayrollTriggerType.SUBSTITUTE_PAYMENT);
        dto.setSubstitutePayment(true);
        dto.setGrossAmount(substituteRate);
        return dto;
    }

    public static PayrollRequestDTO forAdjustedTeacherPayment(UUID lessonId, UUID teacherId,
                                                              BigDecimal originalRate, BigDecimal adjustedRate,
                                                              String adjustmentReason) {
        PayrollRequestDTO dto = new PayrollRequestDTO();
        dto.setLessonId(lessonId);
        dto.setEmployeeId(teacherId);
        dto.setTriggerType(PayrollTriggerType.ADJUSTED_PAYMENT);
        dto.setOriginalRate(originalRate);
        dto.setAdjustedRate(adjustedRate);
        dto.setGrossAmount(adjustedRate);
        dto.setRateAdjustmentReason(adjustmentReason);
        return dto;
    }
}
