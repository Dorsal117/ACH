package org.hinna.payments.repository;

import java.time.LocalDate;
import java.util.UUID;
import java.util.List;

import org.hinna.payments.model.LocationTaxRule;
import org.hinna.payments.model.Tax;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface LocationTaxRuleRepository extends JpaRepository<LocationTaxRule, UUID> {

    
    /**
     * Returns active taxes for a given location and date.
     */
   @Query("""
        SELECT r.tax FROM LocationTaxRule r 
        WHERE r.location.id = :locationId 
          AND r.applicableFrom <= :date 
          AND (r.applicableTo IS NULL OR r.applicableTo >= :date)
          AND r.isActive = true
    """)
    List<Tax> findActiveTaxesByLocationAndDate(@Param("locationId") UUID locationId, @Param("date") LocalDate date);
    
    /**
     * Returns active tax rules (for detailed application, including compound logic).
     * Sorted by isCompound to ensure non-compound taxes are applied first.
     */                                            
    @Query("""
        SELECT r FROM LocationTaxRule r 
        WHERE r.location.id = :locationId 
          AND r.applicableFrom <= :date 
          AND (r.applicableTo IS NULL OR r.applicableTo >= :date)
          AND r.isActive = true
        ORDER BY r.tax.isCompound ASC
    """)
    List<LocationTaxRule> findActiveRulesByLocationAndDate(@Param("locationId") UUID locationId, @Param("date") LocalDate date); 
}
