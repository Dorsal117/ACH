package org.hinna.payments.service.impl;

import com.stripe.Stripe;
import com.stripe.exception.SignatureVerificationException;
import com.stripe.exception.StripeException;
import com.stripe.model.*;
import com.stripe.model.PaymentIntent;
import com.stripe.net.ApiRequest;
import com.stripe.net.ApiResource;
import com.stripe.net.BaseAddress;
import com.stripe.net.Webhook;
import com.stripe.param.*;
import jakarta.annotation.PostConstruct;
import jakarta.transaction.Transactional;
import org.hinna.payments.dto.ValidationResult;
import org.hinna.payments.exception.PaymentProcessingException;
import org.hinna.payments.model.*;
import org.hinna.payments.model.Account;
import org.hinna.payments.model.PaymentMethod;
import org.hinna.payments.model.enums.BankAccountVerificationStatus;
import org.hinna.payments.model.enums.PaymentType;
import org.hinna.payments.repository.StripeCustomerRepository;
import org.hinna.payments.service.StripeApiKeyService;
import org.hinna.payments.service.StripeService;
import org.hinna.payments.service.stripe.StripeKeyValidationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;


@Service
public class StripeServiceImpl implements StripeService {

    private static final Logger logger = LoggerFactory.getLogger(StripeServiceImpl.class);

    @Value("${stripe.api.key.alias:default}")
    private String apiKeyAlias;

    @Value("${stripe.webhook.secret.alias:webhook}")
    private String webhookSecretAlias;

    @Value("${stripe.currency:cad}")
    private String defaultCurrency;

    private final StripeCustomerRepository stripeCustomerRepository;
    private final StripeKeyValidationService stripeKeyValidationService;
    private final StripeApiKeyService stripeApiKeyService;

    private String webhookSecret;

    @Autowired
    public StripeServiceImpl(StripeCustomerRepository stripeCustomerRepository,
            StripeKeyValidationService stripeKeyValidationService, StripeApiKeyService stripeApiKeyService) {
        this.stripeCustomerRepository = stripeCustomerRepository;
        this.stripeKeyValidationService = stripeKeyValidationService;
        this.stripeApiKeyService = stripeApiKeyService;
    }

    /**
     * Initialize Stripe with securely stored API key
     */
    @PostConstruct
    public void init() {
        try {
            // Get the API key securely from the service
            String apiKey = stripeApiKeyService.getDecryptedKey(apiKeyAlias);
            logger.info("Initializing Stripe with API key from secure storage");
            Stripe.apiKey = apiKey;

            // Get the webhook secret
            this.webhookSecret = stripeApiKeyService.getDecryptedKey(webhookSecretAlias);
        } catch (Exception e) {
            logger.error("Failed to initialize Stripe with secure API key: {}", e.getMessage());
            logger.warn("Stripe functionality may be limited until API keys are properly configured");
        }
    }

    @Override
    public ValidationResult validateStripeKey(String apiKey) {
        // Delegate to the dedicated validation service
        return stripeKeyValidationService.validateStripeKey(apiKey);
    }

    @Override
    public ValidationResult performFullTest(String apiKey) {
        // Delegate to the dedicated validation service
        return stripeKeyValidationService.performFullTest(apiKey);
    }

    /**
     * Securely store a Stripe API key
     *
     * @param alias  The alias for the key
     * @param apiKey The API key to store
     * @return ValidationResult with success status and message
     */
    public ValidationResult storeAndValidateApiKey(String alias, String apiKey) {
        // First validate the key
        ValidationResult result = validateStripeKey(apiKey);

        if (result.isValid()) {
            try {
                // If valid, store it securely
                stripeApiKeyService.storeApiKey(alias, apiKey);

                // If this is the main API key, update Stripe.apiKey
                if (alias.equals(apiKeyAlias)) {
                    Stripe.apiKey = apiKey;
                }

                // If this is the webhook secret, update our instance variable
                if (alias.equals(webhookSecretAlias)) {
                    this.webhookSecret = apiKey;
                }

                return new ValidationResult(true, "API key validated and stored securely as '" + alias + "'");
            } catch (Exception e) {
                logger.error("Failed to store API key: {}", e.getMessage());
                return new ValidationResult(false, "API key is valid but could not be stored: " + e.getMessage());
            }
        }

        return result;
    }

    @Override
    @Transactional
    public String createCustomer(Account account) {
        try {
            // Check if customer already exists
            Optional<StripeCustomer> existingStripeCustomer = stripeCustomerRepository.findByAccount(account);
            if (existingStripeCustomer.isPresent()) {
                return existingStripeCustomer.get().getStripeCustomerId();
            }

            // Create params for new customer
            CustomerCreateParams params = CustomerCreateParams.builder()
                    .setName(account.getFullName())
                    .setEmail(account.getEmail())
                    .setPhone(account.getMobilePhone())
                    .setDescription("Customer for " + account.getEmail())
                    .putMetadata("accountId", account.getId().toString())
                    .build();

            // Create customer in Stripe
            Customer customer = Customer.create(params);

            // Save customer in the database
            StripeCustomer stripeCustomer = new StripeCustomer(account, customer.getId());
            stripeCustomerRepository.save(stripeCustomer);

            logger.info("Created Stripe customer {} for account {}", customer.getId(), account.getId());

            return customer.getId();
        } catch (StripeException e) {
            logger.error("Error creating Stripe customer: {}", e.getMessage());
            throw new RuntimeException("Failed to create Stripe customer: {}" + e.getMessage(), e);
        }
    }

    @Override
    @Transactional
    public String updateCustomer(Account account) {
        String customerId = getOrCreateCustomer(account);

        try {
            logger.info("Updating Stripe customer {} for account {}", customerId, account.getId());

            CustomerUpdateParams params = CustomerUpdateParams.builder()
                    .setName(account.getFullName())
                    .setEmail(account.getEmail())
                    .setPhone(account.getMobilePhone())
                    .build();

            Customer customer = Customer.retrieve(customerId);
            customer.update(params);

            return customerId;
        } catch (StripeException e) {
            logger.error("Error updating Stripe customer: {}", e.getMessage());
            throw new PaymentProcessingException("Failed to update Stripe customer: " + e.getMessage(), e);
        }
    }

    @Override
    @Transactional
    public String getOrCreateCustomer(Account account) {
        // Check if the account already has a Stripe customer ID
        Optional<StripeCustomer> stripeCustomer = stripeCustomerRepository.findByAccount(account);

        // If customer exists, return ID
        if (stripeCustomer.isPresent()) {
            return stripeCustomer.get().getStripeCustomerId();
        }

        // Otherwise create new customer
        return this.createCustomer(account);
    }

    @Override
    @Transactional
    public String createPaymentIntent(Payment payment) {
        try {
            // Get or create Stripe customer
            String customerId = getOrCreateCustomer(payment.getCustomer());

            logger.info("Creating payment intent for customer {} with amount {}",
                    customerId, payment.getAmount());

            // Convert amount to cents (Stripe uses smallest currency unit)
            long amountInCents = payment.getAmount().multiply(new BigDecimal(100)).longValue();
            PaymentMethod method = payment.getMethod();
            boolean isAch = method != null && method.isAchBankAccount();
            String currency = payment.getCurrency() != null
                    ? payment.getCurrency().toLowerCase()
                    : defaultCurrency;
            if (isAch) {
                currency = "usd";
            }

            PaymentIntentCreateParams.Builder paramsBuilder = PaymentIntentCreateParams.builder()
                    .setAmount(amountInCents)
                    .setCurrency(currency)
                    .setCustomer(customerId)
                    .setDescription(payment.getDescription() != null ? payment.getDescription()
                            : "Payment for " + payment.getCustomer().getFullName())
                    .putMetadata("payment_id", payment.getId().toString());

            if (isAch) {
                if (method.getProviderToken() == null || method.getProviderToken().isBlank()) {
                    throw new PaymentProcessingException("ACH payment method is missing Stripe token");
                }
                paramsBuilder
                        .setPaymentMethod(method.getProviderToken())
                        .addPaymentMethodType("us_bank_account")
                        .setConfirmationMethod(PaymentIntentCreateParams.ConfirmationMethod.AUTOMATIC)
                        .setConfirm(true)
                        .setPaymentMethodOptions(PaymentIntentCreateParams.PaymentMethodOptions.builder()
                                .setUsBankAccount(
                                        PaymentIntentCreateParams.PaymentMethodOptions.UsBankAccount.builder()
                                                .setVerificationMethod(
                                                        PaymentIntentCreateParams.PaymentMethodOptions.UsBankAccount.VerificationMethod.AUTOMATIC)
                                                .build())
                                .build());
            } else {
                paramsBuilder.setCaptureMethod(PaymentIntentCreateParams.CaptureMethod.MANUAL);
            }

            // Create payment intent params
            PaymentIntentCreateParams params = paramsBuilder.build();

            // Create payment intent in Stripe
            PaymentIntent paymentIntent = PaymentIntent.create(params);

            // Store payment intent ID in payment's reference number
            payment.setReferenceNumber(paymentIntent.getId());

            return paymentIntent.getClientSecret();
        } catch (StripeException e) {
            logger.error("Error creating Stripe payment intent: {}", e.getMessage());
            throw new PaymentProcessingException("Failed to create Stripe payment intent: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean confirmPaymentIntent(String paymentIntentId) {
        try {
            logger.info("Confirming payment intent {}", paymentIntentId);

            PaymentIntent intent = PaymentIntent.retrieve(paymentIntentId);
            PaymentIntentConfirmParams params = PaymentIntentConfirmParams.builder().build();

            PaymentIntent confirmedIntent = intent.confirm(params);
            return "requires_capture".equals(confirmedIntent.getStatus()) ||
                    "succeeded".equals(confirmedIntent.getStatus());
        } catch (StripeException e) {
            logger.error("Error confirming payment intent: {}", e.getMessage());
            throw new PaymentProcessingException("Failed to confirm payment intent: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean capturePaymentIntent(String paymentIntentId) {
        try {
            logger.info("Capturing payment intent {}", paymentIntentId);

            PaymentIntent intent = PaymentIntent.retrieve(paymentIntentId);
            PaymentIntentCaptureParams params = PaymentIntentCaptureParams.builder().build();

            PaymentIntent capturedIntent = intent.capture(params);
            return "succeeded".equals(capturedIntent.getStatus());
        } catch (StripeException e) {
            logger.error("Error capturing payment intent: {}", e.getMessage());
            throw new PaymentProcessingException("Failed to capture payment intent: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean cancelPaymentIntent(String paymentIntentId, String reason) {
        try {
            logger.info("Cancelling payment intent {} with reason: {}", paymentIntentId, reason);

            PaymentIntent intent = PaymentIntent.retrieve(paymentIntentId);
            PaymentIntentCancelParams.Builder paramsBuilder = PaymentIntentCancelParams.builder();

            if (reason != null && !reason.isEmpty()) {
                try {
                    paramsBuilder.setCancellationReason(
                            PaymentIntentCancelParams.CancellationReason.valueOf(reason.toUpperCase()));
                } catch (IllegalArgumentException e) {
                    logger.warn("Invalid cancellation reason: {}, using default", reason);
                }
            }

            PaymentIntent cancelledIntent = intent.cancel(paramsBuilder.build());
            return "canceled".equals(cancelledIntent.getStatus());
        } catch (StripeException e) {
            logger.error("Error cancelling payment intent: {}", e.getMessage());
            throw new PaymentProcessingException("Failed to cancel payment intent: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean processPayment(Payment payment) {
        try {
            // Check if we have a payment intent ID
            if (payment.getReferenceNumber() == null || payment.getReferenceNumber().isEmpty()) {
                logger.error("No payment intent ID found for payment: {}", payment.getId());
                return false;
            }

            // Get payment intent
            PaymentIntent intent = PaymentIntent.retrieve(payment.getReferenceNumber());
            PaymentMethod method = payment.getMethod();
            boolean isAch = method != null && method.isAchBankAccount();

            // Check if it needs to be confirmed
            if ("requires_confirmation".equals(intent.getStatus())) {
                PaymentIntentConfirmParams.Builder confirmBuilder = PaymentIntentConfirmParams.builder();
                if (isAch && method != null && method.getProviderToken() != null) {
                    confirmBuilder.setPaymentMethod(method.getProviderToken());
                }
                intent = intent.confirm(confirmBuilder.build());
            }

            if (isAch) {
                String status = intent.getStatus();
                if ("processing".equals(status) || "requires_action".equals(status) || "succeeded".equals(status)) {
                    logger.info("ACH payment intent {} in status {}", intent.getId(), status);
                    return true;
                }
                logger.warn("ACH payment intent {} returned status {}", intent.getId(), status);
                return false;
            }

            // Check if it needs to be captured
            if ("requires_capture".equals(intent.getStatus())) {
                intent = intent.capture();
            }

            // Check if payment succeeded
            return "succeeded".equals(intent.getStatus());

        } catch (StripeException e) {
            logger.error("Error processing payment through Stripe: {}", e.getMessage());
            throw new PaymentProcessingException("Failed to process payment: " + e.getMessage());
        }

    }

    @Override
    public boolean processRefund(Payment payment, BigDecimal amount) {
        try {
            // Get the payment intent ID from the payment's provider reference
            String paymentIntentId = payment.getReferenceNumber();
            if (paymentIntentId == null || paymentIntentId.isEmpty()) {
                logger.error("No payment intent ID found for payment {}", payment.getId());
                return false;
            }

            logger.info("Processing refund for payment {} with amount {}", payment.getId(), amount);

            // Build refund params
            RefundCreateParams.Builder paramsBuilder = RefundCreateParams.builder()
                    .setPaymentIntent(paymentIntentId);

            // Add amount if partial refund
            if (amount != null && amount.compareTo(payment.getAmount()) < 0) {
                // Convert to cents
                long amountInCents = amount.multiply(new BigDecimal(100)).longValue();
                paramsBuilder.setAmount(amountInCents);
            }

            // Create refund in Stripe
            com.stripe.model.Refund stripeRefund = com.stripe.model.Refund.create(paramsBuilder.build());

            return "succeeded".equals(stripeRefund.getStatus());
        } catch (StripeException e) {
            logger.error("Error processing Stripe refund", e);
            throw new RuntimeException("Failed to process Stripe refund", e);
        }
    }

    @Override
    public String createSetupIntent(Account account) {
        try {
            // Get or create Stripe customer
            String customerId = this.getStripeCustomerId(account);

            logger.info("Creating setup intent for customer {}", customerId);

            // Create setup intent params
            SetupIntentCreateParams params = SetupIntentCreateParams.builder()
                    .setCustomer(customerId)
                    .setUsage(SetupIntentCreateParams.Usage.OFF_SESSION)
                    .build();

            // Create setup intent in Stripe
            SetupIntent setupIntent = SetupIntent.create(params);

            return setupIntent.getClientSecret();
        } catch (StripeException e) {
            logger.error("Error creating Stripe setup intent", e);
            throw new RuntimeException("Failed to create Stripe setup intent", e);
        }
    }

    @Override
    public boolean attachPaymentMethod(String paymentMethodId, Account account) {
        try {
            // Get or create Stripe customer
            String customerId = this.getStripeCustomerId(account);

            logger.info("Attaching payment method {} to customer {}", paymentMethodId, customerId);

            // Attach payment method to customer
            com.stripe.model.PaymentMethod paymentMethod = com.stripe.model.PaymentMethod.retrieve(paymentMethodId);
            PaymentMethodAttachParams params = PaymentMethodAttachParams.builder()
                    .setCustomer(customerId)
                    .build();
            paymentMethod.attach(params);

            return true;
        } catch (StripeException e) {
            logger.error("Error attaching payment method to customer", e);
            throw new RuntimeException("Failed to attach payment method to customer", e);
        }
    }

    @Override
    public boolean validatePaymentMethod(PaymentMethod paymentMethod) {
        return paymentMethod != null &&
                paymentMethod.getIsActive() &&
                paymentMethod.getOwner() != null &&
                paymentMethod.getType() != null;
    }

    @Override
    public void deletePaymentMethod(PaymentMethod paymentMethod) {
        try {
            // If there is a provider token, detach it from Stripe
            if (paymentMethod.getProviderToken() != null && !paymentMethod.getProviderToken().isEmpty()) {

                // Check if it's a payment method ID (pm_xxx) or a token (tok_xxx)
                if (paymentMethod.getProviderToken().startsWith("pm_")) {
                    logger.info("Detaching payment method {} from Stripe", paymentMethod.getProviderToken());

                    com.stripe.model.PaymentMethod stripePaymentMethod = com.stripe.model.PaymentMethod.retrieve(
                            paymentMethod.getProviderToken());
                    stripePaymentMethod.detach();

                    logger.info("Successfully detached payment method: {}", paymentMethod.getProviderToken());
                } else if (paymentMethod.getProviderToken().startsWith("tok_")) {
                    logger.info("Payment method {} is a token, no need to detach from Stripe",
                            paymentMethod.getProviderToken());
                    // Tokens cannot be detached as they are single-use objects
                } else {
                    logger.warn("Unknown provider token format: {}", paymentMethod.getProviderToken());
                }
            } else {
                logger.warn("No provider found for payment method: {}", paymentMethod.getProviderToken());
            }
        } catch (StripeException e) {
            logger.error("Error deleting Stripe payment method: {}", paymentMethod.getProviderToken(), e);
            // Don't throw exception <- we still want to allow the database deletion to
            // proceed
            // The calling service will handle the database cleanup
            // throw new RuntimeException("Failed to delete Stripe payment method", e);
        }
    }

    @Override
    public boolean verifyWebhookSignature(String payload, String sigHeader) {
        try {
            Webhook.constructEvent(payload, sigHeader, webhookSecret);
            return true;
        } catch (SignatureVerificationException e) {
            logger.error("Invalid webhook signature: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Helper method to get Stripe customer ID
     */
    private String getStripeCustomerId(Account account) {
        Optional<StripeCustomer> stripeCustomer = stripeCustomerRepository.findByAccount(account);

        // If customer exists, return ID
        if (stripeCustomer.isPresent()) {
            return stripeCustomer.get().getStripeCustomerId();
        }

        // Otherwise create new customer
        return this.createCustomer(account);
    }

    // used for fallback
    @Override
    public boolean charge(PaymentMethod method, long amountInCents, String currency) {
        try {
            com.stripe.model.PaymentMethod stripePaymentMethod = com.stripe.model.PaymentMethod
                    .retrieve(method.getProviderToken());

            PaymentIntentCreateParams params = PaymentIntentCreateParams.builder()
                    .setAmount(amountInCents)
                    .setCurrency(currency)
                    .setPaymentMethod(stripePaymentMethod.getId())
                    .setConfirm(true)
                    .setConfirmationMethod(PaymentIntentCreateParams.ConfirmationMethod.MANUAL)
                    .putMetadata("payment_method_id", method.getId().toString())
                    .build();

            PaymentIntent intent = PaymentIntent.create(params);
            return "succeeded".equals(intent.getStatus());
        } catch (StripeException e) {
            logger.error("Stripe charge failed", e);
            return false;
        }
    }

    /**
     * Extract brand and other details from Stripe payment method
     */
    @Override
    public void extractAndSetBrandStripe(PaymentMethod paymentMethod,
            com.stripe.model.PaymentMethod stripePaymentMethod) {
        String stripeType = stripePaymentMethod.getType();

        logger.info("Extracting brand information from Stripe payment method type:");

        switch (stripeType) {
            case "card" -> {
                var card = stripePaymentMethod.getCard();
                if (card == null)
                    break;
                paymentMethod.setBrand(card.getBrand());
                paymentMethod.setLastFourDigits(card.getLast4());
                paymentMethod.setExpiryDate(this.toExpiry(card.getExpMonth(), card.getExpYear()));
                if (card.getWallet() != null) {
                    String wallet = card.getWallet().getType();
                    paymentMethod.setWalletType(wallet);
                    paymentMethod.setType(wallet.equals("apple_pay")
                            ? PaymentType.APPLE_PAY
                            : wallet.equals("google_pay")
                                    ? PaymentType.GOOGLE_PAY
                                    : PaymentType.CREDIT_CARD);
                } else {
                    paymentMethod.setType(PaymentType.CREDIT_CARD);
                }
                logger.info("Card details: brand={}, last4={}, expires={}",
                        paymentMethod.getBrand(),
                        paymentMethod.getLastFourDigits(),
                        paymentMethod.getExpiryDate());
            }

            case "us_bank_account", "sepa_debit", "bankcontact", "ideal", "sofort" -> {
                paymentMethod.setType(PaymentType.BANK_TRANSFER);
                paymentMethod.setBrand(stripeType);
                paymentMethod.setLastFourDigits(
                        switch (stripeType) {
                            case "us_bank_account" -> stripePaymentMethod.getUsBankAccount().getLast4();
                            case "sepa_debit" -> stripePaymentMethod.getSepaDebit().getLast4();
                            default -> null;
                        });
                logger.info("Bank transfer method: {}", stripeType);
            }

            case "paypal" -> {
                paymentMethod.setType(PaymentType.PAYPAL);
                paymentMethod.setBrand("paypal");
                logger.info("PayPal method");
            }

            default -> logger.warn("Unhandled Stripe Payment Method type: {}", stripeType);
        }
    }

    private LocalDateTime toExpiry(Long month, Long year) {
        if (month == null || year == null)
            return null;
        return LocalDate.of(year.intValue(), month.intValue(), 1)
                .plusMonths(1)
                .minusDays(1)
                .atStartOfDay();
    }

    /**
     * Process an outgoing payment via Stripe
     * Handles transferring funds to an employee
     *
     * @param payroll The payroll payment to process
     * @return true if the payment was successful, false otherwise
     */
    @Override
    public boolean processOutgoingPayment(Payroll payroll) {
        Staff employee = payroll.getEmployee();
        Account employer = payroll.getProcessingAccount();

        try {
            // Get or create Stripe customers for employee and employer
            String employeeStripeId = getOrCreateCustomer(employee);
            String employerStripeId = getOrCreateCustomer(employer);

            // Determine payment method
            if (payroll.isAchEnabled()) {
                // Process ACH payment (bank transfer)
                return this.processAchPayment(payroll, employeeStripeId, employerStripeId);
            } else if (payroll.getPaymentMethod() != null) {
                // Process payment with specific payment method
                return this.processPaymentWithMethod(payroll, employeeStripeId, employerStripeId);
            } else {
                // Process as direct transfer
                return this.processDirectTransfer(payroll, employeeStripeId, employerStripeId);
            }
        } catch (StripeException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Process a payroll payment via ACH (bank transfer)
     */
    private boolean processAchPayment(Payroll payroll, String employeeStripeId, String employerStripeId)
            throws StripeException {
        // Convert amount to cents
        long amountInCents = payroll.getNetAmount().multiply(new BigDecimal("100")).longValue();

        // Create ACH payout to employee
        Map<String, Object> payoutParams = new HashMap<>();
        payoutParams.put("amount", amountInCents);
        payoutParams.put("currency", defaultCurrency);
        payoutParams.put("method", "standard"); // Standard ACH transfer
        payoutParams.put("destination", employeeStripeId);
        payoutParams.put("description", "Payroll payment: " + payroll.getReferenceNumber());

        // Statement descriptor (what employee will see on their bank statement)
        payoutParams.put("statement_descriptor", "Payroll: " + payroll.getProcessingAccount().getFullName());

        // Metadata for tracking
        Map<String, String> metadata = new HashMap<>();
        metadata.put("payroll_id", payroll.getId().toString());
        metadata.put("reference_number", payroll.getReferenceNumber());
        metadata.put("employee_id", payroll.getEmployee().getId().toString());
        metadata.put("employer_id", payroll.getProcessingAccount().getId().toString());
        payoutParams.put("metadata", metadata);

        try {
            // Create the payout
            Payout payout = Payout.create(payoutParams);

            // Update payroll with Stripe reference
            payroll.setReferenceNumber(payout.getId());

            // Check payout status
            return "paid".equals(payout.getStatus()) || "pending".equals(payout.getStatus());
        } catch (Exception e) {
            logger.error("Stripe ACH payment error: {}", e.getMessage());
            throw e;
        }
    }

    /**
     * Process a payroll payment with a specific payment method (credit card, etc.)
     */
    private boolean processPaymentWithMethod(Payroll payroll, String employeeStripeId, String employerStripeId)
            throws StripeException {
        PaymentMethod paymentMethod = payroll.getPaymentMethod();

        // Convert amount to cents
        long amountInCents = payroll.getNetAmount().multiply(new BigDecimal("100")).longValue();

        // Get Stripe payment method token
        String paymentMethodToken = paymentMethod.getProviderToken();
        if (paymentMethodToken == null) {
            logger.error("No Stripe token available for payment method {}", paymentMethod.getId());
            return false;
        }

        // Create PaymentIntent
        Map<String, Object> paymentIntentParams = new HashMap<>();
        paymentIntentParams.put("amount", amountInCents);
        paymentIntentParams.put("currency", defaultCurrency);
        paymentIntentParams.put("payment_method", paymentMethodToken);
        paymentIntentParams.put("confirm", true); // Confirm immediately
        paymentIntentParams.put("description", "Payroll payment: " + payroll.getReferenceNumber());
        paymentIntentParams.put("customer", employerStripeId);

        // Use transfer_data to move funds to the employee's connected account
        Map<String, Object> transferData = new HashMap<>();
        transferData.put("destination", employeeStripeId);
        paymentIntentParams.put("transfer_data", transferData);

        // Metadata for tracking
        Map<String, String> metadata = new HashMap<>();
        metadata.put("payroll_id", payroll.getId().toString());
        metadata.put("reference_number", payroll.getReferenceNumber());
        metadata.put("employee_id", payroll.getEmployee().getId().toString());
        metadata.put("employer_id", payroll.getProcessingAccount().getId().toString());
        paymentIntentParams.put("metadata", metadata);

        try {
            // Create and confirm the PaymentIntent
            PaymentIntent paymentIntent = PaymentIntent.create(paymentIntentParams);

            // Update payroll with Stripe reference
            payroll.setReferenceNumber(paymentIntent.getId());

            // Check PaymentIntent status
            return "succeeded".equals(paymentIntent.getStatus());
        } catch (StripeException e) {
            logger.error("Stripe payment method error: {}", e.getMessage());
            throw e;
        }
    }

    /**
     * Process a direct transfer from employer to employee
     */
    private boolean processDirectTransfer(Payroll payroll, String employeeStripeId, String employerStripeId)
            throws StripeException {
        // Convert amount to cents
        long amountInCents = payroll.getNetAmount().multiply(new BigDecimal("100")).longValue();

        // Create a Transfer from employer to employee
        Map<String, Object> transferParams = new HashMap<>();
        transferParams.put("amount", amountInCents);
        transferParams.put("currency", defaultCurrency);
        transferParams.put("destination", employeeStripeId);
        transferParams.put("source_transaction", null); // Will use platform account as source
        transferParams.put("description", "Payroll payment: " + payroll.getReferenceNumber());

        // Metadata for tracking
        Map<String, String> metadata = new HashMap<>();
        metadata.put("payroll_id", payroll.getId().toString());
        metadata.put("reference_number", payroll.getReferenceNumber());
        metadata.put("employee_id", payroll.getEmployee().getId().toString());
        metadata.put("employer_id", payroll.getProcessingAccount().getId().toString());
        transferParams.put("metadata", metadata);

        try {
            // Create the transfer
            Transfer transfer = Transfer.create(transferParams);

            // Update payroll with Stripe reference
            payroll.setReferenceNumber(transfer.getId());

            // Check transfer status
            return transfer.getId() != null && transfer.getObject().equals("transfer");
        } catch (StripeException e) {
            logger.error("Stripe direct transfer error: {}", e.getMessage());
            throw e;
        }
    }

    @Override
    public String createAchSetupIntent(Account account) {
        try {
            String customerId = getOrCreateCustomer(account);

            SetupIntentCreateParams params = SetupIntentCreateParams.builder()
                    .setCustomer(customerId)
                    .addPaymentMethodType("us_bank_account")
                    .setUsage(SetupIntentCreateParams.Usage.OFF_SESSION)
                    .setPaymentMethodOptions(
                            SetupIntentCreateParams.PaymentMethodOptions.builder()
                                    .setUsBankAccount(
                                            SetupIntentCreateParams.PaymentMethodOptions.UsBankAccount.builder()
                                                    .setVerificationMethod(
                                                            SetupIntentCreateParams.PaymentMethodOptions.UsBankAccount.VerificationMethod.AUTOMATIC)
                                                    .build())
                                    .build())
                    .build();

            SetupIntent setupIntent = SetupIntent.create(params);
            return setupIntent.getClientSecret();
        } catch (StripeException e) {
            logger.error("Error creating ACH setup intent: {}", e.getMessage());
            throw new PaymentProcessingException("Failed to create ACH setup intent: " + e.getMessage(), e);
        }
    }

    @Override
    public void refreshBankAccountDetails(PaymentMethod paymentMethod) {
        if (paymentMethod.getProviderToken() == null) {
            return;
        }

        try {
            com.stripe.model.PaymentMethod stripePaymentMethod = com.stripe.model.PaymentMethod
                    .retrieve(paymentMethod.getProviderToken());

            if (!"us_bank_account".equals(stripePaymentMethod.getType())) {
                return;
            }

            var bankAccount = stripePaymentMethod.getUsBankAccount();
            if (bankAccount == null) {
                return;
            }

            paymentMethod.setType(PaymentType.BANK_TRANSFER);
            paymentMethod.setBrand("us_bank_account");
            paymentMethod.setLastFourDigits(bankAccount.getLast4());
            paymentMethod.setBankLastFourDigits(bankAccount.getLast4());
            paymentMethod.setBankFingerprint(bankAccount.getFingerprint());
            paymentMethod.setBankMandateReference(null);
            paymentMethod.setBankMandateUrl(null);
            paymentMethod.setAchAccountHolderName(
                    stripePaymentMethod.getBillingDetails() != null
                            ? stripePaymentMethod.getBillingDetails().getName()
                            : null);

            var statusDetails = bankAccount.getStatusDetails();
            BankAccountVerificationStatus previousStatus = Optional
                    .ofNullable(paymentMethod.getBankVerificationStatus())
                    .orElse(BankAccountVerificationStatus.UNVERIFIED);
            BankAccountVerificationStatus mappedStatus = previousStatus;

            if (statusDetails != null && statusDetails.getBlocked() != null) {
                mappedStatus = BankAccountVerificationStatus.FAILED;
            } else if (bankAccount.getFinancialConnectionsAccount() != null) {
                mappedStatus = BankAccountVerificationStatus.VERIFIED;
            }

            paymentMethod.setBankVerificationStatus(mappedStatus);

            if (mappedStatus == BankAccountVerificationStatus.VERIFIED
                    && paymentMethod.getBankVerifiedAt() == null) {
                paymentMethod.setBankVerifiedAt(LocalDateTime.now());
            }

            paymentMethod.setIsActive(mappedStatus == BankAccountVerificationStatus.VERIFIED);
        } catch (StripeException e) {
            logger.error("Unable to refresh ACH bank account details: {}", e.getMessage());
            throw new RuntimeException("Failed to refresh ACH bank account details", e);
        }
    }

    @Override
    public boolean verifyBankAccountMicroDeposits(String paymentMethodId, int firstAmount, int secondAmount) {
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("amounts", List.of(firstAmount, secondAmount));

            String path = String.format("/v1/payment_methods/%s/verify_microdeposits",
                    ApiResource.urlEncodeId(paymentMethodId));

            ApiRequest request = new ApiRequest(BaseAddress.API, ApiResource.RequestMethod.POST, path, params, null);
            ApiResource.getGlobalResponseGetter().request(request, com.stripe.model.PaymentMethod.class);

            return true;
        } catch (StripeException e) {
            String errorCode = e.getCode();
            String userMessage = e.getUserMessage();
            if ("payment_method_bank_account_already_verified".equals(errorCode)) {
                logger.info("Micro-deposit verification skipped: payment method {} already verified", paymentMethodId);
                return true;
            }

            String message = userMessage != null ? userMessage : e.getMessage();
            logger.error("Micro-deposit verification failed for {} (code: {}): {}", paymentMethodId, errorCode, message);
            throw new PaymentProcessingException(
                    message != null ? message : "Stripe micro-deposit verification failed", e);
        }
    }

}
