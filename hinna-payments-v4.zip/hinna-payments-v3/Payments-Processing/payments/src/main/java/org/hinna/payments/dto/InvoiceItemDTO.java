package org.hinna.payments.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.UUID;

@Data
public class InvoiceItemDTO {
    private UUID id;
    private String description;
    private int quantity;
    private BigDecimal price;
    private BigDecimal taxRate;
    private String itemType;
    private UUID itemId;
    private UUID serviceId;
}