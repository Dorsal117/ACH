package org.hinna.payments.dto;

import lombok.Data;
import org.hinna.payments.model.enums.PaymentType;

import java.util.UUID;

/**
 * Data Transfer Object for payment method creation/update
 */
@Data
public class PaymentMethodRequestDTO {
    private UUID ownerId;
    private PaymentType type;
    private String providerToken;
    private String lastFourDigits;
    private String expiryDate;
    private Boolean isDefault;
    private Boolean isActive;
    private String brand; // (visa, mastercard, amex, paypal, ...)
    private String walletType; // (apple_pay, google_pay (optional))
    private String achAccountHolderName;
}
