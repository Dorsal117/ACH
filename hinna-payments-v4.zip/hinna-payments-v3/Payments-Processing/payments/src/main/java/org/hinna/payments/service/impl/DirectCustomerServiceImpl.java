package org.hinna.payments.service.impl;

import jakarta.transaction.Transactional;
import org.hinna.payments.model.BillingHistory;
import org.hinna.payments.model.DirectCustomer;
import org.hinna.payments.model.ResellerAccount;
import org.hinna.payments.repository.BillingHistoryRepository;
import org.hinna.payments.repository.DirectCustomerRepository;
import org.hinna.payments.service.AccountService;
import org.hinna.payments.service.DirectCustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class DirectCustomerServiceImpl implements DirectCustomerService {

    private final DirectCustomerRepository directCustomerRepository;
    private final BillingHistoryRepository billingHistoryRepository;
    private final AccountService accountService;

    @Autowired
    public DirectCustomerServiceImpl(DirectCustomerRepository directCustomerRepository,
                                      BillingHistoryRepository billingHistoryRepository,
                                      AccountService accountService) {
        this.directCustomerRepository = directCustomerRepository;
        this.billingHistoryRepository = billingHistoryRepository;
        this.accountService = accountService;
    }

    @Override
    @Transactional
    public DirectCustomer createDirectCustomer(DirectCustomer directCustomer) {
        // Check if email is already in use
        if (accountService.isEmailTaken(directCustomer.getEmail())) {
            throw new IllegalArgumentException("Email is already in use");
        }

        // Initialize the direct customer
        if (directCustomer.getCredit() == null) {
            directCustomer.setCredit(BigDecimal.ZERO);
        }

        return directCustomerRepository.save(directCustomer);
    }

    @Override
    public Optional<DirectCustomer> getDirectCustomerById(UUID id) {
        return directCustomerRepository.findById(id);
    }

    @Override
    public Page<DirectCustomer> getAllDirectCustomers(Pageable pageable) {
        return directCustomerRepository.findAll(pageable);
    }

    @Override
    public List<DirectCustomer> getDirectCustomersByReseller(ResellerAccount reseller) {
        return directCustomerRepository.findByReseller(reseller);
    }

    @Override
    public List<DirectCustomer> getDirectCustomersByFamilyId(UUID familyId) {
        return directCustomerRepository.findByFamilyId(familyId);
    }

    @Override
    public DirectCustomer updateDirectCustomer(UUID id, DirectCustomer directCustomerDetails) {
        return directCustomerRepository.findById(id)
                .map(existingCustomer -> {
                    // Check if email is being changed and is not already taken
                    if (!existingCustomer.getEmail().equals(directCustomerDetails.getEmail()) &&
                            accountService.isEmailTaken(directCustomerDetails.getEmail())) {
                        throw new IllegalArgumentException("Email is already in use");
                    }

                    // Update account fields
                    existingCustomer.setFirstName(directCustomerDetails.getFirstName());
                    existingCustomer.setLastName(directCustomerDetails.getLastName());
                    existingCustomer.setEmail(directCustomerDetails.getEmail());
                    existingCustomer.setAddress(directCustomerDetails.getAddress());
                    existingCustomer.setMobilePhone(directCustomerDetails.getMobilePhone());
                    existingCustomer.setHomePhone(directCustomerDetails.getHomePhone());

                    // Update direct customer specific fields
                    existingCustomer.setBusinessName(directCustomerDetails.getBusinessName());
                    existingCustomer.setBusinessType(directCustomerDetails.getBusinessType());
                    existingCustomer.setTaxId(directCustomerDetails.getTaxId());
                    existingCustomer.setFamilyId(directCustomerDetails.getFamilyId());
                    existingCustomer.setAllowBookingsFamilyDF(directCustomerDetails.getAllowBookingsFamilyDF());
                    existingCustomer.setAllowPaymentsFamilyDF(directCustomerDetails.getAllowPaymentsFamilyDF());
                    existingCustomer.setAllowRefundsFamilyDF(directCustomerDetails.getAllowRefundsFamilyDF());
                    existingCustomer.setAllowEmailReportsDF(directCustomerDetails.getAllowEmailReportsDF());

                    // Don't update credit directly - use addCredit/useCredit methods

                    return directCustomerRepository.save(existingCustomer);
                })
                .orElseThrow(() -> new IllegalArgumentException("Direct customer not found"));
    }

    @Override
    @Transactional
    public void deleteDirectCustomer(UUID id) {
        directCustomerRepository.deleteById(id);
    }

    @Override
    public DirectCustomer addCredit(UUID customerId, BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Credit amount must be positive");
        }

        DirectCustomer customer = directCustomerRepository.findById(customerId)
                .orElseThrow(() -> new IllegalArgumentException("Direct customer not found"));

        // Add credit to customer
        customer.addCredit(amount);
        DirectCustomer updatedCustomer = directCustomerRepository.save(customer);

        // Record transaction in billing history
        BillingHistory billingRecord = new BillingHistory(customer, amount, "CREDIT_ADDED");
        billingRecord.setDescription("Credit added to account");
        billingHistoryRepository.save(billingRecord);

        return updatedCustomer;
    }

    @Override
    @Transactional
    public DirectCustomer useCredit(UUID customerId, BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Credit amount must be positive");
        }

        DirectCustomer customer = directCustomerRepository.findById(customerId)
                .orElseThrow(() -> new IllegalArgumentException("Direct customer not found"));

        // Check if customer has enough credit
        if (customer.getCredit().compareTo(amount) < 0) {
            throw new IllegalArgumentException("Insufficient credit");
        }

        // Use credit
        customer.useCredit(amount);
        DirectCustomer updatedCustomer = directCustomerRepository.save(customer);

        // Record transaction in billing history
        BillingHistory billingRecord = new BillingHistory(customer, amount.negate(), "CREDIT_USED");
        billingRecord.setDescription("Credit used for payment");
        billingHistoryRepository.save(billingRecord);

        return updatedCustomer;
    }

    @Override
    public List<DirectCustomer> searchDirectCustomers(String searchTerm) {
        return directCustomerRepository.findByBusinessNameContaining(searchTerm);
    }
}
