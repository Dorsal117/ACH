package org.hinna.payments.integration.user.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RabbitMQ configuration for User Service integration.
 * Follows the same pattern as the Booking Service integration
 */
@Configuration
public class UserServiceRabbitMQConfig {

//    // Queue names
//    public static final String USER_CREATED_QUEUE = "hinna.payment.user-created";
//    public static final String USER_UPDATED_QUEUE = "hinna.payment.user-updated";
//    public static final String USER_DELETED_QUEUE = "hinna.payment.user-deleted";
//    public static final String USER_ROLE_CHANGED_QUEUE = "hinna.payment.user-role-changed";
//
//    // Exchange names
//    public static final String USER_EXCHANGE = "hinna.user.exchange";
//    public static final String PAYMENT_EXCHANGE = "hinna.payment.exchange";
//
//    // Routing keys
//    public static final String USER_CREATED_KEY = "user.created";
//    public static final String USER_UPDATED_KEY = "user.updated";
//    public static final String USER_DELETED_KEY = "user.deleted";
//    public static final String USER_ROLE_CHANGED_KEY = "user.role.changed";
//
//    // Queue definitions
//    @Bean
//    public Queue userCreatedQueue() {
//        return QueueBuilder.durable(USER_CREATED_QUEUE).build();
//    }
//
//    @Bean
//    public Queue userUpdatedQueue() {
//        return QueueBuilder.durable(USER_UPDATED_QUEUE).build();
//    }
//
//    @Bean
//    public Queue userDeletedQueue() {
//        return QueueBuilder.durable(USER_DELETED_QUEUE).build();
//    }
//
//    @Bean
//    public Queue userRoleChangedQueue() {
//        return QueueBuilder.durable(USER_ROLE_CHANGED_QUEUE).build();
//    }
//
//    // Exchange definitions
//    @Bean
//    public TopicExchange userExchange() {
//        return ExchangeBuilder.topicExchange(USER_EXCHANGE).durable(true).build();
//    }
//
//    @Bean
//    public TopicExchange paymentExchange() {
//        return ExchangeBuilder.topicExchange(PAYMENT_EXCHANGE).durable(true).build();
//    }
//
//    // Bindings
//    @Bean
//    public Binding userCreatedBinding() {
//        return BindingBuilder.bind(userCreatedQueue()).to(userExchange()).with(USER_CREATED_KEY);
//    }
//
//    @Bean
//    public Binding userUpdatedBinding() {
//        return BindingBuilder.bind(userUpdatedQueue()).to(userExchange()).with(USER_UPDATED_KEY);
//    }
//
//    @Bean
//    public Binding userDeletedBinding() {
//        return BindingBuilder.bind(userDeletedQueue()).to(userExchange()).with(USER_DELETED_KEY);
//    }
//
//    @Bean
//    public Binding userRoleChangedBinding() {
//        return BindingBuilder.bind(userRoleChangedQueue()).to(userExchange()).with(USER_ROLE_CHANGED_KEY);
//    }
//
//    // Message converter that handles Java 8 date/time types
//    @Bean
//    public MessageConverter jsonMessageConverter() {
//        ObjectMapper objectMapper = new ObjectMapper();
//        objectMapper.registerModule(new JavaTimeModule());
//        return new Jackson2JsonMessageConverter(objectMapper);
//    }
//
//    // RabbitTemplate configuration (if not already defined elsewhere)
//    @Bean
//    public RabbitTemplate userServiceRabbitTemplate(ConnectionFactory connectionFactory) {
//        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
//        rabbitTemplate.setMessageConverter(jsonMessageConverter());
//        return rabbitTemplate;
//    }
}
