package org.hinna.payments.model.enums;

/**
 * Enum for lesson cancellation reasons
 */
public enum LessonCancellationReason {
    STUDENT_CANCELLED,         // Student cancelled the lesson
    TEACHER_CANCELLED,         // Teacher cancelled the lesson
    SYSTEM_CANCELLED,          // System cancelled (e.g., facility issue)
    WEATHER_CANCELLED,         // Weather-related cancellation
    EMERGENCY_CANCELLED        // Emergency cancellation
}
