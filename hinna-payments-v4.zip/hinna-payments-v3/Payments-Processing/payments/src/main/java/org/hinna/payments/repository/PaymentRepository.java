package org.hinna.payments.repository;

import org.hinna.payments.model.*;
import org.hinna.payments.model.enums.PaymentStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, UUID> {
    List<Payment> findByCustomer(Account customer);
    List<Payment> findByMethod(PaymentMethod method);
    List<Payment> findByStatus(PaymentStatus status);
    Optional<Payment> findByReferenceNumber(String referenceNumber);
    List<Payment> findByCreatedAtBetween(LocalDateTime start, LocalDateTime end);

    /**
     * Find paginated payments by customer
     */
    Page<Payment> findByCustomer(Account customer, Pageable pageable);

    /**
     * Find payments by customer and multiple statuses
     */
    List<Payment> findByCustomerAndStatusIn(Account customer, List<PaymentStatus> statuses);

    /**
     * Custom query to search for payments by various criteria
     */
    @Query("SELECT p FROM Payment p WHERE p.createdAt BETWEEN :start AND :end " +
            "AND (LOWER(p.referenceNumber) LIKE LOWER(CONCAT('%', :searchTerm, '%')) " +
            "OR LOWER(COALESCE(p.description, '')) LIKE LOWER(CONCAT('%', :searchTerm, '%')) " +
            "OR (p.customer IS NOT NULL AND (" +
            "LOWER(p.customer.firstName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) " +
            "OR LOWER(p.customer.lastName) LIKE LOWER(CONCAT('%', :searchTerm, '%'))" +
            ")))")
    List<Payment> findByCreatedAtBetweenAndSearchTerm(
            @Param("start") LocalDateTime start,
            @Param("end") LocalDateTime end,
            @Param("searchTerm") String searchTerm);
}