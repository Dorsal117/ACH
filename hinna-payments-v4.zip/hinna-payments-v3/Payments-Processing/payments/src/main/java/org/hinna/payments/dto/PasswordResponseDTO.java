package org.hinna.payments.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
public class PasswordResponseDTO {
    private UUID accountId;
    private LocalDateTime lastChanged;
    private String resetToken;
    private LocalDateTime tokenExpiry;
    private boolean tokenValid;
}