package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.List;

@Entity
@Table(name = "admin_group")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = { "admins" })
@EqualsAndHashCode(of = "id")
public class AdminGroup {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "group_name", nullable = false)
    private String groupName;

    @Column(name = "base_permissions")
    private String basePermissions;

    @Column(name = "types")
    private String types;

    @Column(name = "is_active")
    private boolean isActive = true;

    @ManyToMany
    @JoinTable(name = "admin_group_permission", joinColumns = @JoinColumn(name = "admin_group_id"), inverseJoinColumns = @JoinColumn(name = "permission_id"))
    private Set<Permission> permissions = new HashSet<>();

    public boolean hasPermission(String permissionKey) {
        return permissions.stream()
                .anyMatch(p -> p.getPermissionKey().equalsIgnoreCase(permissionKey));
    }

    @OneToMany(mappedBy = "adminGroup")
    private List<Admin> admins;
}
