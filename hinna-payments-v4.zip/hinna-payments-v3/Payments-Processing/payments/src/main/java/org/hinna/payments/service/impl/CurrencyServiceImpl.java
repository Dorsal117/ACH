package org.hinna.payments.service.impl;

import java.util.UUID;

import org.hinna.payments.model.Currency;
import org.hinna.payments.repository.CurrencyRepository;
import org.hinna.payments.service.CurrencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import jakarta.persistence.EntityNotFoundException;

@Service
public class CurrencyServiceImpl implements CurrencyService {
    private final CurrencyRepository currencyRepository;

    @Autowired
    public CurrencyServiceImpl(CurrencyRepository currencyRepository) {
        this.currencyRepository = currencyRepository;
    }

    @Override
    public Currency createCurrency(Currency currency) {
        if (currencyRepository.existsByCode(currency.getCode())) {
            throw new IllegalArgumentException("Currency code already exists.");
        }
        return currencyRepository.save(currency);
    }

    @Override
    public Currency updateCurrency(UUID id, Currency updatedCurrency) {
        Currency existing = currencyRepository.findById(id)
            .orElseThrow(() -> new EntityNotFoundException("Currency not found"));
        existing.setName(updatedCurrency.getName());
        existing.setSymbol(updatedCurrency.getSymbol());
        existing.setExchangeRateToBase(updatedCurrency.getExchangeRateToBase());
        existing.setDecimalPlaces(updatedCurrency.getDecimalPlaces());
        existing.setBaseCurrency(updatedCurrency.isBaseCurrency());
        return currencyRepository.save(existing);
    }

    @Override
    public void deleteCurrency(UUID id) {
        currencyRepository.deleteById(id);
    }

    @Override
    public Currency getCurrency(UUID id) {
        return currencyRepository.findById(id)
            .orElseThrow(() -> new EntityNotFoundException("Currency not found"));
    }

    @Override
    public List<Currency> getAllCurrencies() {
        return currencyRepository.findAll();
    }

    @Override
    public Currency getBaseCurrency() {
        return currencyRepository.findByIsBaseCurrencyTrue()
            .orElseThrow(() -> new IllegalStateException("No base currency set"));
    }
}
