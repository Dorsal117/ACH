package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;
import org.hinna.payments.model.enums.PaymentStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "refund")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = "payment")
@EqualsAndHashCode(of = "id")
public class Refund {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "payment_id")
    private Payment payment;

    @Column(precision = 19, scale = 4, nullable = false)
    private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    private PaymentStatus status;

    @Column(name = "reason_code")
    private String reasonCode;

    private String description;

    @Column(name = "refund_reference")
    private String refundReference;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "processed_at")
    private LocalDateTime processedAt;

    public Refund(Payment payment, BigDecimal amount) {
        this.payment = payment;
        this.amount = amount;
        this.status = PaymentStatus.PENDING;
    }

    @PrePersist
    public void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.refundReference = this.generateRefundReference();
    }

    private String generateRefundReference() {
        return "REF-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

    }
}
