package org.hinna.payments.integration.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.amqp.core.*;

@Configuration
public class RabbitMQConfig {

    // Common settings
    @Value("${spring.rabbitmq.ssl.enabled:false}")
    private boolean sslEnabled;

    @Value("${spring.rabbitmq.ssl.protocol:TLSv1.2}")
    private String sslProtocol;

    // BOOKING INTEGRATION
    // Queue names
    public static final String BOOKING_CREATED_QUEUE = "hinna.payment.booking-created";
    public static final String BOOKING_CANCELLED_QUEUE = "hinna.payment.booking-cancelled";
    public static final String BOOKING_PAYMENT_QUEUE = "hinna.booking.payment-processed";
    public static final String BOOKING_REFUND_QUEUE = "hinna.booking.refund-processed";

    // Exchange names
    public static final String BOOKING_EXCHANGE = "hinna.booking.exchange";
    public static final String PAYMENT_EXCHANGE = "hinna.payment.exchange";

    // Routing keys
    public static final String BOOKING_CREATED_KEY = "booking.created";
    public static final String BOOKING_CANCELLED_KEY = "booking.cancelled";
    public static final String PAYMENT_PROCESSED_KEY = "payment.processed";
    public static final String REFUND_PROCESSED_KEY = "refund.processed";

    // PAT INTEGRATION
    // Exchange name
    public static final String PAT_EXCHANGE = "hinnachat-pat-exchange";

    // Queue names
    public static final String PAT_WORKFLOW_QUEUE = "hinna.payment.pat-workflow";
    public static final String PAT_STEP_QUEUE = "hinna.payment.pat-step";

    // Routing keys
    public static final String PAT_WORKFLOW_EXECUTE_KEY = "workflow.execute";
    public static final String PAT_STEP_EXECUTE_KEY = "step.execute";

    // BOOKING INTEGRATION BEANS
    // Queue definitions
    @Bean
    public Queue bookingCreatedQueue() {
        return QueueBuilder.durable(BOOKING_CREATED_QUEUE).build();
    }

    @Bean
    public Queue bookingCancelledQueue() {
        return QueueBuilder.durable(BOOKING_CANCELLED_QUEUE).build();
    }

    @Bean
    public Queue bookingPaymentQueue() {
        return QueueBuilder.durable(BOOKING_PAYMENT_QUEUE).build();
    }

    @Bean
    public Queue bookingRefundQueue() {
        return QueueBuilder.durable(BOOKING_REFUND_QUEUE).build();
    }

    // Exchange definitions
    @Bean
    public TopicExchange bookingExchange() {
        return ExchangeBuilder.topicExchange(BOOKING_EXCHANGE).durable(true).build();
    }

    @Bean
    public TopicExchange paymentExchange() {
        return ExchangeBuilder.topicExchange(PAYMENT_EXCHANGE).durable(true).build();
    }

    // Bindings
    @Bean
    public Binding bookingCreatedBinding() {
        return BindingBuilder.bind(bookingCreatedQueue()).to(bookingExchange()).with(BOOKING_CREATED_KEY);
    }

    @Bean
    public Binding bookingCancelledBinding() {
        return BindingBuilder.bind(bookingCancelledQueue()).to(bookingExchange()).with(BOOKING_CANCELLED_KEY);
    }

    @Bean
    public Binding paymentProcessedBinding() {
        return BindingBuilder.bind(bookingPaymentQueue()).to(paymentExchange()).with(PAYMENT_PROCESSED_KEY);
    }

    @Bean
    public Binding refundProcessedBinding() {
        return BindingBuilder.bind(bookingRefundQueue()).to(paymentExchange()).with(REFUND_PROCESSED_KEY);
    }

    // ----- PAT INTEGRATION BEANS -----
    @Bean
    public DirectExchange patExchange() {
        return new DirectExchange(PAT_EXCHANGE);
    }

    @Bean
    public Queue patWorkflowQueue() {
        return QueueBuilder.durable(PAT_WORKFLOW_QUEUE).build();
    }

    @Bean
    public Queue patStepQueue() {
        return QueueBuilder.durable(PAT_STEP_QUEUE).build();
    }

    @Bean
    public Binding patWorkflowBinding() {
        return BindingBuilder.bind(patWorkflowQueue()).to(patExchange()).with(PAT_WORKFLOW_EXECUTE_KEY);
    }

    @Bean
    public Binding patStepBinding() {
        return BindingBuilder.bind(patStepQueue()).to(patExchange()).with(PAT_STEP_EXECUTE_KEY);
    }

    // Message converter that handles Java 8 date/time types
    @Bean
    public MessageConverter jsonMessageConverter() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        return new Jackson2JsonMessageConverter(objectMapper);
    }

    // RabbitTemplate
    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
        rabbitTemplate.setMessageConverter(jsonMessageConverter());
        return rabbitTemplate;
    }
}
