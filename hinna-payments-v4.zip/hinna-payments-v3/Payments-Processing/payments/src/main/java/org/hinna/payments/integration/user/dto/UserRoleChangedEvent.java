package org.hinna.payments.integration.user.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Event sent when a user's role is changed in the User Service.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserRoleChangedEvent {
    private Long userId;
    private String oldRole;
    private String newRole;
    private String businessName;
    private String companyName;
    private String taxId;
}
