package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;
import org.hinna.payments.model.enums.PayrollFrequency;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "payroll_schedule")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString(exclude = {"employee", "employer"})
@EqualsAndHashCode(of = "id")
public class PayrollSchedule {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * The staff member (employee receiving the scheduled payroll
     */
    @ManyToOne
    @JoinColumn(name = "employee_id", nullable = false)
    private Staff employee;

    /**
     * The business account processing the payroll payments
     */
    @ManyToOne
    @JoinColumn(name = "employer_id", nullable = false)
    private Account employer;

    /**
     * Payment method to use for automatic payments
     */
    @ManyToOne
    @JoinColumn(name = "payment_method_id")
    private PaymentMethod paymentMethod;

    /**
     * The frequency of payments
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "frequency", nullable = false)
    private PayrollFrequency frequency;

    /**
     * Day of month for monthly payments
     */
    @Column(name = "day_of_month")
    private Integer dayOfMonth;

    /**
     * Day of week for weekly payments
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "day_of_week")
    private DayOfWeek dayOfWeek;

    /**
     * The gross amount to pay
     */
    @Column(name = "gross_amount", precision = 19, scale = 4, nullable = false)
    private BigDecimal grossAmount;

    /**
     * Tax rate percentage
     */
    @Column(name = "tax_rate", precision = 5, scale = 2)
    private BigDecimal taxRate;

    /**
     * Deduction amount
     */
    @Column(name = "deductions", precision = 19, scale = 4)
    private BigDecimal deductions;

    /**
     * Description for this payment schedule
     */
    @Column(name = "description")
    private String description;

    /**
     * Whether the schedule is currently active
     */
    @Column(name = "is_active", nullable = false)
    private boolean isActive = true;

    /**
     * Whether ACH payments are enabled
     */
    @Column(name = "is_ach_enabled", nullable = false)
    private boolean isAchEnabled = false;

    /**
     * The next scheduled payment date
     */
    @Column(name = "next_payment_date")
    private LocalDateTime nextPaymentDate;

    /**
     * When this schedule was created
     */
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    /**
     * When this schedule was last updated
     */
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        calculateNextPaymentDate();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Calculate the next payment date based on frequency and current date
     */
    public void calculateNextPaymentDate() {
        LocalDateTime now = LocalDateTime.now();

        switch (frequency) {
            case WEEKLY:
                if (dayOfWeek != null) {
                    // Find the next occurrence of the specified day of week
                    int daysToAdd = (dayOfWeek.getValue() - now.getDayOfWeek().getValue() + 7) % 7;
                    if (daysToAdd == 0) {
                        daysToAdd = 7; // If today is the day, schedule for next week
                    }
                    this.nextPaymentDate = now.plusDays(daysToAdd).toLocalDate().atStartOfDay();
                }
                break;

            case BI_WEEKLY:
                if (dayOfWeek != null) {
                    // Find the next occurrence of the specified day of week
                    int daysToAdd = (dayOfWeek.getValue() - now.getDayOfWeek().getValue() + 7) % 7;
                    if (daysToAdd == 0) {
                        daysToAdd = 14; // If today is the day, schedule for two weeks from now
                    } else {
                        // Check if the next occurrence is this week or next week
                        if (nextPaymentDate != null && now.minusDays(7).isBefore(nextPaymentDate)) {
                            daysToAdd += 7; // The last payment was less than a week ago, so schedule for next week
                        }
                    }
                    this.nextPaymentDate = now.plusDays(daysToAdd).toLocalDate().atStartOfDay();
                }
                break;

            case MONTHLY:
                if (dayOfMonth != null) {
                    LocalDateTime candidate = now.withDayOfMonth(
                            Math.min(dayOfMonth, now.toLocalDate().lengthOfMonth()));

                    if (candidate.isBefore(now) || candidate.isEqual(now)) {
                        // If the day has already passed this month, schedule for next month
                        candidate = candidate.plusMonths(1);
                    }

                    this.nextPaymentDate = candidate;
                }
                break;

            case SEMI_MONTHLY:
                // Typically 1st and 15th of the month
                int dayOfMonth1 = 1;
                int dayOfMonth2 = 15;

                LocalDateTime firstDate = now.withDayOfMonth(dayOfMonth1);
                LocalDateTime secondDate = now.withDayOfMonth(
                        Math.min(dayOfMonth2, now.toLocalDate().lengthOfMonth()));

                if (now.getDayOfMonth() < dayOfMonth2) {
                    this.nextPaymentDate = secondDate;
                } else {
                    // Both dates have passed, schedule for 1st of next month
                    this.nextPaymentDate = firstDate.plusMonths(1);
                }
                break;

            default:
                // Default to one month from now
                this.nextPaymentDate = now.plusMonths(1);
                break;
        }
    }

    /**
     * Calculate net amount based on gross amount, tax rate, and deductions
     * @return The calculated net amount
     */
    @Transient
    public BigDecimal calculateNetAmount() {
        BigDecimal net = this.grossAmount;

        // Apply tax if tax rate is set
        if (this.taxRate != null && this.taxRate.compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal taxAmount = this.grossAmount.multiply(this.taxRate)
                    .divide(new BigDecimal("100"), 2, java.math.RoundingMode.HALF_UP);
            net = net.subtract(taxAmount);
        }

        // Apply deductions if set
        if (this.deductions != null && this.deductions.compareTo(BigDecimal.ZERO) > 0) {
            net = net.subtract(this.deductions);
        }

        return net.max(BigDecimal.ZERO); // Ensure net amount is not negative
    }
}
