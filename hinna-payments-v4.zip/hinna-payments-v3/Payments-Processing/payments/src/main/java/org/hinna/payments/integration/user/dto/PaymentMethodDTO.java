package org.hinna.payments.integration.user.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * DTO for payment method information.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Information about a payment method")
public class PaymentMethodDTO {

    @Schema(description = "Payment method ID", example = "123e4567-e89b-12d3-a456-426614174000")
    private UUID id;

    @Schema(description = "Payment method type", example = "CREDIT_CARD")
    private String type;

    @Schema(description = "Last four digits of the card (if applicable)", example = "1234")
    private String lastFourDigits;

    @Schema(description = "Expiry date (if applicable)")
    private LocalDateTime expiryDate;

    @Schema(description = "Whether this is the default payment method", example = "true")
    private Boolean isDefault;

    @Schema(description = "Display name for the payment method", example = "Visa ending in 1234")
    private String displayName;

    @Schema(description = "Payment method brand")
    private String brand;

    @Schema(description = "Wallet type for digital wallets")
    private String walletType;
}
