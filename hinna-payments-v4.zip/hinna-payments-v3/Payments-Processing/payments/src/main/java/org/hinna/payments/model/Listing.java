package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "listing")
@Inheritance(strategy = InheritanceType.JOINED)
@Getter
@Setter
@NoArgsConstructor
@ToString
@EqualsAndHashCode(of = "id")
public class Listing {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(nullable = false)
    private String name;

    private String description;

    @Column(precision = 19, scale = 4, nullable = false)
    private BigDecimal price;

    @Column(name = "is_active")
    private boolean isActive = true;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @ManyToMany
    @JoinTable(name = "listing_sale", joinColumns = @JoinColumn(name = "listing_id"), inverseJoinColumns = @JoinColumn(name = "sale_id"))
    private Set<Sale> applicableSales = new HashSet<>();

    @ManyToMany
    @JoinTable(name = "listing_coupon", joinColumns = @JoinColumn(name = "listing_id"), inverseJoinColumns = @JoinColumn(name = "coupon_id"))
    private Set<Coupon> applicableCoupons = new HashSet<>();

    public Listing(String name, BigDecimal price) {
        this.name = name;
        this.price = price;
    }

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public void addSale(Sale sale) {
        applicableSales.add(sale);
        sale.getApplicableListings().add(this);
    }

    public void removeSale(Sale sale) {
        applicableSales.remove(sale);
        sale.getApplicableListings().remove(this);
    }

    public void addCoupon(Coupon coupon) {
        applicableCoupons.add(coupon);
        coupon.getApplicableListings().add(this);
    }

    public void removeCoupon(Coupon coupon) {
        applicableCoupons.remove(coupon);
        coupon.getApplicableListings().remove(this);
    }
}
