package org.hinna.payments.controller.api;

import org.hinna.payments.dto.AccountRequestDTO;
import org.hinna.payments.dto.AccountResponseDTO;
import org.hinna.payments.model.Account;
import org.hinna.payments.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Controller for user-facing account management operations.
 * This controller handles direct account management operations and is distinct from service-to-service integration.
 */
@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    private final AccountService accountService;

    @Autowired
    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    /**
     * Get account by ID - admin only
     * @param id Account ID
     * @return Account details
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<AccountResponseDTO> getAccountById(@PathVariable UUID id) {
        return accountService.getAccountById(id)
                .map(account -> ResponseEntity.ok(convertToResponseDTO(account)))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Account not found"));
    }

    @GetMapping("/email/{email}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<AccountResponseDTO> getAccountByEmail(@PathVariable String email) {
        return accountService.getAccountByEmail(email)
                .map(this::convertToResponseDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Get all accounts - admin only with pagination
     * @param pageable Pagination information
     * @return Page of accounts
     */
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Page<AccountResponseDTO>> getAllAccounts(Pageable pageable) {
        Page<Account> accounts = accountService.getAllAccounts(pageable);
        Page<AccountResponseDTO> accountDTOs = accounts.map(this::convertToResponseDTO);
        return ResponseEntity.ok(accountDTOs);
    }

    /**
     * Update an account - admin only
     * @param id Account ID
     * @param request Account update information
     * @return Updated account details
     */
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<AccountResponseDTO> updateAccount(@PathVariable UUID id,
                                                            @RequestBody AccountRequestDTO request) {
        try {
            // Convert DTO to entity for updating
            Account accountDetails = new Account();
            accountDetails.setAddress(request.getAddress());
            accountDetails.setMobilePhone(request.getMobilePhone());
            accountDetails.setHomePhone(request.getHomePhone());
            accountDetails.setDob(LocalDate.parse(request.getDob()));
            accountDetails.setGender(request.getGender());
            accountDetails.setActive(true); // Default to active, can be overridden in service

            Account updatedAccount = accountService.updateAccount(id, accountDetails);

            // Convert the updated entity back to a response DTO
            return ResponseEntity.ok(this.convertToResponseDTO(updatedAccount));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to update account: " + e.getMessage());
        }
    }

    @GetMapping("/active")
    public ResponseEntity<List<AccountResponseDTO>> getActiveAccounts() {
        List<AccountResponseDTO> active = accountService.getActiveAccounts()
                .stream()
                .map(this::convertToResponseDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(active);
    }

    /**
     * Helper method to convert Account to AccountResponseDTO
     * @param account Account entity
     * @return AccountResponseDTO
     */
    private AccountResponseDTO convertToResponseDTO(Account account) {
        AccountResponseDTO dto = new AccountResponseDTO();
        dto.setId(account.getId());
        dto.setFirstName(account.getFirstName());
        dto.setLastName(account.getLastName());
        dto.setEmail(account.getEmail());
        dto.setAddress(account.getAddress());
        dto.setMobilePhone(account.getMobilePhone());
        dto.setHomePhone(account.getHomePhone());
        dto.setProfilePicturePath(account.getProfilePicturePath());
        dto.setActive(account.isActive());

        // Add account type information
        dto.setAccountType(determineAccountType(account));

        return dto;
    }

    /**
     * Determine account type based on class
     */
    private String determineAccountType(Account account) {
        return getString(account);
    }

    public static String getString(Account account) {
        String className = account.getClass().getSimpleName();

        return switch (className) {
            case "DirectCustomer" -> "BUSINESS";
            case "Staff" -> "STAFF";
            case "ResellerAccount" -> "RESELLER";
            case "SaaSAccount" -> "SAAS";
            default -> "CLIENT";
        };
    }
}