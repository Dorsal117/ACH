package org.hinna.payments.repository;

import org.hinna.payments.model.Account;
import org.hinna.payments.model.PaymentMethod;
import org.hinna.payments.model.enums.PaymentType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.hinna.payments.model.enums.BankAccountVerificationStatus;


import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Repository
public interface PaymentMethodRepository extends JpaRepository<PaymentMethod, UUID> {
    List<PaymentMethod> findByOwner(Account owner);

    List<PaymentMethod> findByOwnerAndIsActiveTrue(Account owner);

    List<PaymentMethod> findByOwnerAndType(Account owner, PaymentType type);

    List<PaymentMethod> findByOwnerAndIsDefaultTrue(Account owner);

    List<PaymentMethod> findByExpiryDateBefore(LocalDate date);

    List<PaymentMethod> findByOwnerOrderByPriorityAsc(Account owner);

    List<PaymentMethod> findByOwnerAndTypeAndBankVerificationStatus(Account owner, PaymentType type, BankAccountVerificationStatus status);


}