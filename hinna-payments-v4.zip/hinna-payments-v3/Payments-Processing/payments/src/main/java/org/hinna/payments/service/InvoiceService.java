package org.hinna.payments.service;

import org.hinna.payments.model.Account;
import org.hinna.payments.model.Invoice;
import org.hinna.payments.model.InvoiceItem;
import org.hinna.payments.model.enums.InvoiceStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface InvoiceService {

    // Basic CRUD
    Invoice createInvoice(Invoice invoice);
    Optional<Invoice> getInvoiceById(UUID id);
    Optional<Invoice> getInvoiceByNumber(String invoiceNumber);
    Page<Invoice> getAllInvoices(Pageable pageable);
    Invoice updateInvoice(UUID id, Invoice invoiceDetails);
    void deleteInvoice(UUID id);

    // Business operations
    Invoice addItemToInvoice(UUID invoiceId, InvoiceItem item);
    Invoice removeItemFromInvoice(UUID invoiceId, UUID id);
    Invoice issueInvoice(UUID id);
    Invoice markAsPaid(UUID invoiceId, UUID paymentId);
    Invoice cancelInvoice(UUID id);

    // Query operations
    List<Invoice> getInvoicesByCustomer(Account customer);
    Page<Invoice> getInvoicesByCustomer(Account customer, Pageable pageable);
    List<Invoice> getInvoiceByStatus(InvoiceStatus status);
    List<Invoice> getOverdueInvoices();
    List<Invoice> getInvoicesWithinDateRange(LocalDateTime start, LocalDateTime end);
    List<Invoice> getInvoicesByCustomerAndStatus(Account customer, InvoiceStatus status);

    // Batch operations
    List<Invoice> markOverdueInvoices();

    // Statistics
    BigDecimal getTotalOutstandingAmount(Account customer);
    BigDecimal getTotalPaidAmount(Account customer, LocalDateTime start, LocalDateTime end);
}
