package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

@Entity
@Table(name = "admin_table_access")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = {"admin", "databaseTable"})
@EqualsAndHashCode(of = "id")
public class AdminTableAccess {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "admin_id")
    private Admin admin;

    @ManyToOne
    @JoinColumn(name = "table_id")
    private DatabaseTable databaseTable;

    @Enumerated(EnumType.STRING)
    private AccessLevel accessLevel;

    @Column(name = "is_creator")
    private boolean isCreator;

    public AdminTableAccess(Admin admin, DatabaseTable databaseTable, AccessLevel accessLevel) {
        this.admin = admin;
        this.databaseTable = databaseTable;
        this.accessLevel = accessLevel;
    }

    @Getter
    public enum AccessLevel {
        READ_ONLY("Read Only"),
        READ_WRITE("Read & Write"),
        FULL_ACCESS("Full Access");

        private final String displayName;

        AccessLevel(String displayName) {
            this.displayName = displayName;
        }
    }
}
