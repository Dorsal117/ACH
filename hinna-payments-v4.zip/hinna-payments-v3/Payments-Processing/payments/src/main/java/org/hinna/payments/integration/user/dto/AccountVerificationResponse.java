package org.hinna.payments.integration.user.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Response DTO for account verification endpoint.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Response containing account verification information")
public class AccountVerificationResponse {

    @Schema(description = "Whether an account exists for the user", example = "true")
    private boolean exists;

    @Schema(description = "Whether an account is active (null if account doesn't exist", example = "true")
    private Boolean active;

    @Schema(description = "Type of account (CLIENT, BUSINESS, STAFF, RESELLER, SAAS)", example = "BUSINESS")
    private String accountType;
}
