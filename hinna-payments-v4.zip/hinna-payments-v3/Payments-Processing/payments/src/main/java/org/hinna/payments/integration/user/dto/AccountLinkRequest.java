package org.hinna.payments.integration.user.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.antlr.v4.runtime.misc.NotNull;

import java.util.UUID;

/**
 * Request DTO for linking a user to an account
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Request to link a user to a payment account")
public class AccountLinkRequest {

    @Schema(description = "ID of the account in the Payment System", example = "123e4567-e89b-12d3-a456-426614174000")
    private UUID accountId;

    @Schema(description = "ID of the user in the User Service", example = "12345")
    private Long userId;

    @Schema(description = "Optional email address for verification", example = "user@example.com")
    private String email;
}
