package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "coupon")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = "applicableListings")
@EqualsAndHashCode(of = "id")
public class Coupon {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(nullable = false, unique = true)
    private String code;

    private String description;

    @Enumerated(EnumType.STRING)
    @Column(name = "discount_type")
    private Sale.DiscountType discountType;

    @Column(name = "discount_value", precision = 19, scale = 4)
    private BigDecimal discountValue;

    @Column(name = "usage_limit")
    private Integer usageLimit;

    @Column(name = "usage_count")
    private Integer usageCount = 0;

    @Column(name = "expiry_date")
    private LocalDate expiryDate;

    @Column(name = "is_active")
    private boolean isActive = true;

    @ManyToMany(mappedBy = "applicableCoupons")
    private Set<Listing> applicableListings = new HashSet<>();

    public Coupon(String code, Sale.DiscountType discountType, BigDecimal discountValue) {
        this.code = code;
        this.discountType = discountType;
        this.discountValue = discountValue;
    }

    public BigDecimal applyCoupon(BigDecimal amount) {
        if (!validateCoupon() || amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return amount;
        }

        BigDecimal discount;
        if (discountType == Sale.DiscountType.PERCENTAGE) {
            discount = amount.multiply(discountValue).divide(BigDecimal.valueOf(100));
        } else {
            discount = discountValue;
        }

        return amount.subtract(discount);
    }

    public boolean validateCoupon() {
        if (!isActive) {
            return false;
        }
        if (expiryDate != null && expiryDate.isBefore(LocalDate.now())) {
            return false;
        }
        if (usageLimit != null && usageLimit > 0 && usageCount >= usageLimit) {
            return false;
        }
        return true;
    }

    public boolean incrementUsage() {
        if (!validateCoupon()) {
            return false;
        }
        usageCount++;

        // Deactivate the coupon when it hits the usage limit
        if (usageLimit != null && usageLimit > 0 && usageCount >= usageLimit) {
            isActive = false;
        }
        return true;
    }
}
