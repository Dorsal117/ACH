package org.hinna.payments.repository;

import org.hinna.payments.model.Listing;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Repository
public interface ListingRepository extends JpaRepository<Listing, UUID> {
    List<Listing> findByNameContaining(String name);
    List<Listing> findByIsActiveTrue();
    List<Listing> findByPriceBetween(BigDecimal min, BigDecimal max);
}
