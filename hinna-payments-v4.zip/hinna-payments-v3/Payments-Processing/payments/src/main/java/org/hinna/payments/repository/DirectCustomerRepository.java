package org.hinna.payments.repository;

import org.hinna.payments.model.DirectCustomer;
import org.hinna.payments.model.ResellerAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Repository
public interface DirectCustomerRepository extends JpaRepository<DirectCustomer, UUID> {
    List<DirectCustomer> findByReseller(ResellerAccount reseller);

    List<DirectCustomer> findByBusinessNameContaining(String businessName);

    List<DirectCustomer> findByFamilyId(UUID familyId);

    List<DirectCustomer> findByCreditGreaterThan(BigDecimal credit);
}