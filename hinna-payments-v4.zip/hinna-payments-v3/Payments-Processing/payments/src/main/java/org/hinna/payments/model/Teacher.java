package org.hinna.payments.model;

import java.util.List;

public class Teacher {
    private String id;
    private String name;
    private String instrument;
    private List<String> timeSlots;

    public Teacher(String id, String name, String instrument, List<String> timeSlots) {
        this.id = id;
        this.name = name;
        this.instrument = instrument;
        this.timeSlots = timeSlots;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getInstrument() {
        return instrument;
    }

    public List<String> getTimeSlots() {
        return timeSlots;
    }
}

