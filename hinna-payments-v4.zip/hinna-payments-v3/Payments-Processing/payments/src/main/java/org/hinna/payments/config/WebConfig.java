package org.hinna.payments.config;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;

@Configuration
public class WebConfig implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        String path = httpRequest.getRequestURI();

        // Ignore Chrome DevTools requests
        if (path.contains("/.well-known/appspecific/com.chrome.devtools")) {
            HttpServletResponse httpResponse = (HttpServletResponse) response;
            httpResponse.setStatus(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        if (response instanceof HttpServletResponse) {
            HttpServletResponse httpResp = (HttpServletResponse) response;
            httpResp.setHeader("Content-Security-Policy",
                    "default-src 'self'; " +
                            "script-src 'self' 'unsafe-inline' https://js.stripe.com https://m.stripe.network https://unpkg.com; "
                            +
                            "connect-src 'self' https://api.stripe.com https://r.stripe.com; " +
                            "frame-src 'self' https://js.stripe.com https://hooks.stripe.com; " +
                            "style-src 'self' 'unsafe-inline'; " +
                            "img-src 'self' https://upload.wikimedia.org;");
        }

        chain.doFilter(request, response);
    }
}
