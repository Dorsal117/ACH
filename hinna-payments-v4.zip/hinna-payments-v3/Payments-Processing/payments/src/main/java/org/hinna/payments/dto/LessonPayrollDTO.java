package org.hinna.payments.dto;

import lombok.Data;
import org.hinna.payments.model.enums.LessonCancellationReason;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * DTO for lesson information needed for payroll processing
 */
@Data
public class LessonPayrollDTO {
    private UUID lessonId;
    private UUID bookingId;
    private UUID originalTeacherId;
    private UUID substituteTeacherId;
    private String lessonTitle;
    private LocalDateTime scheduledTime;
    private LocalDateTime cancellationTime;
    private LessonCancellationReason cancellationReason;
    private BigDecimal originalRate;
    private BigDecimal substituteRate;
    private String studentName;
    private boolean requiresPayment;
}
