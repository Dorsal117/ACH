package org.hinna.payments.service;

import org.hinna.payments.dto.EmployeePayrollDTO;
import org.hinna.payments.dto.PayrollRequestDTO;
import org.hinna.payments.dto.PayrollScheduleRequestDTO;
import org.hinna.payments.model.Payroll;
import org.hinna.payments.model.PayrollSchedule;
import org.hinna.payments.model.enums.PayrollStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Service interface for managing payroll operations
 */
public interface PayrollService {
    /**
     * Create a new payroll payment
     * @param payrollRequest The payroll request data
     * @return The created payroll
     */
    Payroll createPayroll(PayrollRequestDTO payrollRequest);

    /**
     * Get a payroll by its ID
     * @param payrollId The payroll ID
     * @return Optional containing the payroll if found
     */
    Optional<Payroll> getPayrollById(UUID payrollId);

    /**
     * Get a payroll by its reference number
     * @param referenceNumber The reference number
     * @return Optional containing the payroll if found
     */
    Optional<Payroll> getPayrollByReferenceNumber(String referenceNumber);

    /**
     * Get all payrolls for an employee
     * @param employeeId The employee ID
     * @return List of payrolls
     */
    List<Payroll> getPayrollsByEmployee(UUID employeeId);

    /**
     * Get all payrolls for an employer
     * @param employerId The employer ID
     * @return List of payrolls
     */
    List<Payroll> getPayrollsByEmployer(UUID employerId);

    /**
     * Get all payrolls by status
     * @param status The payroll status
     * @return List of payrolls
     */
    List<Payroll> getPayrollsByStatus(PayrollStatus status);

    /**
     * Get scheduled payrolls for a date range
     * @param start Start date
     * @param end End date
     * @return List of scheduled payrolls
     */
    List<Payroll> getScheduledPayrolls(LocalDateTime start, LocalDateTime end);

    /**
     * Process a payroll payment
     * @param payrollId The payroll ID
     * @return The updated payroll
     */
    Payroll processPayroll(UUID payrollId);

    /**
     * Complete a payroll payment that was being processed
     * @param payrollId The payroll ID
     * @return The updated payroll
     */
    Payroll completePayroll(UUID payrollId);

    /**
     * Cancel a scheduled payroll payment
     * @param payrollId The payroll ID
     * @return The updated payroll
     */
    Payroll cancelPayroll(UUID payrollId);

    /**
     * Process all scheduled payrolls that are due
     * @return Number of payrolls processed
     */
    int processScheduledPayrolls();

    /**
     * Create a payroll schedule
     * @param scheduleDTO The schedule data
     * @return The created schedule
     */
    PayrollSchedule createPayrollSchedule(PayrollScheduleRequestDTO scheduleDTO);

    /**
     * Get a payroll schedule by ID
     * @param scheduleId The schedule ID
     * @return Optional containing the schedule if found
     */
    Optional<PayrollSchedule> getPayrollScheduleById(UUID scheduleId);

    /**
     * Get all payroll schedules for an employee
     * @param employeeId The employee ID
     * @return List of schedules
     */
    List<PayrollSchedule> getSchedulesByEmployee(UUID employeeId);

    /**
     * Get all payroll schedules for an employer
     * @param employerId The employer ID
     * @return List of schedules
     */
    List<PayrollSchedule> getSchedulesByEmployer(UUID employerId);

    /**
     * Update a payroll schedule
     * @param scheduleId The schedule ID
     * @param scheduleDTO The updated schedule data
     * @return The updated schedule
     */
    PayrollSchedule updatePayrollSchedule(UUID scheduleId, PayrollScheduleRequestDTO scheduleDTO);

    /**
     * Delete a payroll schedule
     * @param scheduleId The schedule ID
     */
    void deletePayrollSchedule(UUID scheduleId);

    /**
     * Activate a payroll schedule
     * @param scheduleId The schedule ID
     * @return The updated schedule
     */
    PayrollSchedule activateSchedule(UUID scheduleId);

    /**
     * Deactivate a payroll schedule
     * @param scheduleId The schedule ID
     * @return The updated schedule
     */
    PayrollSchedule deactivateSchedule(UUID scheduleId);

    /**
     * Generate payrolls from active schedules
     * @return Number of payrolls generated
     */
    int generateScheduledPayrolls();

    /**
     * Calculate the total payroll expense for a period
     * @param employerId The employer ID
     * @param start Start date
     * @param end End date
     * @return Total payroll expense
     */
    BigDecimal calculatePayrollExpense(UUID employerId, LocalDateTime start, LocalDateTime end);

    /**
     * Get employee payroll summary
     * @param employeeId The employee ID
     * @param start Start date
     * @param end End date
     * @return Employee payroll summary
     */
    EmployeePayrollDTO getEmployeePayrollSummary(UUID employeeId, LocalDateTime start, LocalDateTime end);

    /**
     * Enable or disable automatic ACH payments for a payroll schedule
     * @param scheduleId The schedule ID
     * @param enabled Whether to enable or disable
     * @return The updated schedule
     */
    PayrollSchedule setAchPaymentEnabled(UUID scheduleId, boolean enabled);

    /**
     * Search for payroll records
     * @param searchTerm The search term
     * @return List of matching payrolls
     */
    List<Payroll> searchPayrolls(String searchTerm);

    /**
     * Update employee payment method for a schedule
     * @param scheduleId The schedule ID
     * @param paymentMethodId The payment method ID
     * @return The updated schedule
     */
    PayrollSchedule updatePaymentMethod(UUID scheduleId, UUID paymentMethodId);
}
