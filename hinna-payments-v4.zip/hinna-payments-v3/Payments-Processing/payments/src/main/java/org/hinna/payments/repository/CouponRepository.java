package org.hinna.payments.repository;

import org.hinna.payments.model.Coupon;
import org.hinna.payments.model.Listing;
import org.hinna.payments.model.Sale;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface CouponRepository extends JpaRepository<Coupon, UUID> {
    Optional<Coupon> findByCode(String code);

    List<Coupon> findByIsActiveTrue();

    List<Coupon> findByExpiryDateAfter(LocalDate date);

    List<Coupon> findByApplicableListingsContaining(Listing listing);

//    List<Coupon> findByDiscountType(Sale.DiscountType discountType);

    @Query("SELECT c FROM Coupon c WHERE c.usageCount < c.usageLimit")
    List<Coupon> findAvailableCoupons();
}