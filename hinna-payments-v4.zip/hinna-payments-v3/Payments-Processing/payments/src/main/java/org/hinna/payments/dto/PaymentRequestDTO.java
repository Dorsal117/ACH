package org.hinna.payments.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.UUID;

@Data
public class PaymentRequestDTO {
    private UUID customerId;
    private UUID paymentMethodId;
    private BigDecimal amount;
    private String description;
    private String referenceNumber;
    private String currency;
}
