package org.hinna.payments.service;

import org.hinna.payments.dto.ValidationResult;
import org.hinna.payments.model.Account;
import org.hinna.payments.model.Payment;
import org.hinna.payments.model.PaymentMethod;
import org.hinna.payments.model.Payroll;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public interface StripeService {

    /**
     * Validates a Stripe API key
     * 
     * @param apiKey THe API key to validate
     * @return ValidationResult with success status and message
     */
    ValidationResult validateStripeKey(String apiKey);

    /**
     * Performs a full test of the Stripe API
     * 
     * @param apiKey The API key to test
     * @return ValidationResult with success status and message
     */
    ValidationResult performFullTest(String apiKey);

    /**
     * Create a Stripe customer for an account
     * 
     * @param account The account
     * @return The Stripe customer ID
     */
    String createCustomer(Account account);

    String updateCustomer(Account account);

    String getOrCreateCustomer(Account account);

    /**
     * Create Stripe payment intent for a payment
     * 
     * @param payment The payment
     * @return The client secret for the payment intent
     */
    String createPaymentIntent(Payment payment);

    boolean confirmPaymentIntent(String paymentIntentId);

    boolean capturePaymentIntent(String paymentIntentId);

    boolean cancelPaymentIntent(String paymentIntentId, String reason);

    /**
     * Process a payment
     * 
     * @param payment The payment to process
     * @return True if processed successfully, false otherwise
     */
    boolean processPayment(Payment payment);

    /**
     * Process a refund
     * 
     * @param payment The payment to refund
     * @param amount  The amount to refund
     * @return True if processed successfully, false otherwise
     */
    boolean processRefund(Payment payment, BigDecimal amount);

    /**
     * Create a Stripe setup intent for adding a payment method
     * 
     * @param account The account
     * @return The client secret for the setup intent
     */
    String createSetupIntent(Account account);

    /**
     * Attach a payment method to a customer
     * 
     * @param paymentMethodId The Stripe payment method ID
     * @param account         The account
     * @return True if attached successfully, false otherwise
     */
    boolean attachPaymentMethod(String paymentMethodId, Account account);

    /**
     * Validate a payment method
     * 
     * @param paymentMethod The payment method to validate
     * @return True if valid, false otherwise
     */
    boolean validatePaymentMethod(PaymentMethod paymentMethod);

    /**
     * Delete a payment method
     * 
     * @param paymentMethod The payment method to delete
     */
    void deletePaymentMethod(PaymentMethod paymentMethod);

    /**
     * Verifies a Stripe webhook signature
     * 
     * @param payload   The raw payload from Stripe
     * @param sigHeader The Stripe-Signature header
     * @return True if the signature is valid
     */
    boolean verifyWebhookSignature(String payload, String sigHeader);

    // Used for fallback
    boolean charge(PaymentMethod method, long amountInCents, String currency);

    /**
     * Extract brand and other details from Stripe payment method
     */
    void extractAndSetBrandStripe(PaymentMethod paymentMethod, com.stripe.model.PaymentMethod stripePaymentMethod);

    /**
     * Process an outgoing payment (payroll) via Stripe.
     * This handles transferring funds to an employee
     *
     * @param payroll The payroll payment to process
     * @return true if the payment was successful, false otherwise
     */
    boolean processOutgoingPayment(Payroll payroll);

    String createAchSetupIntent(Account account);

    void refreshBankAccountDetails(PaymentMethod paymentMethod);

    boolean verifyBankAccountMicroDeposits(String paymentMethodId, int firstAmount, int secondAmount);

}
