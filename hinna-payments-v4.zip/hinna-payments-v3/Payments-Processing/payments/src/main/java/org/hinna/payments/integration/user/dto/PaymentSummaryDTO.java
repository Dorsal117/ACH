package org.hinna.payments.integration.user.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * DTO for payment summary information.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Summary information for a payment")
public class PaymentSummaryDTO {

    @Schema(description = "Payment ID", example = "123e4567-e89b-12d3-a456-426614174000")
    private UUID id;

    @Schema(description = "Payment amount", example = "99.99")
    private BigDecimal amount;

    @Schema(description = "Payment status", example = "COMPLETED")
    private String status;

    @Schema(description = "Time the payment was created")
    private LocalDateTime createdAt;

    @Schema(description = "Time the payment was processed (may be null for pending payments)")
    private LocalDateTime processedAt;

    @Schema(description = "Payment reference number", example = "PAY-123456789")
    private String referenceNumber;

    @Schema(description = "Payment description", example = "Monthly subscription")
    private String description;

    @Schema(description = "Payment method used", example = "Credit Card")
    private String paymentMethod;
}
