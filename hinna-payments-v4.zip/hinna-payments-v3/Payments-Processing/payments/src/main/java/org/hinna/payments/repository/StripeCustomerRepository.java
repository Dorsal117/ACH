package org.hinna.payments.repository;

import org.hinna.payments.model.Account;
import org.hinna.payments.model.StripeCustomer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

/**
 * Repository for managing Stripe customer entities
 */
@Repository
public interface StripeCustomerRepository extends JpaRepository<StripeCustomer, UUID> {

    /**
     * Find a Stripe customer by account
     *
     * @param account The account to look up
     * @return The Stripe customer associated with the account, if any
     */
    Optional<StripeCustomer> findByAccount(Account account);

    /**
     * Find a Stripe customer by Stripe customer ID
     *
     * @param stripeCustomerId The Stripe customer ID
     * @return The Stripe customer with the given ID, if any
     */
    Optional<StripeCustomer> findByStripeCustomerId(String stripeCustomerId);

    /**
     * Check if a Stripe customer exists for an account
     *
     * @param account The account to check
     * @return True if a Stripe customer exists for the account, false otherwise
     */
    boolean existsByAccount(Account account);
}
