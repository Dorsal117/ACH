package org.hinna.payments.service.stripe;

import com.stripe.model.*;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.model.Payment;
import org.hinna.payments.model.enums.PaymentStatus;
import org.hinna.payments.model.PaymentTransaction;
import org.hinna.payments.model.enums.TransactionStatus;
import org.hinna.payments.repository.PaymentRepository;
import org.hinna.payments.repository.PaymentTransactionRepository;
import org.hinna.payments.service.StripeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;


import java.time.LocalDateTime;
import java.util.Optional;

/**
 * Service for handling Stripe webhook events
 */
@Service
@Slf4j
public class StripeWebhookHandler {

    private final StripeService stripeService;
    private final PaymentRepository paymentRepository;
    private final PaymentTransactionRepository paymentTransactionRepository;

    @Autowired
    public StripeWebhookHandler(StripeService stripeService,
            PaymentRepository paymentRepository,
            PaymentTransactionRepository paymentTransactionRepository) {
        this.stripeService = stripeService;
        this.paymentRepository = paymentRepository;
        this.paymentTransactionRepository = paymentTransactionRepository;
    }

    /**
     * Process a webhook event from Stripe
     * 
     * @param payload   The raw payload from Stripe
     * @param sigHeader The Stripe-Signature header
     * @return True if the event was processed successfully
     */
    @Transactional
    public boolean handleWebhook(String payload, String sigHeader) {
        // Verify the signature
        if (!stripeService.verifyWebhookSignature(payload, sigHeader)) {
            log.error("Invalid webhook signature");
            return false;
        }

        try {
            // Parse the event
            Event event = Event.GSON.fromJson(payload, Event.class);

            log.info("Processing webhook event: {}", event.getType());

            // Process the event based on its type
            return this.processWebhookEvent(event);
        } catch (Exception e) {
            log.error("Error processing webhook event: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Process a webhook event based on its type
     * 
     * @param event The Stripe event to process
     * @return True if the event was processed successfully
     */
    private boolean processWebhookEvent(Event event) {
        // Get the event type
        String eventType = event.getType();

        // Deserialize the event data
        EventDataObjectDeserializer dataObjectDeserializer = event.getDataObjectDeserializer();

        if (dataObjectDeserializer.getObject().isEmpty()) {
            log.warn("Failed to deserialize event data object: {}", event.getId());
            return false;
        }

        StripeObject stripeObject = dataObjectDeserializer.getObject().get();

        // Process based on event type
        return switch (eventType) {
            case "payment_intent.succeeded" -> handlePaymentIntentSucceeded((PaymentIntent) stripeObject);
            case "payment_intent.payment_failed" -> handlePaymentIntentFailed((PaymentIntent) stripeObject);
            case "payment_intent.canceled" -> handlePaymentIntentCanceled((PaymentIntent) stripeObject);
            case "payment_intent.created" -> handlePaymentIntentCreated((PaymentIntent) stripeObject);

            case "payment_method.attached" -> {
                log.info("Payment method attached: {}", event.getId());
                yield true;
            }
            case "payment_method.detached" -> {
                log.info("Payment method detached: {}", event.getId());
                yield true;
            }
            case "refund.created" -> handleRefundCreated((Refund) stripeObject);
            case "refund.updated" -> handleRefundUpdated((Refund) stripeObject);
            default -> {
                log.info("Unhandled event type: {}", eventType);
                yield true;
            }
            case "payment_intent.processing" -> handlePaymentIntentProcessing((PaymentIntent) stripeObject);
            case "charge.dispute.created" -> handleDisputeCreated((Dispute) stripeObject);

        };
    }

    private boolean handlePaymentIntentSucceeded(PaymentIntent paymentIntent) {
        log.info("Payment succeed: {}", paymentIntent.getId());

        // Find the payment in our system by the reference number (payment intent ID)
        Optional<Payment> paymentOpt = paymentRepository.findByReferenceNumber(paymentIntent.getId());

        if (paymentOpt.isPresent()) {
            Payment payment = paymentOpt.get();

            // Update payment status only if it's not already completed
            if (payment.getStatus() != PaymentStatus.COMPLETED) {
                // Update payment status
                payment.setStatus(PaymentStatus.COMPLETED);
                payment.setProcessedAt(LocalDateTime.now());

                // Save the updated payment
                paymentRepository.save(payment);

                // Create success transaction record
                PaymentTransaction transaction = new PaymentTransaction(
                        payment,
                        TransactionStatus.SUCCESS,
                        payment.getAmount());
                transaction.setMessage("Payment processed successfully");
                transaction.setProviderReference(paymentIntent.getId());
                paymentTransactionRepository.save(transaction);

                log.info("Updated payment {} to COMPLETED", payment.getId());
            }

            return true;
        } else {
            log.warn("Payment not found for payment intent: {}", paymentIntent.getId());
            return false;
        }
    }

        private boolean handlePaymentIntentProcessing(PaymentIntent paymentIntent) {
        Optional<Payment> paymentOpt = paymentRepository.findByReferenceNumber(paymentIntent.getId());
        if (paymentOpt.isEmpty()) {
            log.warn("Payment not found for processing intent: {}", paymentIntent.getId());
            return false;
        }

        Payment payment = paymentOpt.get();
        if (Set.of(PaymentStatus.COMPLETED, PaymentStatus.FAILED).contains(payment.getStatus())) {
            return true;
        }

        payment.setStatus(PaymentStatus.PROCESSING);
        paymentRepository.save(payment);

        PaymentTransaction transaction = new PaymentTransaction(
                payment,
                TransactionStatus.PENDING,
                payment.getAmount());
        transaction.setMessage("Payment is processing via ACH");
        transaction.setProviderReference(paymentIntent.getId());
        paymentTransactionRepository.save(transaction);

        return true;
    }

    private boolean handleDisputeCreated(Dispute dispute) {
        String paymentIntentId = dispute.getPaymentIntent();
        if (paymentIntentId == null) {
            log.warn("Dispute without payment intent: {}", dispute.getId());
            return false;
        }

        Optional<Payment> paymentOpt = paymentRepository.findByReferenceNumber(paymentIntentId);
        if (paymentOpt.isEmpty()) {
            log.warn("Payment not found for dispute: {}", dispute.getId());
            return false;
        }

        Payment payment = paymentOpt.get();
        payment.setStatus(PaymentStatus.FAILED);
        paymentRepository.save(payment);

        PaymentTransaction transaction = new PaymentTransaction(
                payment,
                TransactionStatus.ERROR,
                payment.getAmount());
        transaction.setMessage("ACH return/dispute: " + dispute.getReason());
        transaction.setProviderReference(dispute.getId());
        paymentTransactionRepository.save(transaction);

        return true;
    }


    /**
     * Handle a payment_intent.payment_failed event
     *
     * @param paymentIntent The failed payment intent
     * @return True if handled successfully
     */
    private boolean handlePaymentIntentFailed(PaymentIntent paymentIntent) {
        log.info("Payment failed: {}", paymentIntent.getId());

        // Find the payment in our system by reference number (payment intent ID)
        Optional<Payment> paymentOpt = paymentRepository.findByReferenceNumber(paymentIntent.getId());

        if (paymentOpt.isPresent()) {
            Payment payment = paymentOpt.get();

            // Update payment status
            payment.setStatus(PaymentStatus.FAILED);

            // Save the updated payment
            paymentRepository.save(payment);

            // Create failed transaction record
            PaymentTransaction transaction = new PaymentTransaction(
                    payment,
                    TransactionStatus.DECLINED,
                    payment.getAmount());
            transaction.setMessage("Payment processing failed: " +
                    (paymentIntent.getLastPaymentError() != null ? paymentIntent.getLastPaymentError().getMessage()
                            : "Unknown error"));
            transaction.setProviderReference(paymentIntent.getId());
            paymentTransactionRepository.save(transaction);

            log.info("Updated payment {} to FAILED", payment.getId());
            return true;
        } else {
            log.warn("Payment not found for payment intent: {}", paymentIntent.getId());
            return false;
        }
    }

    /**
     * Handle a payment_intent.canceled event
     *
     * @param paymentIntent The canceled payment intent
     * @return True if handled successfully
     */
    private boolean handlePaymentIntentCanceled(PaymentIntent paymentIntent) {
        log.info("Payment canceled: {}", paymentIntent.getId());

        // Find the payment in our system by reference number (payment intent ID)
        Optional<Payment> paymentOpt = paymentRepository.findByReferenceNumber(paymentIntent.getId());

        if (paymentOpt.isPresent()) {
            Payment payment = paymentOpt.get();

            // Update payment status
            payment.setStatus(PaymentStatus.CANCELLED);

            // Save the updated payment
            paymentRepository.save(payment);

            // Create cancelled transaction record
            PaymentTransaction transaction = new PaymentTransaction(
                    payment,
                    TransactionStatus.DECLINED,
                    payment.getAmount());
            transaction.setMessage("Payment canceled: " +
                    (paymentIntent.getCancellationReason() != null ? paymentIntent.getCancellationReason()
                            : "No reason provided"));
            transaction.setProviderReference(paymentIntent.getId());
            paymentTransactionRepository.save(transaction);

            log.info("Updated payment {} to CANCELLED", payment.getId());
            return true;
        } else {
            log.warn("Payment not found for payment intent: {}", paymentIntent.getId());
            return false;
        }
    }

    /**
     * Handle a payment_intent.created event
     *
     * @param paymentIntent The created payment intent
     * @return True if handled successfully
     */
    private boolean handlePaymentIntentCreated(PaymentIntent paymentIntent) {
        log.info("Payment intent created: {}", paymentIntent.getId());

        // Find the payment in our system by reference number (payment intent ID)
        Optional<Payment> paymentOpt = paymentRepository.findByReferenceNumber(paymentIntent.getId());

        if (paymentOpt.isPresent()) {
            Payment payment = paymentOpt.get();

            // Create transaction record
            PaymentTransaction transaction = new PaymentTransaction(
                    payment,
                    TransactionStatus.INITIATED,
                    payment.getAmount());
            transaction.setMessage("Payment intent created");
            transaction.setProviderReference(paymentIntent.getId());
            paymentTransactionRepository.save(transaction);

            log.info("Recorded payment intent creation for payment {}", payment.getId());
        } else {
            // This might be normal if the webhook arrives before our system creates the
            // payment
            log.info("Payment not yet found for payment intent: {}", paymentIntent.getId());
        }
        return true;
    }

    /**
     * Handle a refund created event
     *
     * @param refund The created refund
     * @return True if handled successfully
     */
    private boolean handleRefundCreated(Refund refund) {
        log.info("Refund created: {}", refund.getId());

        // Find the payment by payment intent ID
        String paymentIntentId = refund.getPaymentIntent();
        Optional<Payment> paymentOpt = paymentRepository.findByReferenceNumber(paymentIntentId);

        if (paymentOpt.isPresent()) {
            Payment payment = paymentOpt.get();

            // Update payment status based on refund amount
            if (refund.getAmount() >= (payment.getAmount().multiply(new java.math.BigDecimal("100")).longValue())) {
                // Full refund
                payment.setStatus(PaymentStatus.REFUNDED);
            } else {
                // Partial refund
                payment.setStatus(PaymentStatus.PARTIAL_REFUNDED);
            }

            // Save the updated payment
            paymentRepository.save(payment);

            // Create refund transaction record
            PaymentTransaction transaction = new PaymentTransaction(
                    payment,
                    TransactionStatus.SUCCESS,
                    new java.math.BigDecimal(refund.getAmount()).divide(
                            java.math.BigDecimal.valueOf(100),
                            java.math.RoundingMode.HALF_UP));
            transaction.setMessage("Refund processed: " + refund.getReason());
            transaction.setProviderReference(refund.getId());
            paymentTransactionRepository.save(transaction);

            log.info("Updated payment {} to {}", payment.getId(), payment.getStatus());
            return true;
        } else {
            log.warn("Payment not found for refund: {}", refund.getId());
            return false;
        }
    }

    /**
     * Handle a refund updated event
     *
     * @param refund The updated refund
     * @return True if handled successfully
     */
    private boolean handleRefundUpdated(Refund refund) {
        log.info("Refund updated: {}", refund.getId());

        // Find the payment by payment intent ID
        String paymentIntentId = refund.getPaymentIntent();
        Optional<Payment> paymentOpt = paymentRepository.findByReferenceNumber(paymentIntentId);

        if (paymentOpt.isPresent()) {
            Payment payment = paymentOpt.get();

            // Update transaction status if refund failed
            if ("failed".equals(refund.getStatus())) {
                // Find the transaction for this refund
                Optional<PaymentTransaction> transactionOpt = paymentTransactionRepository
                        .findByProviderReference(refund.getId());

                if (transactionOpt.isPresent()) {
                    PaymentTransaction transaction = transactionOpt.get();
                    transaction.setStatus(TransactionStatus.ERROR);
                    transaction.setMessage("Refund failed: " + refund.getFailureReason());
                    paymentTransactionRepository.save(transaction);

                    // Revert payment status if refund failed
                    payment.setStatus(PaymentStatus.COMPLETED);
                    paymentRepository.save(payment);

                    log.info("Updated failed refund for payment {}", payment.getId());
                }
            }

            return true;
        } else {
            log.warn("Payment not found for refund update: {}", refund.getId());
            return false;
        }
    }
}
