package org.hinna.payments.repository;

import org.hinna.payments.model.Account;
import org.hinna.payments.model.Payroll;
import org.hinna.payments.model.enums.PayrollStatus;
import org.hinna.payments.model.Staff;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface PayrollRepository extends JpaRepository<Payroll, UUID> {
    List<Payroll> findByEmployee(Staff employee);
    Page<Payroll> findByEmployee(Staff employee, Pageable pageable);
    List<Payroll> findByProcessingAccount(Account procesisngAccount);
    Page<Payroll> findByProcessingAccount(Account processingAccount, Pageable pageable);
    List<Payroll> findByStatus(PayrollStatus status);
    Optional<Payroll> findByReferenceNumber(String referenceNumber);
    List<Payroll> findByScheduledDateBetweenAndStatus(
            LocalDateTime start,
            LocalDateTime end,
            PayrollStatus status
    );
    List<Payroll> findByProcessedDateBetween(LocalDateTime start, LocalDateTime end);

    /**
     * Find payroll records by pay period
     */
    List<Payroll> findByPayPeriodStartGreaterThanAndPayPeriodEndLessThanEqual(
            LocalDateTime periodStart,
            LocalDateTime periodEnd
    );

    /**
     * Find payroll records by ACH payment enabled flag
     */
    List<Payroll> findByIsAchEnabledTrue();
}
