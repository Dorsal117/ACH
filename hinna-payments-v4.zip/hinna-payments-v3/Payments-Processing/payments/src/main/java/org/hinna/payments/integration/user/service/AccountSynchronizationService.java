package org.hinna.payments.integration.user.service;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.client.UserServiceClient;
import org.hinna.payments.exception.ServiceUnavailableException;
import org.hinna.payments.integration.user.dto.UserDTO;
import org.hinna.payments.integration.user.mapper.UserAccountMapper;
import org.hinna.payments.model.Account;
import org.hinna.payments.model.DirectCustomer;
import org.hinna.payments.model.ResellerAccount;
import org.hinna.payments.model.SaaSAccount;
import org.hinna.payments.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Service responsible for synchronizing user data from User Service with accounts in Payments Service.
 */
@Slf4j
@Service
public class AccountSynchronizationService {
    private final UserServiceClient userServiceClient;
    private final UserAccountMapper userAccountMapper;
    private final AccountRepository accountRepository;

    @Autowired
    public AccountSynchronizationService(UserServiceClient userServiceClient,
                                         UserAccountMapper userAccountMapper,
                                         AccountRepository accountRepository) {
        this.userServiceClient = userServiceClient;
        this.userAccountMapper = userAccountMapper;
        this.accountRepository = accountRepository;
    }

    @Transactional
    @Cacheable(value = "accounts", key = "#externalUserId")
    public Account getOrCreateAccount(Long externalUserId) throws ServiceUnavailableException {
        log.debug("Getting or creating account for external user ID: {}", externalUserId);

        // Check if the payment system already have an account for this user
        Optional<Account> existingAccount = accountRepository.findByExternalUserId(externalUserId);

        if (existingAccount.isPresent()) {
            log.debug("Found existing account for external user ID: {}", externalUserId);

            // Check if the service need to update account data from User Service
            if (this.shouldUpdateAccount(existingAccount.get())) {
                return this.refreshAccount(existingAccount.get(), externalUserId);
            }

            return existingAccount.get();
        }

        // No existing account, create a new one from User Service data
        UserDTO userDTO = userServiceClient.getUserById(externalUserId);
        if (userDTO == null) {
            log.error("Failed to fetch user data for external user ID: {}", externalUserId);
            throw new IllegalArgumentException("User not found with ID: " + externalUserId);
        }

        log.info("Creating new account for external user ID: {} with role: {}", externalUserId, userDTO.getRole());

        Account newAccount = userAccountMapper.toAccount(userDTO);
        return accountRepository.save(newAccount);
    }

    /**
     * Get or create an account by email
     * @param email Email address
     * @return Account from the database
     */
    @Transactional
    public Account getOrCreateAccountByEmail(String email) throws ServiceUnavailableException {
        log.debug("Getting or creating account for email: {}", email);

        // Check if we already have an account with this email
        Optional<Account> existingAccount = accountRepository.findByEmail(email);

        if (existingAccount.isPresent()) {
            log.debug("Found existing account for email: {}", email);
            return existingAccount.get();
        }

        // No existing account, create a new one from User Service data
        UserDTO userDTO = userServiceClient.getUserByEmail(email);
        if (userDTO == null) {
            log.error("Failed to fetch user data for email: {}", email);
            throw new IllegalArgumentException("User not found with email: " + email);
        }

        log.info("Creating new account for email: {} with role: {}",
                email, userDTO.getRole());

        Account newAccount = userAccountMapper.toAccount(userDTO);
        return accountRepository.save(newAccount);
    }

    /**
     * Update an account with the latest data from User Service
     * @param account Account to update
     * @return Updated account
     */
    @Transactional
    @CacheEvict(value = "accounts", key = "#account.externalUserId")
    public Account refreshAccount(Account account, Long externalUserId) {
        log.debug("Refreshing account data for external user ID: {}", externalUserId);

        try {
            // Fetch latest data
            UserDTO userDTO = userServiceClient.getUserById(externalUserId);
            if (userDTO == null) {
                log.warn("Could not find user with ID: {} in User Service", externalUserId);
                return account;
            }

            // Update basic fields
            account.setFirstName(userDTO.getFirstName());
            account.setLastName(userDTO.getLastName());
            account.setEmail(userDTO.getEmail());
            account.setMobilePhone(userDTO.getPhoneNumber());
            account.setActive(userDTO.isActive());

            // Update account type-specific fields if needed
            this.updateAccountTypeSpecificFields(account, userDTO);

            log.debug("Account refreshed for external user ID: {}", externalUserId);
            return accountRepository.save(account);

        } catch (ServiceUnavailableException e) {
            log.warn("User Service unavailable, returning cached account data");
            return account;
        }
    }

    /**
     * Fetch all users with a specific role and ensure they have corresponding accounts
     * @param role User role to fetch
     */
    @Transactional
    public List<Account> syncUsersByRole(String role) throws ServiceUnavailableException {
        log.info("Synchronizing all users with role: {}", role);

        List<UserDTO> users = userServiceClient.getUsersByRole(role);

        return users.stream()
                .map(userDTO -> {
                    try {
                        return this.getOrCreateAccount(userDTO.getUserId());
                    } catch (Exception e) {
                        log.error("Failed to sync user: {}", userDTO.getUserId(), e);
                        return null;
                    }
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    /**
     * Determine if an account needs updating based on last update time
     * @param account Account to check
     * @return true if account should be updated
     */
    private boolean shouldUpdateAccount(Account account) {
        // Implement logic(s) to determine if an account needs refreshing here
        // (refresh if last updated more that X hours ago)
        return true; // For now
    }

    /**
     * Update type-specific fields based on account type
     * @param account Account to update
     * @param userDTO User data from User Service
     */
    private void updateAccountTypeSpecificFields(Account account, UserDTO userDTO) {
        if (account instanceof DirectCustomer customer && userDTO.isBusiness()) {
            customer.setBusinessName(userDTO.getBusinessName());
            customer.setTaxId(userDTO.getTaxId());
        } else if (account instanceof ResellerAccount reseller && userDTO.isReseller()) {
            reseller.setCompanyName(userDTO.getCompanyName());
        } else if (account instanceof SaaSAccount saas && userDTO.isSaas()) {
            saas.setCompanyName(userDTO.getCompanyName());
        }
    }
}
