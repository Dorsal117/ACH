package org.hinna.payments.security;

import lombok.extern.slf4j.Slf4j;
import org.hinna.payments.exception.AuthenticationException;
import org.hinna.payments.exception.ServiceUnavailableException;
import org.hinna.payments.integration.user.service.AccountSynchronizationService;
import org.hinna.payments.model.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

/**
 * Utility to resolve the current authenticated user in controllers.
 */
@Slf4j
@Component
public class CurrentUserResolver {

    private final AccountSynchronizationService accountSynchronizationService;

    @Autowired
    public CurrentUserResolver(AccountSynchronizationService accountSynchronizationService) {
        this.accountSynchronizationService = accountSynchronizationService;
    }

    /**
     * Get the current authenticated user's ID from the User Service.
     * @return User ID from the User Service
     * @throws AuthenticationException if no user is authenticated
     */
    public Account getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated() || authentication.getPrincipal() == null) {
            throw new AuthenticationException("No authenticated user found");
        }

        // The principal should be user ID from the User Service
        try {
            Long userId = Long.valueOf(authentication.getPrincipal().toString());
            return accountSynchronizationService.getOrCreateAccount(userId);
        } catch (NumberFormatException | ServiceUnavailableException e) {
            log.error("Invalid user ID in authentication", e);
            throw new AuthenticationException("Invalid user ID in authentication", e);
        }
    }

    /**
     * Get the current authenticated user's ID from the User Service.
     * @return User ID from the User Service
     * @throws AuthenticationException if no user is authenticated
     */
    public Long getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated() ||
                authentication.getPrincipal() == null) {
            throw new AuthenticationException("No authenticated user found");
        }

        try {
            return Long.valueOf(authentication.getPrincipal().toString());
        } catch (NumberFormatException e) {
            log.error("Invalid user ID in authentication", e);
            throw new AuthenticationException("Invalid user ID in authentication", e);
        }
    }

    /**
     * Check if the current user has the given role.
     * @param role Role to check
     * @return true if the user has the role
     */
    public boolean hasRole(String role) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated()) {
            return false;
        }

        return authentication.getAuthorities().stream()
                .anyMatch(authority -> authority.getAuthority().equals("ROLE_" + role));
    }
}
