package org.hinna.payments.controller.api;

import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.Balance;
import com.stripe.model.SetupIntent;
import com.stripe.net.RequestOptions;
import org.hinna.payments.dto.PaymentProviderRequest;
import org.hinna.payments.service.StripeApiKeyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/payment-processors")
public class PaymentProcessorController {

    private final StripeApiKeyService stripeApiKeyService;

    @Autowired
    public PaymentProcessorController(StripeApiKeyService stripeApiKeyService) {
        this.stripeApiKeyService = stripeApiKeyService;
    }

    @PostMapping("/save")
    public ResponseEntity<String> savePaymentProvider(@RequestBody PaymentProviderRequest request) {
        String provider = request.getProvider();
        String secretKey = request.getSecretKey();
        String keyAlias = provider.toLowerCase() + "_primary";

        if (!"stripe".equalsIgnoreCase(provider)) {
            return ResponseEntity.badRequest().body("Unsupported provider.");
        }

        if (stripeApiKeyService.hasApiKeyAlias(keyAlias)) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("API key for this provider already exists.");
        }

        try {
            Stripe.apiKey = secretKey;
            Balance.retrieve();
        } catch (StripeException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Invalid Stripe API key.");
        }

        try {
            stripeApiKeyService.storeApiKey(keyAlias, secretKey);
            return ResponseEntity.ok("Stripe API key validated and securely stored.");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Failed to store API key: " + e.getMessage());
        }
    }

    @GetMapping("/integrations")
    public ResponseEntity<?> getStripeIntegrations() {
        String keyAlias = "stripe_primary";
        try {
            if (stripeApiKeyService.hasApiKeyAlias(keyAlias)) {
                return ResponseEntity.ok(Map.of(
                        "provider", "Stripe",
                        "alias", keyAlias
                ));
            } else {
                return ResponseEntity.ok().build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to fetch integration.");
        }
    }

    @DeleteMapping("/delete/{keyAlias}")
    public ResponseEntity<String> deleteStripeKey(@PathVariable String keyAlias) {
        try {
            boolean deleted = stripeApiKeyService.deleteApiKey(keyAlias);
            if (deleted) {
                return ResponseEntity.ok("Stripe API key deleted.");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Key alias not found.");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete key.");
        }
    }

    @PostMapping("/create-setup-intent")
    public ResponseEntity<?> createSetupIntent() {
        String keyAlias = "stripe_primary";

        try {
            String secretKey = stripeApiKeyService.getDecryptedKey(keyAlias);
            if (secretKey == null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Stripe key not configured.");
            }

            RequestOptions requestOptions = RequestOptions.builder()
                    .setApiKey(secretKey)
                    .build();

            SetupIntent setupIntent = SetupIntent.create(Map.of(), requestOptions);

            return ResponseEntity.ok(Map.of("clientSecret", setupIntent.getClientSecret()));
        } catch (StripeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to create SetupIntent: " + e.getMessage());
        }
    }
}
