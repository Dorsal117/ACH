package org.hinna.payments.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "item")
@Getter
@Setter
@NoArgsConstructor
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class Item extends Listing {

    private String sku;

    @Column(name = "stock_quantity")
    private Integer stockQuantity;

    private String manufacturer;

    public Item(String name, BigDecimal price, String sku) {
        super(name, price);
        this.sku = sku;
        this.stockQuantity = 0;
    }

    public Integer checkInventory() {
        return stockQuantity;
    }

    public boolean updateStock(Integer quantity) {
        if (quantity < 0 && Math.abs(quantity) > stockQuantity) {
            return false;
        }
        stockQuantity += quantity;
        return true;
    }
}
