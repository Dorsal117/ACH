package org.hinna.payments.repository;

import org.hinna.payments.model.Account;
import org.hinna.payments.model.Admin;
import org.hinna.payments.model.AdminGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

import java.util.List;

@Repository
public interface AdminRepository extends JpaRepository<Admin, UUID> {
    Optional<Admin> findByAccount(Account account);
    List<Admin> findByAdminType(String adminType);
    List<Admin> findByAdminGroup(AdminGroup adminGroup);
}