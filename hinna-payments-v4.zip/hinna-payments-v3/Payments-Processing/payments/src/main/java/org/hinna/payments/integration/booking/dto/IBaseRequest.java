package org.hinna.payments.integration.booking.dto;

/**
 * Marker interface to match the IBaseRequest from booking service
 */
public interface IBaseRequest extends Cloneable {
}
