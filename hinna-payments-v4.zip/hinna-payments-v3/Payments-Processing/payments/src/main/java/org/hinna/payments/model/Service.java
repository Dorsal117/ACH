package org.hinna.payments.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "service")
@Getter
@Setter
@NoArgsConstructor
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class Service extends Listing {

    @Column(name = "duration_minutes")
    private Integer durationMinutes;

    @Column(name = "is_recurring")
    private Boolean isRecurring = false;

    private String frequency;

    public Service(String name, BigDecimal price, Integer durationMinutes) {
        super(name, price);
        this.durationMinutes = durationMinutes;
    }

    public BigDecimal calculatePrice(Integer duration) {
        if (duration == null || duration <= 0 || durationMinutes == null || durationMinutes <= 0) {
            return getPrice();
        }
        return getPrice().multiply(new BigDecimal(duration)).divide(new BigDecimal(durationMinutes));
    }

    public boolean checkAvailability(LocalDate data, Integer duration) {
        // check availability
        return true;
    }
}
