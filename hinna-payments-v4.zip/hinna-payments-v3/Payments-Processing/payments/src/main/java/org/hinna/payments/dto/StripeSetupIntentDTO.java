package org.hinna.payments.dto;

import lombok.Data;

import java.util.UUID;

/**
 * Data Transfer Object for Stripe setup intent
 */
@Data
public class StripeSetupIntentDTO {
    private String clientSecret;
    private UUID accountId;
}
