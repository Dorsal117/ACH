package org.hinna.payments.repository;

import org.hinna.payments.model.Payment;
import org.hinna.payments.model.enums.PaymentStatus;
import org.hinna.payments.model.Refund;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface RefundRepository extends JpaRepository<Refund, UUID> {
    /**
     * Find refunds for a specific payment
     */
    List<Refund> findByPayment(Payment payment);

    /**
     * Find refunds by status
     */
    List<Refund> findByStatus(PaymentStatus status);

    /**
     * Find refunds for a payment with a specific status
     */
    List<Refund> findByPaymentAndStatus(Payment payment, PaymentStatus status);

    /**
     * Find refunds created within a date range
     */
    List<Refund> findByCreatedAtBetween(LocalDateTime start, LocalDateTime end);

    /**
     * Find refunds processed within a date range
     */
    List<Refund> findByProcessedAtBetween(LocalDateTime start, LocalDateTime end);

    /**
     * Find refunds by reference number
     */
    Optional<Refund> findByRefundReference(String refundReference);

    /**
     * Find refunds containing a specific reason text
     */
    List<Refund> findByDescriptionContaining(String description);

    /**
     * Find recent refunds for a specific payment
     */
    @Query("SELECT r FROM Refund r WHERE r.payment = :payment ORDER BY r.createdAt DESC")
    List<Refund> findRecentRefundsByPayment(@Param("payment") Payment payment, Pageable pageable);

    /**
     * Calculate total refunded amount for a payment
     */
    @Query("SELECT SUM(r.amount) FROM Refund r WHERE r.payment = :payment AND r.status = 'COMPLETED'")
    BigDecimal calculateTotalRefundedAmount(@Param("payment") Payment payment);
}