package org.hinna.payments.controller;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.hinna.payments.model.Tax;
import org.hinna.payments.service.TaxService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/taxes")
public class TaxController {
    private final TaxService taxService;

    @Autowired
    public TaxController(TaxService taxService) {
        this.taxService = taxService;
    }

    @PostMapping
    public ResponseEntity<Tax> createTax(@RequestBody Tax tax) {
        return ResponseEntity.status(HttpStatus.CREATED).body(taxService.createTax(tax));
    }

    /**
     * Retrieves applicable taxes for a given location and date.
     */
    @GetMapping("/location/{locationId}")
    public ResponseEntity<List<Tax>> getApplicableTaxes(
            @PathVariable UUID locationId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ResponseEntity.ok(taxService.getApplicableTaxes(locationId, date));
    }

    /**
     * Calculates the total amount including applicable taxes.
     */
    @GetMapping("/calculate")
    public ResponseEntity<Map<String, BigDecimal>> calculateTaxedAmount(
            @RequestParam BigDecimal amount,
            @RequestParam UUID locationId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        BigDecimal taxed = taxService.applyTaxes(amount, locationId, date);
        Map<String, BigDecimal> result = new HashMap<>();
        result.put("baseAmount", amount);
        result.put("totalWithTax", taxed);
        result.put("taxAmount", taxed.subtract(amount));
        return ResponseEntity.ok(result);
    }
}
