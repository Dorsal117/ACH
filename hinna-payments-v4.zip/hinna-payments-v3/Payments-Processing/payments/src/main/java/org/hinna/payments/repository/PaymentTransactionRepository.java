package org.hinna.payments.repository;

import org.hinna.payments.model.Payment;
import org.hinna.payments.model.PaymentTransaction;
import org.hinna.payments.model.enums.TransactionStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface PaymentTransactionRepository extends JpaRepository<PaymentTransaction, UUID> {
    List<PaymentTransaction> findByPayment(Payment payment);
    List<PaymentTransaction> findByStatus(TransactionStatus status);
    List<PaymentTransaction> findByTimestampBetween(LocalDateTime start, LocalDateTime end);
    List<PaymentTransaction> findByPaymentAndStatus(Payment payment, TransactionStatus status);

    /**
     * Find a transaction by provider reference (Stripe ID)
     * @param providerReference The provider reference (Stripe ID to search for)
     * @return Optional containing the transaction if found
     */
    Optional<PaymentTransaction> findByProviderReference(String providerReference);
}