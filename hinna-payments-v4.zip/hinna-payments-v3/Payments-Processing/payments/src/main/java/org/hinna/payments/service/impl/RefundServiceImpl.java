package org.hinna.payments.service.impl;

import org.hinna.payments.integration.pat.PayrollPATIntegrationService;
import org.hinna.payments.model.Payment;
import org.hinna.payments.model.enums.PaymentStatus;
import org.hinna.payments.model.Refund;
import org.hinna.payments.repository.PaymentRepository;
import org.hinna.payments.repository.RefundRepository;
import org.hinna.payments.service.RefundService;
import org.hinna.payments.service.StripeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class RefundServiceImpl implements RefundService {

    private final PaymentRepository paymentRepository;
    private final RefundRepository refundRepository;
    private final StripeService stripeService;
    private final PayrollPATIntegrationService patIntegrationService;

    @Autowired
    public RefundServiceImpl(
            PaymentRepository paymentRepository,
            RefundRepository refundRepository,
            StripeService stripeService, PayrollPATIntegrationService patIntegrationService) {
        this.paymentRepository = paymentRepository;
        this.refundRepository = refundRepository;
        this.stripeService = stripeService;
        this.patIntegrationService = patIntegrationService;
    }

    @Override
    @Transactional
    public Refund requestRefund(UUID paymentId, BigDecimal amount, String reason) {
        // Find the payment
        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new IllegalArgumentException("Payment not found"));

        // Validate that the payment is eligible for refund
        if (payment.getStatus() != PaymentStatus.COMPLETED &&
            payment.getStatus() != PaymentStatus.PARTIAL_REFUNDED) {
            throw new IllegalArgumentException("Payment is not in a refundable state");
        }

        // Create and save the refund record with PENDING_APPROVAL status
        Refund refund = new Refund(payment, amount);
        refund.setStatus(PaymentStatus.PENDING_APPROVAL);
        refund.setDescription(reason);
        refundRepository.save(refund);

        return refund;
    }

    @Override
    @Transactional
    public Refund approveRefund(UUID refundId) {
        Refund refund = refundRepository.findById(refundId)
                .orElseThrow(() -> new IllegalArgumentException("Refund not found"));

        // Validate that the refund is pending approval
        if (refund.getStatus() != PaymentStatus.PENDING_APPROVAL) {
            throw new IllegalStateException("Refund is not pending approval");
        }

        // Update refund status to PROCESSING
        refund.setStatus(PaymentStatus.PROCESSING);
        refundRepository.save(refund);

        // Call external Stripe service to process the refund
        boolean success = stripeService.processRefund(refund.getPayment(), refund.getAmount());

        // Refund successful: update refund and payment statuses
        if (success) {
            refund.setStatus(PaymentStatus.COMPLETED);
            refund.setProcessedAt(LocalDateTime.now());

            Payment payment = refund.getPayment();
            if (refund.getAmount().compareTo(payment.getAmount()) == 0) {
                payment.setStatus(PaymentStatus.REFUNDED);
            } else {
                payment.setStatus(PaymentStatus.PARTIAL_REFUNDED);
            }
            paymentRepository.save(payment);
        } else {
            // Refund failed: mark as FAILED
            refund.setStatus(PaymentStatus.FAILED);
        }

        refundRepository.save(refund);
        return refund;
    }

    @Override
    @Transactional
    public Refund rejectRefund(UUID refundId, String rejectionReason) {
        Refund refund = refundRepository.findById(refundId)
                .orElseThrow(() -> new IllegalArgumentException("Refund not found"));

        // Validate that the refund is pending approval
        if (refund.getStatus() != PaymentStatus.PENDING_APPROVAL) {
            throw new IllegalStateException("Refund is not pending approval");
        }

        // Update status to REJECTED and record rejection details
        refund.setStatus(PaymentStatus.REJECTED);
        refund.setDescription("Refund rejected: " + rejectionReason);
        refund.setProcessedAt(LocalDateTime.now());
        refundRepository.save(refund);

        return refund;
    }
}
