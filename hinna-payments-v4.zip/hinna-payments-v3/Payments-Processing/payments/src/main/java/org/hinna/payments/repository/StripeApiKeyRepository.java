package org.hinna.payments.repository;

import org.hinna.payments.model.StripeApiKey;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface StripeApiKeyRepository extends JpaRepository<StripeApiKey, UUID>{
    Optional<StripeApiKey> findByKeyAlias(String keyAlias);
}
