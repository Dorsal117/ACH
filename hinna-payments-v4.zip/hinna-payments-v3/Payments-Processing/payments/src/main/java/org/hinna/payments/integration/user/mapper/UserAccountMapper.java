package org.hinna.payments.integration.user.mapper;

import org.hinna.payments.integration.user.dto.UserDTO;
import org.hinna.payments.model.*;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Maps between User service DTOs and Payment service Account entities
 */
@Component
public class UserAccountMapper {

    /**
     * Convert a UserDTO to an appropriate Account entity based on user role
     * @param userDTO UserDTO
     * @return Account entity
     */
    public Account toAccount(UserDTO userDTO) {
        if (userDTO == null) {
            return null;
        }

        // Determine user role and create appropriate account type
        return switch (userDTO.getRole()) {
            case "BUSINESS" -> this.toDirectCustomer(userDTO);
            case "STAFF" -> this.toStaff(userDTO);
            case "RESELLER" -> this.toResellerAccount(userDTO);
            case "SAAS" -> this.toSaaSAccount(userDTO);
            default -> this.toBaseAccount(userDTO);
        };
    }

    /**
     * Convert to base Account entity
     */
    private Account toBaseAccount(UserDTO userDTO) {
        Account account = new Account();
        setBaseAccountFields(account, userDTO);
        return account;
    }

    /**
     * Convert to DirectCustomer entity
     */
    private DirectCustomer toDirectCustomer(UserDTO userDTO) {
        DirectCustomer customer = new DirectCustomer();
        setBaseAccountFields(customer, userDTO);

        // Set business-specific fields
        customer.setBusinessName(userDTO.getBusinessName());
        customer.setBusinessType("Standard"); // Default type
        customer.setTaxId(userDTO.getTaxId());

        return customer;
    }

    /**
     * Convert to Staff entity
     */
    private Staff toStaff(UserDTO userDTO) {
        Staff staff = new Staff();
        setBaseAccountFields(staff, userDTO);

        // Set staff-specific fields
        staff.setPosition("Staff");
        staff.setDepartment("General");
        staff.setIsAdmin(false);

        return staff;
    }

    /**
     * Convert to ResellerAccount entity
     */
    private ResellerAccount toResellerAccount(UserDTO userDTO) {
        ResellerAccount reseller = new ResellerAccount();
        setBaseAccountFields(reseller, userDTO);

        // Set reseller-specific fields
        reseller.setCompanyName(userDTO.getCompanyName());
        reseller.setResellerCode(generateResellerCode(userDTO));
        reseller.setCommissionRate(new BigDecimal("10.00")); // Default commission rate

        return reseller;
    }

    /**
     * Convert to SaaSAccount entity
     */
    private SaaSAccount toSaaSAccount(UserDTO userDTO) {
        SaaSAccount saas = new SaaSAccount();
        setBaseAccountFields(saas, userDTO);

        // Set SaaS-specific fields
        saas.setCompanyName(userDTO.getCompanyName());
        saas.setPlanType("Standard"); // Default plan type

        return saas;
    }

    /**
     * Set common base fields for all account types
     */
    private void setBaseAccountFields(Account account, UserDTO userDTO) {
        account.setFirstName(userDTO.getFirstName());
        account.setLastName(userDTO.getLastName());
        account.setEmail(userDTO.getEmail());

        // Set external user ID to link with User Service
        account.setExternalUserId(userDTO.getUserId());

        // Combine address fields if present
        StringBuilder fullAddress = new StringBuilder();
        if (userDTO.getAddress() != null && !userDTO.getAddress().isEmpty()) {
            fullAddress.append(userDTO.getAddress());
        }
        if (userDTO.getCity() != null && !userDTO.getCity().isEmpty()) {
            if (fullAddress.length() > 0) fullAddress.append(", ");
            fullAddress.append(userDTO.getCity());
        }
        if (userDTO.getProvince() != null && !userDTO.getProvince().isEmpty()) {
            if (fullAddress.length() > 0) fullAddress.append(", ");
            fullAddress.append(userDTO.getProvince());
        }
        if (userDTO.getPostalCode() != null && !userDTO.getPostalCode().isEmpty()) {
            if (fullAddress.length() > 0) fullAddress.append(", ");
            fullAddress.append(userDTO.getPostalCode());
        }
        if (userDTO.getCountry() != null && !userDTO.getCountry().isEmpty()) {
            if (fullAddress.length() > 0) fullAddress.append(", ");
            fullAddress.append(userDTO.getCountry());
        }
        account.setAddress(fullAddress.toString());

        account.setMobilePhone(userDTO.getPhoneNumber());
        account.setProfilePicturePath(userDTO.getProfilePicturePath());
        account.setActive(true);
    }

    /**
     * Generate a reseller code based on user details
     */
    private String generateResellerCode(UserDTO userDTO) {
        // Simple algorithm to generate a unique reseller code
        String baseCode = userDTO.getLastName().substring(0, Math.min(3, userDTO.getLastName().length())).toUpperCase();
        return baseCode + "-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
    }
}
