package org.hinna.payments.service.impl;

import jakarta.transaction.Transactional;
import org.hinna.payments.model.Permission;
import org.hinna.payments.repository.PermissionRepository;
import org.hinna.payments.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class PermissionServiceImpl implements PermissionService {

    private final PermissionService permissionService;
    private final PermissionRepository permissionRepository;

    @Autowired
    public PermissionServiceImpl(@Lazy PermissionService permissionService, PermissionRepository permissionRepository) {
        this.permissionService = permissionService;
        this.permissionRepository = permissionRepository;
    }

    @Override
    @Transactional
    public Permission createPermission(Permission permission) {
        if (this.existsByName(permission.getName())) {
            throw new IllegalArgumentException("Permission with this name already exists");
        }
        return permissionRepository.save(permission);
    }

    @Override
    public Optional<Permission> getPermissionById(UUID id) {
        return permissionRepository.findById(id);
    }

    @Override
    public Optional<Permission> getPermissionByName(String name) {
        return permissionRepository.findByName(name);
    }

    @Override
    public Page<Permission> getAllPermissions(Pageable pageable) {
        return permissionRepository.findAll(pageable);
    }

    @Override
    public List<Permission> getPermissionsByResourceType(String resourceType) {
        return permissionRepository.findByResourceType(resourceType);
    }

    @Override
    @Transactional
    public Permission updatePermission(UUID id, Permission permissionDetails) {
        return permissionRepository.findById(id)
                .map(existingPermission -> {
                    // Check if name is being changed and is not already taken
                    if (!existingPermission.getName().equals(permissionDetails.getName()) &&
                            this.existsByName(permissionDetails.getName())) {
                        throw new IllegalArgumentException("Permission with name " +
                                permissionDetails.getName() + " already exists");
                    }

                    existingPermission.setName(permissionDetails.getName());
                    existingPermission.setDescription(permissionDetails.getDescription());
                    existingPermission.setResourceType(permissionDetails.getResourceType());
                    existingPermission.setAction(permissionDetails.getAction());

                    return permissionRepository.save(existingPermission);
                })
                .orElseThrow(() -> new IllegalArgumentException("Permission not found"));
    }

    @Override
    @Transactional
    public void deletePermission(UUID id) {
        permissionRepository.deleteById(id);
    }

    @Override
    public boolean existsByName(String name) {
        return permissionRepository.existsByName(name);
    }
}
