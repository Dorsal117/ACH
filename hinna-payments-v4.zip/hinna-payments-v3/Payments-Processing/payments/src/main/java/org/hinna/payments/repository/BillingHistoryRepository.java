package org.hinna.payments.repository;

import org.hinna.payments.model.Account;
import org.hinna.payments.model.BillingHistory;
import org.hinna.payments.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Repository
public interface BillingHistoryRepository extends JpaRepository<BillingHistory, UUID> {
    List<BillingHistory> findByAccount(Account account);

    List<BillingHistory> findByPayment(Payment payment);

    List<BillingHistory> findByTransactionType(String transactionType);

    List<BillingHistory> findByTransactionDateBetween(LocalDateTime start, LocalDateTime end);

    List<BillingHistory> findByAmountGreaterThan(BigDecimal amount);

    List<BillingHistory> findByAccountOrderByTransactionDateDesc(Account account);
}