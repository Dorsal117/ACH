package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "saas_account")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = "resellers", callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class SaaSAccount extends Account {

    @Column(name = "company_name", nullable = false)
    private String companyName;

    @Column(name = "plan_type", nullable = false)
    private String planType;

    @Column(name = "subscription_start")
    private LocalDateTime subscriptionStart;

    @Column(name = "subscription_end")
    private LocalDateTime subscriptionEnd;

    @OneToMany(mappedBy = "saasAccount", cascade = CascadeType.ALL)
    private List<ResellerAccount> resellers = new ArrayList<>();

    public SaaSAccount(String firstName, String lastName, String email, String companyName, String planType) {
        super(firstName, lastName, email);
        this.companyName = companyName;
        this.planType = planType;
    }

    public void addReseller(ResellerAccount reseller) {
        resellers.add(reseller);
        reseller.setSaasAccount(this);
    }

    public void removeReseller(ResellerAccount reseller) {
        resellers.remove(reseller);
        reseller.setSaasAccount(null);
    }

    public boolean isSubscriptionActive() {
        if (subscriptionEnd == null) {
            return true;
        }
        return LocalDateTime.now().isBefore(subscriptionEnd);
    }
}
