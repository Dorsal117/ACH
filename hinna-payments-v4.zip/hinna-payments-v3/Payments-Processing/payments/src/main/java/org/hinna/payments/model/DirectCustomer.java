package org.hinna.payments.model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "direct_customer")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = {"reseller", "staffMembers"}, callSuper = true)
public class DirectCustomer extends Account {

    @Column(name = "business_name", nullable = false)
    private String businessName;

    @Column(name = "business_type")
    private String businessType;

    @Column(name = "tax_id")
    private String taxId;

    @Column(name = "family_id")
    private UUID familyId;

    @Column(name = "credit")
    private BigDecimal credit = BigDecimal.ZERO;

    @Column(name = "allow_bookings_family_df")
    private Boolean allowBookingsFamilyDF = false;

    @Column(name = "allow_payments_family_df")
    private Boolean allowPaymentsFamilyDF = false;

    @Column(name = "allow_refunds_family_df")
    private Boolean allowRefundsFamilyDF = false;

    @Column(name = "allow_email_reports_df")
    private Boolean allowEmailReportsDF = false;

    @ManyToOne
    @JoinColumn(name = "reseller_id")
    private ResellerAccount reseller;

    @OneToMany(mappedBy = "employer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Staff> staffMembers = new ArrayList<>();

    public DirectCustomer(String firstName, String lastName, String email, String businessName) {
        super(firstName, lastName, email);
        this.businessName = businessName;
    }

    public void addStaffMember(Staff staff) {
        staffMembers.add(staff);
        staff.setEmployer(this);
    }

    public void removeStaffMember(Staff staff) {
        staffMembers.remove(staff);
        staff.setEmployer(null);
    }

    public void addCredit(BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) > 0) {
            this.credit = this.credit.add(amount);
        }
    }

    public boolean useCredit(BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) > 0 && amount.compareTo(this.credit) <= 0) {
            this.credit = this.credit.subtract(amount);
            return true;
        }
        return false;
    }
}
