package org.hinna.payments;

import org.hinna.payments.model.StripeApiKey;
import org.hinna.payments.repository.StripeApiKeyRepository;
import org.hinna.payments.security.EncryptionUtil;
import org.hinna.payments.service.StripeApiKeyService;
import org.hinna.payments.service.impl.StripeApiKeyServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class StripeApiKeyServiceImplTest {
    private StripeApiKeyRepository stripeApiKeyRepository;
    private StripeApiKeyService stripeApiKeyService;
    private static final String ENCRYPTION_KEY = "1234567890abcdef"; // 16 characters
    private static final String TEST_ALIAS = "default";
    private static final String TEST_API_KEY = "sk_test_12345";

    @BeforeEach
    void setUp() {
        stripeApiKeyRepository = Mockito.mock(StripeApiKeyRepository.class);
        stripeApiKeyService = new StripeApiKeyServiceImpl(stripeApiKeyRepository, ENCRYPTION_KEY);
    }

    @Test
    void testStoreApiKey_Success() throws Exception {
        when(stripeApiKeyRepository.save(any(StripeApiKey.class))).thenAnswer(i -> i.getArguments()[0]);

        stripeApiKeyService.storeApiKey(TEST_ALIAS, TEST_API_KEY);

        verify(stripeApiKeyRepository, times(1)).save(any(StripeApiKey.class));
    }

    @Test
    void testGetDecryptedKey_Success() throws Exception {
        EncryptionUtil encryptionUtil = new EncryptionUtil(ENCRYPTION_KEY);
        String encryptedKey = encryptionUtil.encrypt(TEST_API_KEY);

        StripeApiKey storedKey = new StripeApiKey(TEST_ALIAS, encryptedKey);
        when(stripeApiKeyRepository.findByKeyAlias(TEST_ALIAS)).thenReturn(Optional.of(storedKey));

        String decryptedKey = stripeApiKeyService.getDecryptedKey(TEST_ALIAS);

        assertEquals(TEST_API_KEY, decryptedKey);
        verify(stripeApiKeyRepository, times(1)).findByKeyAlias(TEST_ALIAS);
    }

    @Test
    void testGetDecryptedKey_KeyNotFound() {
        when(stripeApiKeyRepository.findByKeyAlias(TEST_ALIAS)).thenReturn(Optional.empty());

        Exception exception = assertThrows(RuntimeException.class, () -> {
            stripeApiKeyService.getDecryptedKey(TEST_ALIAS);
        });

        assertTrue(exception.getMessage().contains("Failed to retrieve or decrypt API key"));
    }
}
