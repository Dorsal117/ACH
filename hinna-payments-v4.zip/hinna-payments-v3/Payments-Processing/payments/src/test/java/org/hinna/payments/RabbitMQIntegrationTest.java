package org.hinna.payments;

import org.junit.jupiter.api.Test;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.UUID;

@SpringBootTest
public class RabbitMQIntegrationTest {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Test
    public void testRabbitMQConnection() {
        // Simple test message
        String message = "Test message " + UUID.randomUUID();

        // Send to a test queue
        rabbitTemplate.convertAndSend("test.exchange", "test.key", message);

        // If no exception is thrown, connection is working
    }
}
